# com.officina_hide.base
JavaFX版のアプリケーション構築モデルをこれから作っていきます。  
We will create a JavaFX version application construction model.
