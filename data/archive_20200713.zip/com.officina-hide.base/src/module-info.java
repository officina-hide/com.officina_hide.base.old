module com.officina_hide {
	requires javafx.graphics;
	requires javafx.controls;
	requires java.sql;

<<<<<<< HEAD
//	exports com.officina_hide.base;
=======
>>>>>>> 5e59587f7629e9fe61a8399fb369509cb2996236
	opens com.officina_hide.fx.view;
}