package com.officina_hide.fx.base;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.DIF_OFN_Fx_MenuItem;
import com.officina_hide.base.model.DIF_OFN_Fx_View;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewAction;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIO_OFN_Fx_MenuItem;
import com.officina_hide.base.model.DIO_OFN_Fx_View;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewAction;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIO_OFN_Reference;
import com.officina_hide.base.model.OFN_DB;
import com.officina_hide.base.model.OFN_WhereData;

import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * 画面項目情報クラス<br>
 * <p>指定された画面情報で使用する項目情報を管理する。</p>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/05/05
 */
public class ViewItemData extends OFN_DB {

	/**
	 * 画面項目ベース
	 */
	private VBox base = new VBox();
	/**
	 * 画面情報
	 */
	private DIO_OFN_Fx_View ofv;
	/**
	 * 画面項目情報リスト
	 */
	private List<DIO_OFN_Fx_ViewItem> items;
	
	/**
	 * コンストラクター<br>
	 * <p>インスタンス化時に画面名称から項目情報を抽出し、画面項目情報を構築する。</p>
	 * @author ueno hideo
	 * @since 2020/05/05
	 * @param env 環境情報
	 * @param viewName 画面名
	 */
	public ViewItemData(EnvData env, String viewName, Stage stage) {
		//Fx画面情報取得
		OFN_WhereData where = new OFN_WhereData();
		where.getWhere().append(DIF_OFN_Fx_View.COLUMNNAME_FX_VIEW_NAME).append(" = '").append(viewName).append("'");
		ofv = new DIO_OFN_Fx_View(env, where);
		
		//メニューバー設定
		if(ofv.getOFN_Fx_Menu_ID() > 0) {
			base.getChildren().add(createMenu(env, ofv.getOFN_Fx_Menu_ID()));
		}
		
		//Fx画面項目情報取得
		items = getViewItemData(env, ofv.getOFN_Fx_View_ID());
		for(DIO_OFN_Fx_ViewItem item : items) {
			HBox row = new HBox();
			base.getChildren().add(row);
			//リファレンス情報取得
			DIO_OFN_Reference dor = new DIO_OFN_Reference(env, item.getItem_Type_ID());
			if(dor.getReference_Name().equals("FxItem_Text")) {
				//ラベル
				Label label = new Label(item.getOFN_Name());
				row.getChildren().add(label);
				//テキストフィールド
				TextField text = new TextField("");
				text.setId(item.getFx_ViewItem_Name());
				row.getChildren().add(text);
			}
			if(dor.getReference_Name().equals("FxItem_Password")) {
				//ラベル
				Label label = new Label(item.getOFN_Name());
				row.getChildren().add(label);
				//パスワードフィールド
				PasswordField pass = new PasswordField();
				pass.setId(item.getFx_ViewItem_Name());
				row.getChildren().add(pass);
			}
			if(dor.getReference_Name().equals("FxItem_Button")) {
				Button button = new Button(item.getOFN_Name());
				//ボタン制御処理
				button.setOnAction(event -> {
					buttonAction(env, item, stage);
				});;
				row.getChildren().add(button);
			}
		}
	}

	/**
	 * メニューバー生成<br>
	 * @author ueno hideo
	 * @param env 環境情報
	 * @since 2020/05/10
	 * @param menuID メニュー情報ID
	 * @return メニューバー
	 */
	private MenuBar createMenu(EnvData env, int menuID) {
		MenuBar menubar = new MenuBar();
//		//メニュー情報取得
//		DIO_OFN_Fx_Menu ofm = new DIO_OFN_Fx_Menu(env, menuID);
		//メニュー項目情報取得
		DIO_OFN_Fx_MenuItem fmn = new DIO_OFN_Fx_MenuItem(env);
		OFN_WhereData where = new OFN_WhereData(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENU_ID, menuID);
		List<Integer> ids = fmn.getIds(env, where);
		Menu menu = null;
		for(int id : ids) {
			DIO_OFN_Fx_MenuItem item = new DIO_OFN_Fx_MenuItem(env, id);
			DIO_OFN_Reference dor = new DIO_OFN_Reference(env, item.getMenuItem_Type_ID());
			if(dor.getReference_Name().equals("FxMenu_Group")) {
				menu = new Menu(item.getMenuItem_Name());
				menubar.getMenus().add(menu);
			}
			if(dor.getReference_Name().equals("FxMenu_Item")) {
				MenuItem menuItem = new MenuItem(item.getMenuItem_Name());				
				menu.getItems().add(menuItem);
				
				DIO_OFN_Reference itemAction = new DIO_OFN_Reference(env, item.getMenuAction_Type_ID());
				if(itemAction.getReference_Name().equals("FxAction_NextView")) {
					DIO_OFN_Fx_View nextView = new DIO_OFN_Fx_View(env, item.getMenuAction_View_ID());
					menuItem.setOnAction(event->{
						try {
							Class<?> viewClass = Class.forName(env.getFxViewParent()+"."+nextView.getFX_View_Name());
							Constructor<?> con = viewClass.getConstructor(new Class[] {EnvData.class, String.class});
							Object view = con.newInstance(new Object[] {env, nextView.getFX_View_Name()});
							Method  viewStart = viewClass.getMethod("start", Stage.class);
							viewStart.invoke(view, new Stage());
						} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException
								| IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
							e.printStackTrace();
						}
					});
				}
			}
		}
		return menubar;
	}

	/**
	 * ボタンAction処理<br>
	 * @author ueno hideo
	 * @param env 環境情報
	 * @param item 項目情報
	 * @param stage 画面表示
	 * @since 2020/05/09
	 *  TODO 本処理は汎用化の予定(2020/05/09 ueno)
	 */
	private void buttonAction(EnvData env, DIO_OFN_Fx_ViewItem item, Stage stage) {
		//項目制御情報を取得する。
		OFN_WhereData where = new OFN_WhereData();
		where.getWhere().append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_FX_VIEWITEM_ID)
			.append(" = ").append(item.getOFN_Fx_ViewItem_ID());
		DIO_OFN_Fx_ViewAction fva = new DIO_OFN_Fx_ViewAction(env, where);
		DIO_OFN_Reference dor = new DIO_OFN_Reference(env, fva.getViewAction_Type_ID());
		if(dor.getReference_Name().equals("FxAction_NextView")) {
			try {
				//遷移先画面情報取得
				DIO_OFN_Fx_View ofv = new DIO_OFN_Fx_View(env, fva.getViewAction_View_ID());
				Class<?> viewClass = Class.forName(env.getFxViewParent()+"."+ofv.getFX_View_Name());
				Constructor<?> con = viewClass.getConstructor(new Class[] {EnvData.class, String.class});
				Object view = con.newInstance(new Object[] {env, ofv.getFX_View_Name()});
				Method  viewStart = viewClass.getMethod("start", Stage.class);
				viewStart.invoke(view, new Stage());
				stage.close();
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException
					| IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Fx画面項目情報リスト生成<br>
	 * @param env 環境情報
	 * @param id　Fx画面情報ID
	 * @return Fx画面項目情報リスト
	 */
	private List<DIO_OFN_Fx_ViewItem> getViewItemData(EnvData env, int id) {
		List<DIO_OFN_Fx_ViewItem> list = new ArrayList<DIO_OFN_Fx_ViewItem>();
		DIO_OFN_Fx_ViewItem fvi = new DIO_OFN_Fx_ViewItem(env);
		OFN_WhereData where = new OFN_WhereData();
		where.getWhere().append(DIF_OFN_Fx_ViewItem.COLUMNNAME_OFN_FX_VIEW_ID).append(" = ").append(id);
		List<Integer> ids = fvi.getIds(env, where);
		for(int itemId : ids) {
			DIO_OFN_Fx_ViewItem itemData = new DIO_OFN_Fx_ViewItem(env, itemId);
			list.add(itemData);
		}
		return list;
	}

	public Node getItemNodes() {
		return base;
	}

}
