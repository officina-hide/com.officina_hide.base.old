package com.officina_hide.fx.process;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.fx.view.model.OFN_Fx_ViewData;

import javafx.stage.Stage;

/**
 * ログイン時処理<br>
 * <p>TODO 本クラスは非汎用化のため、再検討が必要</p>
 * @author ueno hideo
 * @version 1.11
 * @since 2020/07/11
 */
public class FxLogin {
	 
		//環境情報
		private EnvData env;

		public FxLogin(EnvData env) {
			this.env = env;
		}
		
		/**
		 * プロセス実行<br>
		 * @author ueno hideo
		 * @since 1.11 2020/07/11
		 * @param stage 画面ステージ
		 * @param item 画面所ぅ方
		 */
		public void execute(Stage stage, OFN_Fx_ViewData item) {
			env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Login Process Start");
			//入力情報チェック
//			System.out.println(item.getStringData("User_ID"));
//			System.out.println(item.getStringData("User_Password"));
			//認証
			// TODO 認証は未実装
		}
}
