package com.officina_hide.fx.process;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.fx.view.model.OFN_Fx_ViewData;

import javafx.stage.Stage;

/**
 * Fx画面遷移処理<br>
 * @author ueno hideo
 * @version 1.11
 * @since 2020/07/12
 */
public class FxGoToView {

	//環境情報
	private EnvData env;

	public FxGoToView(EnvData env) {
		this.env = env;
	}
	
	/**
	 * 処理実行<br>
	 * @param stage 画面ステージ
	 * @param item 画面情報
	 */
	public void execute(Stage stage, OFN_Fx_ViewData item) {
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Go To View");
		//
	}
}
