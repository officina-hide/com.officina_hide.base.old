package com.officina_hide.fx.process;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.DIF_OFN_TableColumn;
import com.officina_hide.base.model.DIO_OFN_Fx_Process;
import com.officina_hide.base.model.DIO_OFN_Fx_View;
import com.officina_hide.base.model.DIO_OFN_TableColumn;
import com.officina_hide.base.model.OFN_WhereData;

import javafx.stage.Stage;

/**
 * Fx画面のプロセス処理を制御する。<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/06/09
 */
public class ExecuteProcess {

	/**
	 * コンストラクタ－<br> 
	 * @param stage 画面
	 * @param processId プロセス情報ID
	 * @param viewId 画面情報ID
	 */
	public ExecuteProcess(EnvData env, Stage stage, int processId, int viewId) {
		try {
			//プロセス情報取得
			DIO_OFN_Fx_Process ofp = new DIO_OFN_Fx_Process(env, processId);
			//画面情報取得
			DIO_OFN_Fx_View ofv = new DIO_OFN_Fx_View(env, viewId);
			//テーブル項目情報取得
			DIO_OFN_TableColumn dot = new DIO_OFN_TableColumn(env);
			OFN_WhereData where = new OFN_WhereData(DIF_OFN_TableColumn.COLUMNNAME_OFN_TABLE_ID, 0);
			List<Integer> ids = dot.getIds(env, where);

			//プロセスで指定されたクラスを実行
			System.out.println(ofp.getProcess_Class());
			Class<?> viewClass = Class.forName(ofp.getProcess_Class());
			Constructor<?> con = viewClass.getConstructor(new Class[] {EnvData.class});
			Object view = con.newInstance(new Object[] {env});
			Method  viewStart = viewClass.getMethod("execute", Stage.class);
			viewStart.invoke(view, stage);
			
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException 
				| InstantiationException | IllegalAccessException | IllegalArgumentException 
				| InvocationTargetException e) {
			e.printStackTrace();
		}

	}

}
