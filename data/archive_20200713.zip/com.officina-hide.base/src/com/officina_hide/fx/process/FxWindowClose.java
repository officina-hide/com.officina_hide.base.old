package com.officina_hide.fx.process;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.fx.view.model.OFN_Fx_ViewData;

import javafx.stage.Stage;

/**
 * Fx画面を閉じる<br>
 * <p>履歴<br>
 * 1.10 新規作成<br>
 * 1.11 executeメソッドに画面情報を追加<br></p>
 * @author ueno hideo
 * @version 1.11 (2020/07/10)
 * @since 2020/06/16
 */
public class FxWindowClose {
 
	//環境情報
	private EnvData env;
	
	public FxWindowClose(EnvData env) {
		this.env = env;
	}

	/**
	 * Fx画面を閉じる<br>
	 * @author ueno hideo
	 * @since 1.10 2020/06/16
	 * @param stage 画面ステージ
	 * @param item 画面情報
	 */
	public void execute(Stage stage, OFN_Fx_ViewData item) {
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "View Close");
		stage.close();
	}
}
