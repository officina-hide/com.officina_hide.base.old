/**
 * Fx画面のプロセス処理を管理する。<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/06/09
 */
package com.officina_hide.fx.process;