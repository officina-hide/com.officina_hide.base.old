package com.officina_hide.fx.process;

import com.officina_hide.base.EnvData;

/**
 * 次のFx画面を表示する。
 * @author ueno hideo
 * @version 1.10
 * @since 2020/06/25
 */
public class FxNextView {
	 
		//環境情報
		private EnvData env;
 
		public FxNextView(EnvData env) {
			this.env = env;
		}

}
