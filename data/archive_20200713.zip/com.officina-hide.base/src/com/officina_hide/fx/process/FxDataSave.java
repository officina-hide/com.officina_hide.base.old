package com.officina_hide.fx.process;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;

import javafx.stage.Stage;

/**
 * 画面情報保存<br>
 * @author ueno
 * @version 1.10
 * @since 2020/06/18
 */
public class FxDataSave {
	
	//環境情報
	private EnvData env;

	public FxDataSave(EnvData env) {
		this.env = env;
	}
	
	/**
	 * 画面情報をテーブルに保管する。
	 * @param stage 画面
	 */
	public void execute(Stage stage) {
		//画面登録情報の取得
		
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Data Save Start");
	}
}
