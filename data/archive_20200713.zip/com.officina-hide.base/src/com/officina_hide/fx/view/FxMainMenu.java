package com.officina_hide.fx.view;

import javafx.stage.Stage;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import com.officina_hide.base.OFN_EnvData;
import com.officina_hide.base.WhereData;
import com.officina_hide.model.DIF_OFN_View;
import com.officina_hide.model.DIO_OFN_View;
import com.officina_hide.fx.util.FxMenuData;
import com.officina_hide.fx.util.FxViewItemData;
import javafx.scene.Scene;

public class FxMainMenu extends FxViewBase {
	@Override
	public void start(Stage stage) throws Exception {
		VBox root = new VBox();

		root.setPadding(new Insets(5, 5, 5, 5));
		root.setStyle("-fx-font-family: MS Mincho; -fx-font-size: 12;");

		OFN_EnvData env = new OFN_EnvData();
		env.setOFN_LoginUser_ID(Integer.parseInt(prop.getProperty(SYSTEM_USER_ID)));
		env.setProp(prop);

		WhereData where = new WhereData();
		where.getWhere().append(DIF_OFN_View.COLUMNNAME_VIEW_NAME).append(" = '").append("FxMainMenu").append("' ");
		DIO_OFN_View dov = new DIO_OFN_View(env, where);

		if(dov.getOFN_View_Menu_ID() > 0) {
			FxMenuData menu = new FxMenuData(env,"FxMainMenu");
			root.getChildren().add(menu.getMenubar());
		}

		FxViewItemData items = new FxViewItemData(env, "FxMainMenu");
		root.getChildren().add(items.getItemNodes());

		Scene scene = new Scene(root, dov.getView_Width(), dov.getView_Height());
		stage.setScene(scene);
		stage.setTitle(dov.getOFN_Name());
		stage.show();

	}
}
