package com.officina_hide.fx.view;

<<<<<<< HEAD
import java.io.File;
import java.io.IOException;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Fx画面開始処理<br>
 * <p>履歴<br>
 * 1.10 新規作成
 * 1.11 画面呼び出しの方法を変更（汎用化）2020/06/30</p>
 * @author ueno hideo
 * @version 1.11
 * @since 2020-04-27
 */
public class FxStartMain extends Application {

	@Override
	public void start(Stage stage) throws Exception {
		//環境情報設定
		// TODO 環境設定処理の実装が必要(2020/05/04 ueno)
		EnvData env = getEnvData();

		//開始メッセージ
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Fx View Start");
		
		
		/*
		 * ログイン画面を表示する。(1.11)
		 */
		new FxView(env, "OFN_FxLogin", new Stage());
//		//開始クラス遷移
//		Class<?> viewClass = Class.forName(env.getStartFxClass());
//		Constructor<?> con = viewClass.getConstructor(new Class[] {EnvData.class, String.class});
//		Object view = con.newInstance(new Object[] {env, env.getStartFxClass().split("\\.")[env.getStartFxClass().split("\\.").length - 1]});
//		Method  viewStart = viewClass.getMethod("start", Stage.class);
//		viewStart.invoke(view, new Stage());
		
		//終了メッセージ
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Fx View End");
		env.getLog().close();
=======
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;

import com.officina_hide.base.OFI_Base;

import javafx.stage.Stage;

/**
 * JavaFX�p�N���N���X<br>
 * <p>�{�N���X�́AjavaFX�p�̍ŏ��̃N���X���N������B</p>
 * @author ueno hide
 * @version 1.0
 * @since 2020-02-20
 */
public class FxStartMain extends FxViewBase implements OFI_Base {

	@Override
	public void start(Stage stage) throws Exception {
		//�V�X�e���ݒ�ǂݍ���
		try {
			prop.load(new FileInputStream("./officina.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		log.open(prop);

		Class<?> viewClass = Class.forName(prop.getProperty(START_FX_CLASS).toString());
		Object view = viewClass.getDeclaredConstructor().newInstance();
		Method  viewStart = viewClass.getMethod("start", Stage.class);
		viewStart.invoke(view, new Stage());
>>>>>>> 5e59587f7629e9fe61a8399fb369509cb2996236
	}

	public static void main(String[] args) {
		launch(args);
	}

<<<<<<< HEAD
	/**
	 * 環境情報設定<br>
	 * TODO 汎用化予定(2020-04-27)
	 * @author ueno hideo
	 * @since 1.10 2020-04-27
	 * @return 環境情報
	 */
	private EnvData getEnvData() {
		EnvData env = new EnvData();
		env.setDB_Host("www.officina-hide.com");
		env.setDB_Name("datatest");
		env.setDB_User("root");
		env.setDB_Password("kan2*Sin");
		env.setSystemUserID(1000001);
		env.setLoginUserID(1000001);
		env.setModelParent("com.officina_hide.base.model");
//		env.setStartFxClass("com.officina_hide.fx.view.Fx_Login");
		env.setFxViewParent("com.officina_hide.fx.view");
		
		try {
			String currentPath = new File(".").getCanonicalPath();
			env.setModelPath(currentPath + "\\src\\com\\officina_hide\\base\\model");
			env.setDataPath(currentPath + "\\data");
		} catch (IOException e) {
			e.printStackTrace();
		}
		/**
		 * システムログ
		 */
		env.getLog().open(env, OFN_Logging.MODE_DEBUG, OFN_Logging.LOG_MODIFYED);
		return env;
	}

=======
>>>>>>> 5e59587f7629e9fe61a8399fb369509cb2996236
}
