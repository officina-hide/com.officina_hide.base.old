package com.officina_hide.fx.view.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.fx.process.ExecuteProcess;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FXM_Fx_MainMenu {
	/**
	 * ルートノード.<br>
	 */
	private VBox root = new VBox();

	/**
	 * rootノードを返す。.<br>
	 */
	public Pane getRoot(EnvData env, Stage stage) {
		getMenu(env, stage, root);
		getItem(root);
		return root;
	}

	/**
	 * 画面メニューバー表示用Node取得.<br>
	 */
	private void getMenu(EnvData env, Stage stage, Pane root) {
		MenuBar menubar = new MenuBar();
		root.getChildren().add(menubar);
		Menu menu_System = new Menu("システム");
		menubar.getMenus().add(menu_System);
		MenuItem menu_UserData = new MenuItem("ユーザー情報");
		menu_System.getItems().add(menu_UserData);
		menu_UserData.setOnAction(event->{
			new ExecuteProcess(env, stage, 100003, 100002);
		});
		MenuItem menu_Exit = new MenuItem("終了");
		menu_System.getItems().add(menu_Exit);
	}

	/**
	 * 画面項目表示用Node取得.<br>
	 */
	private void getItem(Pane root) {
	}
}
