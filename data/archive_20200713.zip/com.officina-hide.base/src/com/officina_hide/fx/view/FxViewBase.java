package com.officina_hide.fx.view;

<<<<<<< HEAD
import javafx.application.Application;

/**
 * FX画面共通クラス<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020-04-27
 */
public abstract class FxViewBase extends Application {

=======
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.officina_hide.base.OFI_Base;
import com.officina_hide.base.OFN_EnvData;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.base.WhereData;
import com.officina_hide.model.DIF_OFN_View_Item;
import com.officina_hide.model.DIO_OFN_View_Item;

import javafx.application.Application;

public abstract class FxViewBase extends Application implements OFI_Base {

	/**
	 * �V�X�e���ݒ�
	 */
	protected final static Properties prop = new Properties();
	/**
	 * �V�X�e�����O
	 */
	protected final static OFN_Logging log = new OFN_Logging();

	/**
	 * ���ڈꗗ�擾<br>
	 * @author ueno hideo
	 * @param env �����
	 * @since 1.0 2020-03-14
	 * @param viewID ��ʏ��ID
	 * @return ��ʍ��ڏ�񃊃X�g
	 */
	public List<ViewItemData> getViewItems(OFN_EnvData env, int viewID) {
		List<ViewItemData> list = new ArrayList<ViewItemData>();
		WhereData where = new WhereData();
		where.getWhere().append(DIF_OFN_View_Item.COLUMNNAME_OFN_VIEW_ID).append(" = ").append(viewID).append(" ");
		List<Integer> ids = new DIO_OFN_View_Item(env).getIds(where);
		for(Integer id : ids) {
			ViewItemData vi = new ViewItemData(env);
			vi.setViewItem(new DIO_OFN_View_Item(env, id));
			list.add(vi);
		}
		return list;
	}
>>>>>>> 5e59587f7629e9fe61a8399fb369509cb2996236
}
