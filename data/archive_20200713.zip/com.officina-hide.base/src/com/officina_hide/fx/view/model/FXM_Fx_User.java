package com.officina_hide.fx.view.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.fx.process.ExecuteProcess;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FXM_Fx_User {
	/**
	 * ルートノード.<br>
	 */
	private VBox root = new VBox();
	private TextField User_Name = new TextField();
	private TextField OFN_Password = new TextField();

	/**
	 * rootノードを返す。.<br>
	 */
	public Pane getRoot(EnvData env, Stage stage) {
		getMenu(env, stage, root);
		getItem(root);
		return root;
	}

	/**
	 * 画面メニューバー表示用Node取得.<br>
	 */
	private void getMenu(EnvData env, Stage stage, Pane root) {
		MenuBar menubar = new MenuBar();
		root.getChildren().add(menubar);
		Menu menu_File = new Menu("ファイル");
		menubar.getMenus().add(menu_File);
		MenuItem menu_Save = new MenuItem("保存");
		menu_File.getItems().add(menu_Save);
		menu_Save.setOnAction(event->{
			new ExecuteProcess(env, stage, 100002, 100003);
		});
		MenuItem menu_Exit = new MenuItem("終了");
		menu_File.getItems().add(menu_Exit);
		menu_Exit.setOnAction(event->{
			new ExecuteProcess(env, stage, 100001, 100003);
		});
	}

	/**
	 * 画面項目表示用Node取得.<br>
	 */
	private void getItem(Pane root) {
		HBox row01 = new HBox();
		root.getChildren().add(row01);
		row01.getChildren().add(new Label("User_Name"));
		row01.getChildren().add(User_Name);
		HBox row02 = new HBox();
		root.getChildren().add(row02);
		row02.getChildren().add(new Label("OFN_Password"));
		row02.getChildren().add(OFN_Password);
	}
}
