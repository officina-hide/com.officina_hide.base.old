/**
 * 画面情報モデルを管理します。
 * @author ueno hideo
 * @version 1.10
 * @since 2020/05/22
 */
package com.officina_hide.fx.view.model;