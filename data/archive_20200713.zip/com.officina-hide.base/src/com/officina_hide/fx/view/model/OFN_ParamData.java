package com.officina_hide.fx.view.model;

/**
 * パラろメータ情報<br>
 * <p>Fx画面からプロセス等への情報引き渡しに使用する個別の情報単位</p>
 * @author ueno hideo 
 * @version 1.10
 * @since 2020/06/21
 */
public class OFN_ParamData {

	/**
	 * パラメータ名
	 */
	private String name;
	/**
	 * パラメータ
	 */
	private Object value;
	private String typeCD;
}
