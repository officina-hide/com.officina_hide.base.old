package com.officina_hide.fx.view.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * Fx画面項目情報クラス<br>
 * @author ueno hideo
 * @version 1.11
 * @since 2020/07/11
 */
public class OFN_Fx_ViewData {

	/**
	 * リストに保管する項目名
	 */
	public static final String FX_ITEM_TYPE = "itemType";		//項目種別
	public static final String FX_ITEM_NAME = "itemName";	//項目名
	public static final String FX_ITEM_NODE = "itemNode";	//項目情報(Node)
	
	/**
	 * 項目リスト<br>
	 * @author ueno hideo
	 * @since 1.00 2020/07/12
	 */
	private List<Map<String, Object>> itemList = new ArrayList<Map<String, Object>>();
	
	/**
	 * 画面項目情報追加
	 * @param itemType 項目種別
	 * @param name 項目名
	 * @param item 項目オブジェクト
	 */
	public void add(String itemType, String name, Object item) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(FX_ITEM_TYPE, itemType);
		map.put(FX_ITEM_NAME, name);
		map.put(FX_ITEM_NODE, item);
		itemList.add(map);
	}

	/**
	 * 文字列情報取得<br>
	 * <p>指定された項目名を持つNodeから入力された文字列を取得する。</p>
	 * @author ueno hideo
	 * @since 1.11 2020/07/12
	 * @param name 項目名
	 * @return 文字列<br>
	 * もし、文字列が取得できない場合は、nullを返す。
	 */
	public String getStringData(String name) {
		String data = null;
		for(Map<String, Object> map : itemList ) {
			if(map.get(FX_ITEM_NAME).toString().equals(name)) {
				switch(map.get(FX_ITEM_TYPE).toString()) {
				case "FxItem_Text":		//1行テキストフィールド
					TextField text = (TextField) map.get(FX_ITEM_NODE);
					data = text.getText();
					break;
				case "FxItem_Password":
					PasswordField pass = (PasswordField) map.get(FX_ITEM_NODE);
					data = pass.getText();
					break;
				default:
					data = null;
				}
			}
		}
		return data;
	}

}
