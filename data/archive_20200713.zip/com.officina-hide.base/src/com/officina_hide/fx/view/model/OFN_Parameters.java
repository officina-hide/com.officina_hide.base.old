package com.officina_hide.fx.view.model;

import java.util.List;

/**
 * パラメーターリスト<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/06/20
 */
public class OFN_Parameters {

	/**
	 * パラメータの一覧<br>
	 * @author ueno hideo
	 * @since 1.10 2020/06/21
	 */
	private List<OFN_ParamData> paramList;
}
