package com.officina_hide.fx.view;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.DIF_OFN_Fx_View;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewProcess;
import com.officina_hide.base.model.DIO_OFN_Fx_View;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewProcess;
import com.officina_hide.base.model.DIO_OFN_Reference;
import com.officina_hide.base.model.OFN_OrderData;
import com.officina_hide.base.model.OFN_WhereData;
import com.officina_hide.fx.view.model.OFN_Fx_ViewData;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Fx画面表示<br>
 * @author ueno　hideo
 * @version 1.11
 * @since 2020/06/30
 */
public class FxView {

	/**
	 * 環境情報
	 */
	private EnvData env;
	/**
	 * 画面情報
	 */
	private DIO_OFN_Fx_View view;
	/**
	 * 画面ステージ
	 */
	private Stage stage;
	/**
	 * 画面情報
	 */
	private OFN_Fx_ViewData viewData = new OFN_Fx_ViewData();
	
	/**
	 * コンストラクタ－<br>
	 * <p>インスタンス時に指定された画面を表示する。</p>
	 * @param env 環境情報
	 * @param viewName 画面名
	 * @param stage ステージ
	 */
	public FxView(EnvData env, String viewName, Stage stage) {
		this.env = env;
		this.stage = stage;
		//画面情報取得
		OFN_WhereData where = new OFN_WhereData(DIF_OFN_Fx_View.COLUMNNAME_FX_VIEW_NAME, viewName);
		view = new DIO_OFN_Fx_View(env, where);
		start(stage);
	}

	/**
	 * 画面表示<br>
	 * @param stage ステージ
	 */
	private void start(Stage stage) {
		//画面項目Node取得
		Scene scene = new Scene(getNodes(), view.getPre_Width(), view.getPre_Height());
		stage.setScene(scene);
		stage.setTitle(view.getOFN_Name());
		stage.showAndWait();
	}

	/**
	 * 画面表示用Node作成<br>
	 * @author ueno hideo
	 * @since 1.11 2020/06/30
	 * @return Root Nods
	 */
	private Parent getNodes() {
		//Root設定
		VBox root = new VBox();
		// TODO paddingはパラメータ化する事(2020/07/02 ueno)
		root.setPadding(new Insets(5, 5, 5, 5));
		
		//画面項目情報取得
		OFN_WhereData where = new  OFN_WhereData(DIF_OFN_Fx_ViewItem.COLUMNNAME_OFN_FX_VIEW_ID, view.getOFN_Fx_View_ID());
		OFN_OrderData order = new OFN_OrderData();
		order.add(DIF_OFN_Fx_ViewItem.COLUMNNAME_ROW_NO, OFN_OrderData.ASCENDING);
		List<Integer> ids = new DIO_OFN_Fx_ViewItem(env).getIds(env, where, order);
		HBox row = null;
		int rowNo = 0;
		for(int id : ids) {
			//画面項目情報取得
			DIO_OFN_Fx_ViewItem item = new DIO_OFN_Fx_ViewItem(env, id);
			//行番号が変わったときは新たに行フレームを生成する。
			if(rowNo != item.getRow_No()) {
				row = new HBox();
				root.getChildren().add(row);
				rowNo = item.getRow_No();
			}
			//項目種別リファレンス情報取得
			DIO_OFN_Reference ref = new DIO_OFN_Reference(env, item.getItem_Type_ID());
			switch(ref.getReference_Name()) {
			case "FxItem_Text":
				getTextNode(row, item);
				break;
			case "FxItem_Password":
				getPasswordNode(row, item);
				break;
			case "FxItem_Button":
				getButtonNode(row, item);
				break;
			}
		}
		
		return root;
	}

	/**
	 * テキスト表示設定<br>
	 * @author ueno hideo
	 * @since 1.11 2020/07/01
	 * @param row 行フレーム
	 * @param item 画面項目情報
	 */
	private void getTextNode(HBox row, DIO_OFN_Fx_ViewItem item) {
		row.setAlignment(Pos.CENTER_LEFT);
		Label label = new Label(item.getOFN_Name());
		row.getChildren().add(label);
		TextField text = new TextField("");
		row.getChildren().add(text);
		//画面情報追加
		viewData.add("FxItem_Text", item.getFx_ViewItem_Name(), text);
	}

	/**
	 * パスワード入力用Node表示<br>
	 * @author ueno hideo
	 * @since 2020/07/01
	 * @param row 行フレーム
	 * @param item 画面項目情報
	 */
	private void getPasswordNode(HBox row, DIO_OFN_Fx_ViewItem item) {
		row.setAlignment(Pos.CENTER_LEFT);
		Label label = new Label(item.getOFN_Name());
		row.getChildren().add(label);
		PasswordField password = new PasswordField();
		row.getChildren().add(password);
		//画面情報追加
		viewData.add("FxItem_Password", item.getFx_ViewItem_Name(), password);
	}

	/**
	 * ボタンNode表示<br>
	 * @author ueno hideo
	 * @since 2020/07/02
	 * @param row 行フレーム
	 * @param item 画面項目情報
	 */
	private void getButtonNode(HBox row, DIO_OFN_Fx_ViewItem item) {
		row.setAlignment(Pos.CENTER_RIGHT);
		Button button = new Button(item.getOFN_Name());
		row.getChildren().add(button);
		//プロセス処理(項目に関連するプロセスを紐づける）
		OFN_WhereData where = new OFN_WhereData(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_FX_VIEWITEM_ID, item.getOFN_Fx_ViewItem_ID());
		OFN_OrderData order = new OFN_OrderData();
		order.add(DIF_OFN_Fx_ViewProcess.COLUMNNAME_PROCESS_SORT_ORDER, OFN_OrderData.ASCENDING);
		List<Integer> ids = new  DIO_OFN_Fx_ViewProcess(env).getIds(env, where, order);
//		DIO_OFN_Fx_ViewProcess fvp = new DIO_OFN_Fx_ViewProcess(env, where);
		if(ids.size() > 0) {
			//ボタンにアクションイベントを作成する。
			button.setOnAction(event -> {
				try {
					for(int id : ids) {
						DIO_OFN_Fx_ViewProcess fvp = new DIO_OFN_Fx_ViewProcess(env, id);
						Class<?> viewClass = Class.forName(fvp.getProcess_Class_Name());
						Constructor<?> con = viewClass.getConstructor(new Class[] {EnvData.class});
						Object view = con.newInstance(new Object[] {env});
						Method  viewStart = viewClass.getMethod("execute", Stage.class, OFN_Fx_ViewData.class);
						viewStart.invoke(view, stage, viewData);
					}
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException 
						| InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					e.printStackTrace();
				}
			});
		}
	}

}
