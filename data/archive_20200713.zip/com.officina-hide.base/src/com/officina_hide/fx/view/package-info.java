/**
 * FX用画面クラス
 * @author ueno hideo
 * @version 1.10
 * @since 2020-04-27
 */
package com.officina_hide.fx.view;