package com.officina_hide.fx.view;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.DIF_OFN_Fx_View;
import com.officina_hide.base.model.DIO_OFN_Fx_View;
import com.officina_hide.base.model.OFN_WhereData;
import com.officina_hide.fx.view.model.FXM_Fx_User;

import javafx.scene.Scene;
import javafx.stage.Stage;

public class Fx_User implements DIF_OFN_Fx_View {
	/**
	 * 画面情報.<br>
	 */
	private DIO_OFN_Fx_View ofv = null;
	/**
	 * 環境情報.<br>
	 */
	private EnvData env;
	/**
	 * 画面名.<br>
	 */
	private String viewName;

	/**
	 * コンストラクター<br>.<br>
	 */
	public Fx_User(EnvData env, String viewName) {
		this.env = env;
		this.viewName = viewName;
		OFN_WhereData where = new OFN_WhereData();
		where.getWhere().append(COLUMNNAME_FX_VIEW_NAME).append(" = '").append(viewName).append("'");
		ofv = new DIO_OFN_Fx_View(env, where);
	}

	/**
	 * 画面表示<br>.<br>
	 */
	public void start(Stage stage) throws Exception {
		FXM_Fx_User ffu = new FXM_Fx_User();
		Scene scene = new Scene(ffu.getRoot(env, stage));
//		VBox root = new VBox();
//		ViewItemData vim = new ViewItemData(env, viewName, stage);
//		root.getChildren().add(vim.getItemNodes());
//		Scene scene = new Scene(root, ofv.getFX_View_Width(), ofv.getFX_View_Height());
		stage.setScene(scene);
//		stage.setTitle(ofv.getOFN_Name());
		stage.showAndWait();
	}

}

