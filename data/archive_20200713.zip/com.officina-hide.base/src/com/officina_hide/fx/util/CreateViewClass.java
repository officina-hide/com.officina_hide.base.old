package com.officina_hide.fx.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import com.officina_hide.base.OFI_Base;
import com.officina_hide.base.OFN_Base;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.model.DIO_OFN_View;

/**
 * ��ʃN���X����<br>
 * @author ueno hideo
 * @version 1.0
 * @since 2020-03-22
 */
public class CreateViewClass extends OFN_Base implements OFI_Base {

	/**
	 * �R���X�g���N�^�[<br>
	 * @author ueno hideo
	 * @since 2020-03-22
	 * @param prop �V�X�e�����
	 * @param view ��ʏ��
	 */
	public CreateViewClass(Properties prop, DIO_OFN_View view) {
		//��ʃN���X����
		createViewClass(prop, view);
	}

	/**
	 * ��ʃN���X����
	 * @author ueno hideo
	 * @since 2020-03-22
	 * @param prop �V�X�e�����
	 * @param view ��ʏ��
	 */
	private void createViewClass(Properties prop, DIO_OFN_View view) {
		log.add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Created View Class : "+view.getView_Name());
		StringBuffer pack = new StringBuffer();
		StringBuffer imp = new StringBuffer();
		StringBuffer source = new StringBuffer();
		
		try {
			File difFile = new File((prop.get(FX_VIEW_PATH).toString()+"\\"+view.getView_Name()+".java"));
			FileWriter fw  = new FileWriter(difFile);
			
			//package�錾
			pack.append("package ").append(prop.getProperty(FX_VIEW_PACKAGE).toString()).append(";").append(OFN_RETURN).append(OFN_RETURN);
			//�N���X��`�J�n
			source.append("public class ").append(view.getView_Name()).append(" extends FxViewBase {").append(OFN_RETURN);
			
			//start���\�b�hOverride
			source.append(setTab(1)).append("@Override").append(OFN_RETURN);
			//start���\�b�h�J�n
			source.append(setTab(1)).append("public void start(Stage stage) throws Exception {").append(OFN_RETURN);
			addImportList("javafx.stage.Stage");
			//root�m�[�h��`
			source.append(setTab(2)).append("VBox root = new VBox();").append(OFN_RETURN).append(OFN_RETURN);
			addImportList("javafx.scene.layout.VBox");
			//root�m�[�h�̃X�^�C���ݒ�
			//TODO : �X�^�C���̊�{���̓R���t�B�O�֘A�̏���ݒ肷��B(2020-04-06 ueno)
			source.append(setTab(2)).append("root.setPadding(new Insets(5, 5, 5, 5));").append(OFN_RETURN);
			source.append(setTab(2)).append("root.setStyle(").append(OFN_DQ).append("-fx-font-family: MS Mincho; -fx-font-size: 12;").append(OFN_DQ)
				.append(");").append(OFN_RETURN).append(OFN_RETURN);
			addImportList("javafx.geometry.Insets");
			//�����擾
			source.append(setTab(2)).append("OFN_EnvData env = new OFN_EnvData();").append(OFN_RETURN);
			source.append(setTab(2)).append("env.setOFN_LoginUser_ID(Integer.parseInt(prop.getProperty(SYSTEM_USER_ID)));").append(OFN_RETURN);
			source.append(setTab(2)).append("env.setProp(prop);").append(OFN_RETURN).append(OFN_RETURN);
			addImportList("com.officina_hide.base.OFN_EnvData");
			//��ʏ��擾
			source.append(setTab(2)).append("WhereData where = new WhereData();").append(OFN_RETURN);
			source.append(setTab(2)).append("where.getWhere().append(DIF_OFN_View.COLUMNNAME_VIEW_NAME).append(")
				.append(OFN_DQ).append(" = ").append(OFN_SQ).append(OFN_DQ).append(")")
				.append(".append(").append(OFN_DQ).append(view.getView_Name()).append(OFN_DQ).append(")")
				.append(".append(").append(OFN_DQ).append(OFN_SQ).append(" ").append(OFN_DQ).append(");").append(OFN_RETURN);
			source.append(setTab(2)).append("DIO_OFN_View dov = new DIO_OFN_View(env, where);").append(OFN_RETURN).append(OFN_RETURN);
			addImportList("com.officina_hide.base.WhereData");
			addImportList("com.officina_hide.model.DIF_OFN_View");
			addImportList("com.officina_hide.model.DIO_OFN_View");
			
			/*
			 * ���j���[�o�[�\���ݒ�<br>
			 * ���j���[���ID���o�^����Ă���Ƃ��Ƀ��j���[�o�[��\������B
			 */
			source.append(setTab(2)).append("if(dov.getOFN_View_Menu_ID() > 0) {").append(OFN_RETURN);
			source.append(setTab(3)).append("FxMenuData menu = new FxMenuData(env,")
				.append(OFN_DQ).append(view.getView_Name()).append(OFN_DQ).append(");").append(OFN_RETURN);
			source.append(setTab(3)).append("root.getChildren().add(menu.getMenubar());").append(OFN_RETURN);
			source.append(setTab(2)).append("}").append(OFN_RETURN).append(OFN_RETURN);
			addImportList("com.officina_hide.fx.util.FxMenuData");
			
			/*
			 * ��ʍ��ڕ\���ݒ�
			 */
			source.append(setTab(2)).append("FxViewItemData items = new FxViewItemData(env, ")
				.append(OFN_DQ).append(view.getView_Name()).append(OFN_DQ).append(");").append(OFN_RETURN);
			source.append(setTab(2)).append("root.getChildren().add(items.getItemNodes());").append(OFN_RETURN).append(OFN_RETURN);
			addImportList("com.officina_hide.fx.util.FxViewItemData");
			
			//��ʕ\��
			source.append(setTab(2)).append("Scene scene = new Scene(root, dov.getView_Width(), dov.getView_Height());").append(OFN_RETURN);
			source.append(setTab(2)).append("stage.setScene(scene);").append(OFN_RETURN);
			source.append(setTab(2)).append("stage.setTitle(dov.getOFN_Name());").append(OFN_RETURN);
			source.append(setTab(2)).append("stage.show();").append(OFN_RETURN).append(OFN_RETURN);
			addImportList("javafx.scene.Scene");
			//start���\�b�h�I��
			source.append(setTab(1)).append("}").append(OFN_RETURN);
			
			//�N���X��`�I��
			source.append("}").append(OFN_RETURN);
			
			//�C���|�[�g��`
			imp.append(createImpirtClass());

			fw.write(pack.toString()+imp.toString()+source.toString());
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
}
