package com.officina_hide.fx.util;

import java.util.List;

import com.officina_hide.base.OFN_EnvData;
import com.officina_hide.base.WhereData;
import com.officina_hide.model.DIF_OFN_View;
import com.officina_hide.model.DIF_OFN_View_Item;
import com.officina_hide.model.DIO_OFN_Reference;
import com.officina_hide.model.DIO_OFN_View;
import com.officina_hide.model.DIO_OFN_View_Item;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Fx��ʍ��ڏ��<br>
 * @author ueno hideo
 * @version 1.0
 * @since 2020-04-01
 */
public class FxViewItemData {

	VBox base = new VBox();
	
	/**
	 * �R���X�g���N�^�[<br> 
	 * @param env �����
	 * @param viewName ��ʖ�
	 */
	public FxViewItemData(OFN_EnvData env, String viewName) {
		//��ʏ��擾
		WhereData where = new WhereData();
		where.getWhere().append(DIF_OFN_View.COLUMNNAME_VIEW_NAME).append(" = '").append(viewName).append("' ");
		DIO_OFN_View ov = new DIO_OFN_View(env, where);
		//���ʃ{�^���̈�ݒ�
		
		//��ʍ��ڏ��擾
		where.clear();
		where.getWhere().append(DIF_OFN_View_Item.COLUMNNAME_OFN_VIEW_ID).append(" = ").append(ov.getOFN_View_ID()).append(" ");
		DIO_OFN_View_Item ovi = new DIO_OFN_View_Item(env, where);
		List<Integer> ids = ovi.getIds(where);
		HBox hb = null;
		int rowCnt = 0;	//����p�s�J�E���g
		for(Integer id : ids) {
			ovi = new DIO_OFN_View_Item(env, id);
			//�s�ʒu�`�F�b�N
			if(rowCnt < ovi.getView_Item_RowNo()) {
				hb = new HBox();
				hb.setAlignment(Pos.CENTER_LEFT);
				hb.setPadding(new Insets(3, 3, 3, 3));
				base.getChildren().add(hb);
				rowCnt = ovi.getView_Item_RowNo();
			}
			//�e�m�[�h�Ή�
			String itemTypeName = new  DIO_OFN_Reference(env, ovi.getView_Item_Type_ID()).getReference_Name();
			switch(itemTypeName) {
			//���x��
			case "View_Label" :
				hb.getChildren().add(addViewLabel(ovi));
				break;
			//�e�L�X�g
			case "View_TextField":
				hb.getChildren().add(addTextField(ovi));
				break;
			}
		}
	}

	/**
	 * ��ʍ��ڂ��擾����B
	 * @author ueno hideo
	 * @since 1.0 2020-04-04
	 * @return
	 */
	public Node getItemNodes() {
		return base;
	}

	/**
	 * ���x����ǉ�<br>
	 * @author ueno hideo
	 * @param viewItemData ��ʍ��ڏ��
	 * @return ���x���m�[�h
	 * @since 1.0 2020-04-06
	 * TODO : �{���\�b�h�̓��t�@�N�^�����O���K�v(2020-03-16 ueno)
	 */
	private Node addViewLabel(DIO_OFN_View_Item viewItem) {
		Label label = new Label(viewItem.getView_Item_Value());
		label.setPrefWidth(viewItem.getView_Item_width());
		return label;
	}

	/**
	 * �e�L�X�g���͍��ڒǉ�<br>
	 * @author ueno hideo
	 * @since 1.0 2020-03-21
	 * @param viewItem ��ʍ��ڏ��
	 * @return �e�L�X�g���ڃm�[�h
	 */
	private Node addTextField(DIO_OFN_View_Item viewItem) {
		TextField text = new TextField();
		text.setPrefWidth(viewItem.getView_Item_width());
		if(viewItem.getView_Item_Value() != null) {
			text.setText(viewItem.getView_Item_Value());
		}
		return text;
	}
}
