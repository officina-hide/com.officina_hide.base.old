package com.officina_hide.util;

import com.officina_hide.model.DIO_Base;

/**
 * �f�[�^�x�[�X���<br>
 * 
 * �e�[�u���č\�z������<code>RebuildTable</code>�ֈڂ��B (2020-02-16 ueno)
 * @author ueno hideo
 * @since 1.0 2020-02-09
 * @version 1.0
 * @deprecated 2020-02-18
 */
public class RestoreDB extends DIO_Base {
	
	/**
	 * �e�[�u�����<br>
	 * �č\�z�Ώۂ̃e�[�u�����<br>
	 */
//	private TableData table = null;
//	private Map<String, String> fieldMap = null;
//	private List<NamedData> fieldList = new  ArrayList<NamedData>();
	
//	/**
//	 * �����ݒ���
//	 */
//	private static Properties prop = new Properties();

//	public static void main(String[] args) {
//		OFN_Logging olog = new OFN_Logging();
//		olog.add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Start Restore DB To XML");
//		try {
//			//�V�X�e���ݒ�ǂݍ���
//			InputStream is = new FileInputStream("./officina.properties");
//			prop.load(is);
//
//			RestoreTable rt = new RestoreTable(prop);
//			rt.execute(prop.get("Data_Path").toString()+"\\export.xml");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		olog.add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "End Restore DB To XML");
//	}
//
//	/**
//	 * �e�[�u���č\�z����<br>
//	 * @author ueno hideo
//	 * @param filePath �e�[�u���\�z�pXML�t�@�C���p�X<br>
//	 * 				(XML file path for table construction)
//	 * @since 1.0 2020-02-10
//	 */
//	public void rebuild(String filePath) {
//		try {
//			XMLInputFactory factory = XMLInputFactory.newInstance();
//			InputStreamReader sr = new InputStreamReader(new FileInputStream(filePath), "UTF-8");
//			XMLStreamReader  xmlr = factory.createXMLStreamReader(sr);
//			while(xmlr.hasNext()) {
//				int event = xmlr.next();
//				switch (event) {
//			      case XMLStreamConstants.START_ELEMENT:
//			    	  if(xmlr.getLocalName().equals("table")) {
//			    		  //�e�[�u����`�p���擾
//			    		  getTableData(xmlr);
//			    	  }
//			    	  if(xmlr.getLocalName().equals("column")) {
//			    		  //�e�[�u�����ڒ�`�p���擾
//			    		  getColumnData(xmlr);
//			    	  }
//			    	  break;
//			      case XMLStreamConstants.END_ELEMENT:
//			    	  if(xmlr.getLocalName().equals("table")) {
//			    		  //�e�[�u����`����
//			    		  List<StringBuffer> list = new ArrayList<StringBuffer>();
//			    		  list.add(new StringBuffer().append("DROP TABLE IF EXISTS ").append(table.getTableName()));
//
//			    		  StringBuffer sql = new StringBuffer();
//			    		  sql.append("CREATE TABLE IF NOT EXISTS ").append(table.getTableName()).append(" ");
//			    		  sql.append("(");
//			    		  StringBuffer clm = new StringBuffer();
//			    		  for(ColumnData cd : table.getColumns()) {
//			    			  if(clm.length() > 0) {
//			    				  clm.append(",");
//			    			  }
//			    			  clm.append(cd.getColumnName()).append(" ");
//			    			  if(cd.getColumnSize() == 0) {
//				    			  clm.append(cd.getColumnTyps()).append(" ");
//			    			  } else {
//			    				  clm.append(cd.getColumnTyps()).append("(").append(cd.getColumnSize()).append(")").append(" ");
//			    			  }
//			    			  if(cd.isNotnull()) {
//			    				  clm.append("NOT NULL").append(" ");
//			    			  }
//			    			  if(cd.getKey() != null && cd.getKey().equals("primary")) {
//			    				  clm.append("PRIMARY KEY").append(" ");
//			    			  }
//			    			  if(cd.getComment().length() > 0) {
//			    				  clm.append("COMMENT '").append(cd.getComment()).append("' ");
//			    			  }
//			    		  }
//			    		  sql.append(clm.toString()).append(") ");
//			    		  if(table.getTableComment().length() > 0) {
//			    			  sql.append("COMMENT '").append(table.getTableComment()).append("' ");
//			    		  }
//			    		  list.add(sql);
//			    		  
//			    		  //�f�[�^�x�[�X�X�V
//			    		  for(StringBuffer sql2 : list) {
//			    			  executeDB(sql2.toString());
//			    		  }
//			    		  
//			    	  }
//			      }
//			}
//			
//		} catch (UnsupportedEncodingException | FileNotFoundException | FactoryConfigurationError | XMLStreamException e) {
//			e.printStackTrace();
//		}
//
//	}

//	/**
//	 * �e�[�u�����o�^����<br>
//	 * <p>XML�t�@�C���ɏ]���āA�w�肳�ꂽ�e�[�u���ɏ���o�^����B<br>
//	 * �{�����ł́AXML�t�@�C���̓��e�ɏ]���ēo�^���邽�߁A�o�^���AID���̏��̎����ݒ�͍s��Ȃ��B</p>
//	 * @author ueno hideo
//	 * @since 1.0 2020-02-13
//	 * @param filePath �o�^�t�@�C���p�X 
//	 */
//	public void restore(String filePath) {
//		try {
//			XMLInputFactory factory = XMLInputFactory.newInstance();
//			InputStreamReader sr = new InputStreamReader(new FileInputStream(filePath), "UTF-8");
//			XMLStreamReader  xmlr = factory.createXMLStreamReader(sr);
//			while(xmlr.hasNext()) {
//				int event = xmlr.next();
//				
//				switch (event) {
//				case XMLStreamConstants.START_ELEMENT:
//					//�e�[�u�����
//					if(xmlr.getLocalName().equals("table")) {
//						table = new TableData();
//						for(int ix = 0; ix < xmlr.getAttributeCount(); ix++) {
//							if(xmlr.getAttributeLocalName(ix).equals("name")) {
//								table.setTableName(xmlr.getAttributeValue(ix));
//								break;
//							}
//						}
//					}
//					
//					//��{���ڏ��
//					if(xmlr.getLocalName().equals("data")) {
//						//�o�^SQL���쐬
//						fieldList = new ArrayList<NamedData>();
//						fieldList.add(new NamedData(table.getTableName()+"_ID", Integer.parseInt(xmlr.getAttributeValue(0))));
//					}
//
//					//�e�[�u�����ڏ��
//					if(xmlr.getLocalName().equals("field")) {
//						NamedData data = new NamedData();
//						String value = null;
//						int type = 0;
//						for(int ix = 0; ix < xmlr.getAttributeCount(); ix++) {
//							if(xmlr.getAttributeLocalName(ix).equals("name")) {
//								data.setName(xmlr.getAttributeValue(ix));
//							}
//							if(xmlr.getAttributeLocalName(ix).equals("value")) {
//								value = xmlr.getAttributeValue(ix);
//							}
//							if(xmlr.getAttributeLocalName(ix).equals("type")) {
//								type = Integer.parseInt(xmlr.getAttributeValue(ix));
//							}
//						}
//						switch(type) {
//						case NamedData.DATA_TYPE_STRING:
//							data.setValue(value);
//							break;
//						case NamedData.DATA_TYPE_INT:
//							data.setValue(Integer.parseInt(value));
//							break;
//						case NamedData.DATA_TYPE_DATE:
//							Calendar cal = new GregorianCalendar(new Locale("jp", "JP"));
//							if(value.equals("$now")) {
//								cal.setTime(new Date());
//							}
//							data.setValue(cal);
//							break;
//						}
//						fieldList.add(data);
//					}
//					
//					break;
//					
//				case XMLStreamConstants.END_ELEMENT:
//					if(xmlr.getLocalName().equals("data")) {
//						//���̓o�^
//						StringBuffer sql = new StringBuffer();
//						StringBuffer set = new StringBuffer();
//						sql.append("INSERT INTO ").append(table.getTableName()).append(" ");
//						sql.append("SET ");					
//						for(NamedData data : fieldList) {
//							if(set.length() > 0) {
//								set.append(", ");
//							}
//							set.append(data.getName()).append(" = ");
//							switch(data.getValueType()) {
//							case NamedData.DATA_TYPE_STRING:
//								set.append("'").append(data.getStringValue()).append("'");
//								break;
//							case NamedData.DATA_TYPE_INT:
//								set.append(data.getIntValue());
//								break;
//							case NamedData.DATA_TYPE_DATE:
//								set.append("'").append(sqlDatefmt.format(data.getDateValue().getTime())).append("'");
//								break;
//							}
//						}
//						sql.append(set.toString());
//						//DB�֒ǉ�
//						executeDB(sql.toString());
//					}
//					break;
//				}
//			}
//		} catch (UnsupportedEncodingException | FileNotFoundException | FactoryConfigurationError | XMLStreamException e) {
//			e.printStackTrace();
//		}
//	}

//	/**
//	 * �e�[�u����`���擾<br>
//	 * @author ueno hideo
//	 * @since 1.0 2020-02-10
//	 * @param xmlr�@�e�[�u���\�z��`���
//	 */
//	private void getTableData(XMLStreamReader xmlr) {
//		table = new TableData();
//		for(int ix = 0; ix < xmlr.getAttributeCount(); ix++) {
//			switch(xmlr.getAttributeLocalName(ix)) {
//			case "id":
//				break;
//			case "name":
//				table.setTableName(xmlr.getAttributeValue(ix));
//				break;
//			case "comment":
//				table.setTableComment(xmlr.getAttributeValue(ix));
//				break;
//			}
//		}
//	}

//	/**
//	 * �e�[�u�����ڒ�`���擾
//	 * @param xmlr
//	 */
//	private void getColumnData(XMLStreamReader xmlr) {
//		//�e�[�u�����ڏ����e�[�u�����ɐV�K�ǉ�����B
//		ColumnData cd = new ColumnData();
//		table.getColumns().add(cd);
//		for(int ix = 0; ix < xmlr.getAttributeCount(); ix++) {
//			switch(xmlr.getAttributeLocalName(ix)) {
//			case "name":
//				cd.setColumnName(xmlr.getAttributeValue(ix));
//				break;
//			case "type":
//				cd.setColumnTyps(xmlr.getAttributeValue(ix));
//				break;
//			case "notnull":
//				if(xmlr.getAttributeValue(ix).equals("YES")) {
//					cd.setNotnull(true);
//				} else {
//					cd.setNotnull(false);
//				}
//				break;
//			case "key":
//				cd.setKey(xmlr.getAttributeValue(ix));
//				break;
//			case "comment":
//				cd.setComment(xmlr.getAttributeValue(ix));
//				break;
//			case "size":
//				cd.setColumnSize(Integer.parseInt(xmlr.getAttributeValue(ix)));
//				break;
//			}
//		}
//	}

}
