package com.officina_hide.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.officina_hide.model.DIF_Base;
import com.officina_hide.model.DIO_Base;

/**
 * �e�[�u�����o��<br>
 * @author ueno hideo 
 * @since 1.0 2020-02-03
 * @version 1.0
 */
public class ExportTable extends DIO_Base  implements DIF_Base {

	public ExportTable(Properties prop) {
//		this.prop = prop;
	}

	/**
	 * �o�͎��s<br>
	 * @author ueno hideo
	 * @since 1.0 2020-02-03
	 * @param filePath �o�̓t�@�C��Path
	 */
	public void execute(String filePath) {
		//�e�[�u����񃊃X�g�쐬
		List<Map<String, String>> tableList = getTableList();

		try {
			OutputStreamWriter os = new OutputStreamWriter( new FileOutputStream(filePath), "UTF-8");
			XMLOutputFactory xmlof = XMLOutputFactory.newInstance();
			XMLStreamWriter xmlw = xmlof.createXMLStreamWriter(os);
			xmlw.writeStartDocument("utf-8", "1.0");
			xmlw.writeCharacters("\n");
			
			xmlw.writeStartElement("tables");
			xmlw.writeCharacters("\n");
			for(Map<String, String>  tableMap : tableList) {
				xmlw.writeCharacters("\t");
				xmlw.writeStartElement("table");
				xmlw.writeAttribute(DB_TABLE_NAME, tableMap.get(DB_TABLE_NAME).toString());
				xmlw.writeAttribute(DB_COMMENT, tableMap.get(DB_COMMENT).toString());
				
				//���ڏ��
				xmlw.writeCharacters("\n\t\t");
				xmlw.writeStartElement("columns");
				xmlw.writeCharacters("\n");
				List<Map<String, String>> columnList = getTableColumnInfo(tableMap.get(DB_TABLE_NAME).toString());
				for(Map<String, String> map : columnList) {
					xmlw.writeCharacters("\t\t\t");
					xmlw.writeStartElement("column");
					xmlw.writeAttribute(DB_FIELD, map.get(DB_FIELD).toString());
					xmlw.writeAttribute(DB_TYPE, map.get(DB_TYPE).toString());
					xmlw.writeAttribute(DB_NULL, map.get(DB_NULL).toString());
					xmlw.writeAttribute(DB_KEY, map.get(DB_KEY).toString());
					xmlw.writeAttribute(DB_DEFAULT, map.get(DB_DEFAULT).toString());
					xmlw.writeAttribute(DB_COMMENT, map.get(DB_COMMENT).toString());
					xmlw.writeEndElement();
					xmlw.writeCharacters("\n");
				}
				xmlw.writeCharacters("\t\t");
				xmlw.writeEndElement();
				xmlw.writeCharacters("\n");
				
				xmlw.writeCharacters("\t");
				xmlw.writeEndElement();
				xmlw.writeCharacters("\n");
			}
			
			xmlw.writeEndElement();
			
			
			xmlw.writeEndDocument();
			xmlw.close();
		} catch (FileNotFoundException | FactoryConfigurationError | XMLStreamException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * �f�[�^�x�[�X�ɓo�^����Ă���e�[�u���̈ꗗ���쐬����B<br>
	 * @author ueno hideo
	 * @since 1.0 2020-02-04
	 * @return �e�[�u���ꗗ
	 */
	private List<Map<String, String>> getTableList() {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		StringBuffer sql = new StringBuffer();
		try {
			sql.append("SHOW TABLE STATUS;");
			ResultSet rs = queryDB(sql.toString());
			while(rs.next()) {
				Map<String, String> map = new HashMap<String, String>();
				map.put(DB_TABLE_NAME, rs.getString(DB_TABLE_NAME));
				map.put(DB_COMMENT, rs.getString(DB_COMMENT));
				list.add(map);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return list;
	}

	/**
	 * �e�[�u�����ڂ̈ꗗ���쐬����B<br>
	 * @param tableName �Ώۃe�[�u����
	 * @return �e�[�u�����ڈꗗ
	 */
	private List<Map<String, String>> getTableColumnInfo(String tableName) {
		List<Map<String, String>> list = new ArrayList<Map<String,String>>();
		StringBuffer sql = new StringBuffer();
		try {
			sql.append("SHOW FULL COLUMNS FROM "+ tableName);
			ResultSet rs = queryDB(sql.toString());
			while(rs.next()) {
				Map<String, String> map = new HashMap<String, String>();
				map.put(DB_FIELD, rs.getString(DB_FIELD));
				map.put(DB_TYPE, rs.getString(DB_TYPE));
				map.put(DB_NULL,	rs.getString(DB_NULL));
				map.put(DB_KEY, rs.getString(DB_KEY));
				if(rs.getString(DB_DEFAULT) != null) {
					map.put(DB_DEFAULT, rs.getString(DB_DEFAULT));
				} else {
					map.put(DB_DEFAULT, "null");					
				}
				map.put(DB_COMMENT, rs.getString(DB_COMMENT));
				list.add(map);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

}
