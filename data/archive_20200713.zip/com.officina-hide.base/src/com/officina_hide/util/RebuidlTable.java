package com.officina_hide.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.officina_hide.model.ColumnData;
import com.officina_hide.model.DIO_Base;
import com.officina_hide.model.TableData;

/**
 * �e�[�u����ۊǂ���XML�t�@�C�����č\�z����B<br>
 * @author ueno hideo
 * @version 1.0
 * @since 1.0  2020-02-16
 */
public class RebuidlTable extends DIO_Base {
	/**
	 * �e�[�u�����<br>
	 * �č\�z�Ώۂ̃e�[�u�����<br>
	 */
	private TableData table = null;

	/**
	 * �č\�z����<br>
	 * @author ueno hideo
	 * @since 1.0 2020-02-16
	 * @param filePath �č\�z�pXML�t�@�C��
	 */
	public void rebuild(String filePath) {
		try {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			InputStreamReader sr = new InputStreamReader(new FileInputStream(filePath), "UTF-8");
			XMLStreamReader  xmlr = factory.createXMLStreamReader(sr);
			while(xmlr.hasNext()) {
				int event = xmlr.next();
				switch (event) {
			      case XMLStreamConstants.START_ELEMENT:
			    	  if(xmlr.getLocalName().equals("table")) {
			    		  //�e�[�u����`�p���擾
			    		  getTableData(xmlr);
			    	  }
			    	  if(xmlr.getLocalName().equals("column")) {
			    		  //�e�[�u�����ڒ�`�p���擾
			    		  getColumnData(xmlr);
			    	  }
			    	  break;
			      case XMLStreamConstants.END_ELEMENT:
			    	  if(xmlr.getLocalName().equals("table")) {
			    		  //�e�[�u����`����
			    		  List<StringBuffer> list = new ArrayList<StringBuffer>();
			    		  list.add(new StringBuffer().append("DROP TABLE IF EXISTS ").append(table.getTableName()));

			    		  StringBuffer sql = new StringBuffer();
			    		  sql.append("CREATE TABLE IF NOT EXISTS ").append(table.getTableName()).append(" ");
			    		  sql.append("(");
			    		  StringBuffer clm = new StringBuffer();
			    		  for(ColumnData cd : table.getColumns()) {
			    			  if(clm.length() > 0) {
			    				  clm.append(",");
			    			  }
			    			  clm.append(cd.getColumnName()).append(" ");
			    			  if(cd.getColumnSize() == 0) {
				    			  clm.append(cd.getColumnTypeName()).append(" ");
			    			  } else {
			    				  clm.append(cd.getColumnTypeName()).append("(").append(cd.getColumnSize()).append(")").append(" ");
			    			  }
			    			  if(cd.getDefaultValue() != null && cd.getDefaultValue().length() > 0) {
			    				  clm.append("DEFAULT ").append(cd.getDefaultValue()).append(" ");
			    			  }
			    			  if(cd.isNotnull()) {
			    				  clm.append("NOT NULL").append(" ");
			    			  }
			    			  if(cd.getKey() != null && cd.getKey().equals("primary")) {
			    				  clm.append("PRIMARY KEY").append(" ");
			    			  }
			    			  if(cd.getComment().length() > 0) {
			    				  clm.append("COMMENT '").append(cd.getComment()).append("' ");
			    			  }
			    		  }
			    		  sql.append(clm.toString()).append(") ");
			    		  if(table.getTableComment().length() > 0) {
			    			  sql.append("COMMENT '").append(table.getTableComment()).append("' ");
			    		  }
			    		  list.add(sql);
			    		  
			    		  //�f�[�^�x�[�X�X�V
			    		  for(StringBuffer sql2 : list) {
			    			  executeDB(sql2.toString());
			    		  }
			    		  
			    	  }
			      }
			}
			
		} catch (UnsupportedEncodingException | FileNotFoundException | FactoryConfigurationError | XMLStreamException e) {
			e.printStackTrace();
		}
	}

	/**
	 * �e�[�u����`���擾<br>
	 * @author ueno hideo
	 * @since 1.0 2020-02-10
	 * @param xmlr�@�e�[�u���\�z��`���
	 */
	private void getTableData(XMLStreamReader xmlr) {
		table = new TableData();
		for(int ix = 0; ix < xmlr.getAttributeCount(); ix++) {
			switch(xmlr.getAttributeLocalName(ix)) {
			case "id":
				break;
			case "name":
				table.setTableName(xmlr.getAttributeValue(ix));
				break;
			case "comment":
				table.setTableComment(xmlr.getAttributeValue(ix));
				break;
			}
		}
	}

	/**
	 * �e�[�u�����ڒ�`���擾
	 * @param xmlr
	 */
	private void getColumnData(XMLStreamReader xmlr) {
		//�e�[�u�����ڏ����e�[�u�����ɐV�K�ǉ�����B
		ColumnData cd = new ColumnData();
		table.getColumns().add(cd);
		for(int ix = 0; ix < xmlr.getAttributeCount(); ix++) {
			switch(xmlr.getAttributeLocalName(ix)) {
			case "name":
				cd.setColumnName(xmlr.getAttributeValue(ix));
				break;
			case "type":
				cd.setColumnTypeName(xmlr.getAttributeValue(ix));
				break;
			case "notnull":
				if(xmlr.getAttributeValue(ix).equals("YES")) {
					cd.setNotnull(true);
				} else {
					cd.setNotnull(false);
				}
				break;
			case "key":
				cd.setKey(xmlr.getAttributeValue(ix));
				break;
			case "comment":
				cd.setComment(xmlr.getAttributeValue(ix));
				break;
			case "size":
				cd.setColumnSize(Integer.parseInt(xmlr.getAttributeValue(ix)));
				break;
			case "default":
				cd.setDefaultValue(xmlr.getAttributeValue(ix));
				break;
			}
		}
	}
}
