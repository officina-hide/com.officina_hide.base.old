package com.officina_hide.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.officina_hide.base.NamedData;
import com.officina_hide.model.DIO_Base;
import com.officina_hide.model.TableData;

/**
 * �e�[�u���č\�z<br>
 * @author ueno hideo
 * @version 1.0
 * @since 1.0 2020-02-09
 */
public class RestoreTable extends DIO_Base {
	/**
	 * �e�[�u�����<br>
	 * �č\�z�Ώۂ̃e�[�u�����<br>
	 */
	private TableData table = null;
	private List<NamedData> fieldList = new  ArrayList<NamedData>();

	/**
	 * �e�[�u���\�z����<br>
	 * @author ueno hideo
	 * @since 2020-02-09
	 * @param filePath DB�\�z�pXML�t�@�C��
	 */
	public void execute(String filePath) {
		try {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			InputStreamReader sr = new InputStreamReader(new FileInputStream(filePath), "UTF-8");
			XMLStreamReader  xmlr = factory.createXMLStreamReader(sr);
			while(xmlr.hasNext()) {
			      int event = xmlr.next();
			      switch (event) {
			      case XMLStreamConstants.START_ELEMENT:
			    	  System.out.println(xmlr.getLocalName());
			      }
			}
		} catch (UnsupportedEncodingException | FileNotFoundException | FactoryConfigurationError | XMLStreamException e) {
			e.printStackTrace();
		}
	}

	/**
	 * �ޔ�pXML�t�@�C������e�[�u���ɏ���o�^����B<br>
	 * �{�N���X�̑O������Ƃ��āA�e�[�u���͍č\�z���ꏉ��������Ă��鎖�i���ǉ��̖ړI�̏ꍇ�������j<br>
	 * @see RebuildTable
	 * @author ueno hideo
	 * @since 1.0 2020-02-17
	 * @param filePath �o�^�pXML�t�@�C���p�X
	 */
	public void restore(String filePath) {
		try {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			InputStreamReader sr = new InputStreamReader(new FileInputStream(filePath), "UTF-8");
			XMLStreamReader  xmlr = factory.createXMLStreamReader(sr);
			while(xmlr.hasNext()) {
				int event = xmlr.next();
				
				switch (event) {
				case XMLStreamConstants.START_ELEMENT:
					//�e�[�u�����
					if(xmlr.getLocalName().equals("table")) {
						table = new TableData();
						for(int ix = 0; ix < xmlr.getAttributeCount(); ix++) {
							if(xmlr.getAttributeLocalName(ix).equals("name")) {
								table.setTableName(xmlr.getAttributeValue(ix));
							}
							if(xmlr.getAttributeLocalName(ix).equals("id")) {
								table.setOFNTableID(Integer.parseInt(xmlr.getAttributeValue(ix)));
							}
						}
					}
					
					//��{���ڏ��
					if(xmlr.getLocalName().equals("data")) {
						//�o�^SQL���쐬
						fieldList = new ArrayList<NamedData>();
						NamedData data = new NamedData();
						data.setName(table.getTableName()+"_ID");
						if(xmlr.getAttributeValue(0).equals("$New")) {
							//ID�̔ԏ���
							data.setValue(getNewID(table.getTableName(),  Integer.parseInt(prop.get("SYSTEM_User_ID").toString())));
						} else {
							data.setValue(Integer.parseInt(xmlr.getAttributeValue(0)));
						}
						fieldList.add(data);
					}

					//�e�[�u�����ڏ��
					if(xmlr.getLocalName().equals("field")) {
						NamedData data = new NamedData();
						String value = null;
						int type = 0;
						for(int ix = 0; ix < xmlr.getAttributeCount(); ix++) {
							if(xmlr.getAttributeLocalName(ix).equals("name")) {
								data.setName(xmlr.getAttributeValue(ix));
							}
							if(xmlr.getAttributeLocalName(ix).equals("value")) {
								value = xmlr.getAttributeValue(ix);
							}
							if(xmlr.getAttributeLocalName(ix).equals("type")) {
								type = Integer.parseInt(xmlr.getAttributeValue(ix));
							}
						}
						switch(type) {
						case NamedData.DATA_TYPE_STRING:
							data.setValue(value);
							break;
						case NamedData.DATA_TYPE_INT:
							try {
								data.setValue(Integer.parseInt(value));
							} catch (NumberFormatException e) {
								if(value.indexOf("$R_", 0) == 0) {
									//�Q�Ə�񂩂�̎Q�Ə��ID�̎擾
									data.setValue(getReferenceID(value.substring(3)));
								}
								if(value.indexOf("$T_", 0) == 0) {
									//�e�[�u����񂩂�e�[�u�����ID�̎擾
									data.setValue(getTableID(value.substring(3)));
								}
							}
							break;
						case NamedData.DATA_TYPE_DATE:
							Calendar cal = new GregorianCalendar(new Locale("jp", "JP"));
							if(value.equals("$now")) {
								cal.setTime(new Date());
							}
							data.setValue(cal);
							break;
						case NamedData.DATA_TYPE_TEXT:
							data.setValue(value);
							data.setType(NamedData.DATA_TYPE_TEXT);
							break;
						}
						fieldList.add(data);
					}
					
					break;
					
				case XMLStreamConstants.END_ELEMENT:
					if(xmlr.getLocalName().equals("data")) {
						//���̓o�^
						StringBuffer sql = new StringBuffer();
						StringBuffer set = new StringBuffer();
						sql.append("INSERT INTO ").append(table.getTableName()).append(" ");
						sql.append("SET ");					
						for(NamedData data : fieldList) {
							if(set.length() > 0) {
								set.append(", ");
							}
							set.append(data.getName()).append(" = ");
							switch(data.getValueType()) {
							case NamedData.DATA_TYPE_STRING:
								set.append("'").append(data.getStringValue()).append("'");
								break;
							case NamedData.DATA_TYPE_INT:
								set.append(data.getIntValue());
								break;
							case NamedData.DATA_TYPE_DATE:
								set.append("'").append(sqlDatefmt.format(data.getDateValue().getTime())).append("'");
								break;
							case NamedData.DATA_TYPE_TEXT:
								set.append("'").append(data.getStringValue()).append("'");
							}
						}
						sql.append(set.toString());
						//DB�֒ǉ�
						executeDB(sql.toString());
					}
					break;
				}
			}
		} catch (UnsupportedEncodingException | FileNotFoundException | FactoryConfigurationError | XMLStreamException e) {
			e.printStackTrace();
		}
	}

	/**
	 * �e�[�u�����ID�擾<br>
	 * <p>�����̃e�[�u�������e�[�u�����ID���擾����B</p>
	 * TODO �{���\�b�h�͗Վ��I�ɖ{�N���X���ɒu�����B���K�̏ꏊ�ɂ��Ă͗v����(2020-02-24 ueno)
	 * @author ueno hideo
	 * @since 1.0 2020-02-24
	 * @param tableName �e�[�u����
	 * @return �e�[�u�����ID
	 */
	private int getTableID(String tableName) {
		int id = 0;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT OFN_Table_ID FROM OFN_Table ");
			sql.append("WHERE Table_Name = '").append(tableName).append("' ");
			ResultSet rs = queryDB(sql.toString());
			if(rs.next()) {
				id = rs.getInt("OFN_Table_ID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}

	/**
	 * �Q�Ə��ID�擾<br>
	 * <p>�����̎Q�Ə�񖼂��Q�Ə��ID���擾����B</p>
	 * TODO �{���\�b�h�͗Վ��I�ɖ{�N���X���ɒu�����B���K�̏ꏊ�ɂ��Ă͗v����(2020-02-24 ueno)
	 * @author ueno hideo
	 * @since 1.0 2020-02-24
	 * @param referenceName �Q�Ə��
	 * @return �Q�Ə��ID<br>
	 * �Q�Ɩ����o�^����Ă��Ȃ��ꍇ�́A0��Ԃ��B
	 */
	private int getReferenceID(String referenceName) {
		int id = 0;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT OFN_Reference_ID FROM OFN_Reference ");
			sql.append("WHERE Reference_Name = '").append(referenceName).append("' ");
			ResultSet rs = queryDB(sql.toString());
			if(rs.next()) {
				id = rs.getInt("OFN_Reference_ID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}

}
