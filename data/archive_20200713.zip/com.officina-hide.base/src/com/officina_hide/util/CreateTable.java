package com.officina_hide.util;

import java.util.ArrayList;
import java.util.List;

import com.officina_hide.model.ColumnData;
import com.officina_hide.model.DIF_Base;
import com.officina_hide.model.DIO_Base;
import com.officina_hide.model.TableData;

/**
 * �e�[�u����`<br>
 * @author ueno hideo
 * @version 1.0
 * @since 2020-03-10
 */
public class CreateTable extends DIO_Base implements DIF_Base {

	/**
	 * �R���X�g���N�^�[<br>
	 * @param tableName
	 */
	public CreateTable(String tableName) {
		//�e�[�u�����擾
		TableData table = new TableData(tableName);
		//�\�z�pSQL���쐬
		List<String> sqls = createSQL(table);
		for(String sql : sqls) {
			executeDB(sql);
		}
	}

	/**
	 * �\�z�pSQL���쐬<br>
	 * @author ueno hideo
	 * @since 1.0 2020-03-10
	 * @param table �e�[�u�����
	 * @return �\�z�pSQL��
	 */
	private List<String> createSQL(TableData table) {
		List<String> list = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		//�e�[�u���폜
		list.add(new StringBuffer().append("DROP TABLE IF EXISTS ").append(table.getTableName()).append("; ").toString());
		//�e�[�u���\�z
		 sql.append("CREATE TABLE IF NOT EXISTS ").append(table.getTableName()).append(" ");
		 sql.append("(");
		 StringBuffer column = new StringBuffer();
		 for(ColumnData cd : table.getColumns()) {
			 if(column.length() > 0) {
				 column.append(", ");
			 }
			 column.append(cd.getColumnName()).append(" ");
			 //���ڂ̑�����SQL�����R�[�g��蔻�肷��B
			 switch(cd.getSqlTypeCD()) {
			 case 1:	//���l(int unsigned)
			 case 4:	//���l(int unsigned)
			 case 5:	//���l(int unsigned)
				 column.append("INT UNSIGNED");
				 break;
			 case 2:	//�e�L�X�g
				 column.append("VARCHAR");
				 break;
			 case 3:	//���t
				 column.append("DATETIME");
				 break;
			 }
			  if(cd.getColumnSize() > 0) {
				  column.append("(").append(cd.getColumnSize()).append(")");
			  }
			  column.append(" ");
			  if(cd.getComment().length() > 0) {
				  column.append("COMMENT '").append(cd.getComment()).append("' ");
			  }
		 }
		 sql.append(column.toString()).append(")");
		 //�R�����g
		 sql.append("COMMENT '").append(table.getTableLogicalName()).append("' ");
		 list.add(sql.toString());
		return list;
	}
	
}
