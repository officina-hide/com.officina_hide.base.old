package com.officina_hide.base.setting;

import java.util.List;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.DIF_OFN_TableColumn;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIO_OFN_TableColumn;
import com.officina_hide.base.model.OFN_DB;
import com.officina_hide.base.model.OFN_WhereData;

/**
 * 画面項目展開処理<br>
 * <p>テーブル項目情報から画面表示用の項目情報を展開する。</p>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/05/18
 */
public class CreateViewItem extends OFN_DB {

	/**
	 * コンストラクター<br>
	 * @param env 環境情報
	 * @param tableID　テーブル情報ID
	 * @param viewID 画面情報ID
	 */
	public CreateViewItem(EnvData env, int tableID, int viewID) {
		 /*
		  * テーブル情報項目の一覧を取得する。
		  * テーブル情報項目は情報IDと並び順が900以上のものは、画面項目として自動展開しない。
		  */
		DIO_OFN_TableColumn otc = new DIO_OFN_TableColumn(env);
		OFN_WhereData where = new OFN_WhereData(DIF_OFN_TableColumn.COLUMNNAME_OFN_TABLE_ID, tableID);
		List<Integer> ids = otc.getIds(env, where);
		for(int id : ids) {
			DIO_OFN_TableColumn column = new DIO_OFN_TableColumn(env, id);
			//並び順が0または900以上の時は処理の対象としない。
			if(column.getColumn_Sort_Order() == 0 || column.getColumn_Sort_Order() >= 900) {
				continue;
			}
			//画面項目登録
			DIO_OFN_Fx_ViewItem ofv = new DIO_OFN_Fx_ViewItem(env);
			ofv.setOFN_Fx_View_ID(viewID);
			ofv.setFx_ViewItem_Name(column.getColumn_Name());
			ofv.setOFN_Name(column.getOFN_Name());
			// TODO 項目属性は仮設定(2020/05/20 ueno)
			ofv.setItem_Type_ID(getReferenceID(env, "FxItem_Text"));
			ofv.save();
		}
	}

}
