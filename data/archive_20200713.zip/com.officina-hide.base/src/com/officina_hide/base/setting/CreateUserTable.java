package com.officina_hide.base.setting;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.DIO_OFN_Table;
import com.officina_hide.base.model.OFN_DB;
import com.officina_hide.base.util.CreateModel;
import com.officina_hide.base.util.CreateTable;

/**
 * ユーザー情報テーブル生成<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/05/16
 */
public class CreateUserTable extends OFN_DB {

	/**
	 * テーブル名
	 */
	private static final String TABLE_NAME = "OFN_User";
	
	private int tableID;

	/**
	 * コンストラクター<br>
	 * @author ueno hideo
	 * @since 1.10 2020/05/16
	 * @param env 環境情報
	 */
	public CreateUserTable(EnvData env) {
		//ユーザー情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name(TABLE_NAME);
		dot.setOFN_Name("ユーザー情報");
		dot.setOFN_Comment("システムをユーザー利用するユーザーの情報をユーザー管理する。");
		dot.save();
		//テーブル情報ID保管
		tableID = dot.getOFN_Table_ID();
		//ユーザー情報テーブル項目登録
		addTableColumnData(env, dot.getOFN_Table_ID(), TABLE_NAME+"_ID", "情報ID", 0, "ユーザー情報ID", "ユーザー情報をユーザー識別するためのID", 0, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "User_Name", "テキスト", 100, "ユーザー名", "ユーザーを識別するための名称(ID)", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Password", "テキスト", 100, "パスワード", "ログイン時の認証で確認するパスワード", 20, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "ユーザー情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "ユーザー情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "ユーザー情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "ユーザー情報の更新者ID", 930, false);
		//ユーザー情報モデル生成
		new CreateModel(env, TABLE_NAME);
		//ユーザー情報テーブル生成
		new CreateTable(env, TABLE_NAME, dot.getOFN_Name());
	}

	/**
	 * @return tableID
	 */
	public int getTableID() {
		return tableID;
	}

}
