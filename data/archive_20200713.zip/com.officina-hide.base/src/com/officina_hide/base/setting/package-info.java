/**
 * システム設定用クラス
 * <p>システムに設定に必要にクラスを管理する。</p>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/05/16
 */
package com.officina_hide.base.setting;