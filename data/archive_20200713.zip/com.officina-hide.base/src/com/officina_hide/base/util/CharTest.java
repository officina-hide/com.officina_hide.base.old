package com.officina_hide.base.util;

import java.io.UnsupportedEncodingException;

public class CharTest {

	public static void main(String[] args) {
		try {
			byte[] st2 = {(byte) 207, (byte) 194};
			String sj = new String(st2, "UTF-8");

			System.out.println(sj.getBytes().length);
			
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

}
