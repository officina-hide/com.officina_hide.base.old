package com.officina_hide.base.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.DIF_OFN_Fx_View;
import com.officina_hide.base.model.DIO_OFN_Fx_View;
import com.officina_hide.base.model.OFI_DB;
import com.officina_hide.base.model.OFN_DB;
import com.officina_hide.base.model.OFN_WhereData;

/**
 * 画面表示クラス生成<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/04/30
 */
public class CreateViewClass extends OFN_DB implements OFI_DB {

	/**
	 * 画面名
	 */
	private String viewName;
	
	/**
	 * コンストラクタ－<br>
	 * @param env 環境情報
	 * @param viewName 画面名
	 */
	public CreateViewClass(EnvData env, String viewName) {
		this.viewName = viewName;
		importClassList = new ArrayList<String>();
		execute(env, viewName);
	}

	/**
	 * 画面表示クラス生成処理<br>
	 * @author ueno hideo
	 * @since 2020/05/02
	 * @param env 環境情報
	 * @param viewName　画面名
	 */
	private void execute(EnvData env, String viewName) {
		StringBuffer packageSource = new StringBuffer();
		StringBuffer source = new StringBuffer();
		StringBuffer importSource = new StringBuffer();
		//画面情報取得
		OFN_WhereData where = new OFN_WhereData();
		where.getWhere().append(DIF_OFN_Fx_View.COLUMNNAME_FX_VIEW_NAME).append(" = ").append(OFN_SQ).append(viewName).append(OFN_SQ);
		DIO_OFN_Fx_View ofv = new DIO_OFN_Fx_View(env, where);
		try {
			File file = new File(env.getFxViewPath()+"\\"+ofv.getFX_View_Name()+".java");
			FileWriter fw  = new FileWriter(file);
			//Package宣言
			packageSource.append("package " + env.getFxViewParent()).append(";").append(OFN_RETURN).append(OFN_RETURN);
			//クラス開始
			source.append("public class ").append(ofv.getFX_View_Name())
				.append(" implements ").append("DIF_OFN_Fx_View").append(" {").append(OFN_RETURN);
			addImportClass(importClassList, "com.officina_hide.base.model.DIF_OFN_Fx_View");
			//共通変数定義
			source.append(editComment("画面情報", 1));
			source.append(setTab(1)).append("private DIO_OFN_Fx_View ofv = null;").append(OFN_RETURN);
			source.append(editComment("環境情報", 1));
			source.append(setTab(1)).append("private EnvData env;").append(OFN_RETURN);
			source.append(editComment("画面名", 1));
			source.append(setTab(1)).append("private String viewName;").append(OFN_RETURN);
			source.append(OFN_RETURN);
			//コンストラクター生成
			source.append(createConstractor());
			//startメソッド生成
			source.append(createStartMethod(env, ofv));
			//クラス終了
			source.append("}").append(OFN_RETURN).append(OFN_RETURN);
			
			//インポート編集
			importSource = editImportClass(importClassList);
			
			fw.write(packageSource.toString() + importSource.toString() + source.toString());
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * コンストラクター生成<br>
	 * @author ueno hideo
	 * @since 2020/05/04
	 * @return 定義文字列
	 */
	private String createConstractor() {
		StringBuffer source = new StringBuffer();
		source.append(editComment("コンストラクター<br>", 1));
		//メソッド開始
		source.append(setTab(1)).append("public ").append(viewName).append("(EnvData env, String viewName) {").append(OFN_RETURN);
		//共通変数保存
		source.append(setTab(2)).append("this.env = env;").append(OFN_RETURN);
		source.append(setTab(2)).append("this.viewName = viewName;").append(OFN_RETURN);
		//画面情報取得
		source.append(setTab(2)).append("OFN_WhereData where = new OFN_WhereData();").append(OFN_RETURN);
		source.append(setTab(2)).append("where.getWhere().append(COLUMNNAME_FX_VIEW_NAME)")
			.append(".append(").append(OFN_DQ).append(" = ").append(OFN_SQ).append(OFN_DQ).append(")")
			.append(".append(viewName)")
			.append(".append(").append(OFN_DQ).append(OFN_SQ).append(OFN_DQ).append(");").append(OFN_RETURN);
		source.append(setTab(2)).append("ofv = new DIO_OFN_Fx_View(env, where);").append(OFN_RETURN);
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);
		
		addImportClass(importClassList, "com.officina_hide.base.EnvData");
		addImportClass(importClassList, "com.officina_hide.base.model.OFN_WhereData");
		addImportClass(importClassList, "com.officina_hide.base.model.DIO_OFN_Fx_View");
		return source.toString();
	}

	/**
	 * startメソッド生成<br>
	 * @author ueno hideo
	 * @since 2020/05/04
	 * @param env 環境情報
	 * @param ofv 画面情報
	 * @return 定義文字列
	 */
	private String createStartMethod(EnvData env, DIO_OFN_Fx_View ofv) {
		StringBuffer source = new StringBuffer();
		source.append(editComment("画面表示<br>", 1));
		//メソッド開始
		source.append(setTab(1)).append("public void start(Stage stage) throws Exception {").append(OFN_RETURN);
		//root設定
		source.append(setTab(2)).append("VBox root = new VBox();").append(OFN_RETURN);
		/*
		 * 項目情報設定<br>
		 * Fx画面項目情報の一覧を追加取得し、生成したnodeをrootの配下に紐付ける。
		 */
		source.append(setTab(2)).append("ViewItemData vim = new ViewItemData(env, viewName, stage);").append(OFN_RETURN);
		source.append(setTab(2)).append("root.getChildren().add(vim.getItemNodes());").append(OFN_RETURN);
		//画面表示
		source.append(setTab(2)).append("Scene scene = new Scene(root, ofv.getFX_View_Width(), ofv.getFX_View_Height());").append(OFN_RETURN);
		source.append(setTab(2)).append("stage.setScene(scene);").append(OFN_RETURN);
		source.append(setTab(2)).append("stage.setTitle(ofv.getOFN_Name());").append(OFN_RETURN);
		source.append(setTab(2)).append("stage.showAndWait();").append(OFN_RETURN);
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);

		addImportClass(importClassList, "javafx.stage.Stage");
		addImportClass(importClassList, "javafx.scene.Scene");
		addImportClass(importClassList, "javafx.scene.layout.VBox");
		addImportClass(importClassList, "com.officina_hide.fx.base.ViewItemData");
		return source.toString();
	}

}
