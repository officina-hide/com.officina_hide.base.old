/**
 * プロジェクトを維持するうえで必要なツールを提供する。<br>
 * <p>
 * 【English】<br>
 * Provide the tools needed to maintain the project.
 * </p>
 * @author ueno hideo
 * @version 1.10
 * @since 2020-04-07
 */
package com.officina_hide.base.util;