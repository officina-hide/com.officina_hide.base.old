package com.officina_hide.base.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.DIF_OFN_Fx_MenuItem;
import com.officina_hide.base.model.DIF_OFN_Fx_MenuProcess;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIO_OFN_Fx_MenuItem;
import com.officina_hide.base.model.DIO_OFN_Fx_MenuProcess;
import com.officina_hide.base.model.DIO_OFN_Fx_View;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIO_OFN_Reference;
import com.officina_hide.base.model.OFI_DB;
import com.officina_hide.base.model.OFN_DB;
import com.officina_hide.base.model.OFN_WhereData;

/**
 * Fx画面モデルクラス生成<br>
 * <p>Fx画面モデルクラスでは、画面項目の生成、画面制御、データベースモデルとの連携を行う。</p>
 * @author ueno hideo
 * @version 1.10
 * @since 2020/05/20
 */
public class CreateViewModel extends OFN_DB implements OFI_DB {

	/**
	 * 画面情報ID
	 */
	private int viewId;	
	
	/**
	 * コンストラクター<br>
	 * @author ueno hideo
	 * @since 2020/05/20
	 * @param env 環境情報 
	 * @param viewId 画面情報ID
	 */
	public CreateViewModel(EnvData env, int viewId) {
		/*
		 * fx.view.modelに画面モデルを作成する。
		 * getRoot : 画面でroot以下のノードを返す。
		 * get(itemName) : 画面項目の取得
		 * set(itemName) : 画面項目のセット
		 * save : 画面情報の保存
		 */
		StringBuffer packageSource = new StringBuffer();	//パッケージ
		StringBuffer importSource = new StringBuffer();		//インポート
		StringBuffer source = new StringBuffer();					//ソース
		importClassList = new ArrayList<String>();		//インポートリスト
		this.viewId = viewId;

		//画面情報取得
		DIO_OFN_Fx_View ofv = new DIO_OFN_Fx_View(env, viewId);
		//画面項目情報リスト取得
		List<Map<String, String>> itemList = getViewItemList(env, ofv.getOFN_Fx_View_ID());
		
		//モデルクラスファイル生成
		File file = new File(env.getFxViewPath()+"\\model\\"+"FXM_"+ofv.getFX_View_Name()+".java");
		try {
			FileWriter fw  = new FileWriter(file);
			//パッケージ宣言
			packageSource.append("package ").append(env.getFxViewParent()+".model;").append(OFN_RETURN).append(OFN_RETURN);
			//クラス開始
			source.append("public class FXM_" + ofv.getFX_View_Name() + " {").append(OFN_RETURN);
			//グローバル変数作成
			source.append(createVariable(itemList));
			//コンストラクター生成
			//source.append(createConstractor(env, itemList));
			//getRootメソッド作成
			source.append(createGetRootMethod(env, ofv));
			//getMenuメソッド作成(画面情報のメニュー情報IDが0以上の時）
			if(ofv.getOFN_Fx_Menu_ID() > 0) {
				source.append(createGetMenuMethod(env, ofv.getOFN_Fx_Menu_ID()));
			}
			//getItemメソッド生成(privateメソッド)
			source.append(createGetItemMethod(env, itemList));
			
			//クラス終了
			source.append("}").append(OFN_RETURN);
			
			//インポート編集
			importSource = editImportClass(importClassList);
			
			fw.write(packageSource.toString() + importSource.toString() + source.toString());
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 画面項目情報リスト取得<br>
	 * @author ueno hideo
	 * @since 2020/05/22
	 * @param env 環境情報
	 * @param viewId 画面情報ID
	 * @return 画面項目情報リスト(Map構造)
	 */
	private List<Map<String, String>> getViewItemList(EnvData env, int viewId) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		DIO_OFN_Fx_ViewItem ofv = new DIO_OFN_Fx_ViewItem(env);
		OFN_WhereData where = new OFN_WhereData(DIF_OFN_Fx_ViewItem.COLUMNNAME_OFN_FX_VIEW_ID	, viewId);
		List<Integer> ids = ofv.getIds(env, where);
		for(int id : ids) {
			DIO_OFN_Fx_ViewItem item = new DIO_OFN_Fx_ViewItem(env, id);
			Map<String, String> map =new HashMap<String, String>();
			map.put(DIF_OFN_Fx_ViewItem.COLUMNNAME_FX_VIEWITEM_NAME, item.getFx_ViewItem_Name());
			DIO_OFN_Reference typeRef = new DIO_OFN_Reference(env, item.getItem_Type_ID());
			map.put("Fx_Item_Type_Name",typeRef.getReference_Name());
			list.add(map);
		}
		return list;
	}

//	/**
//	 * コンストラクター生成<br>
//	 * <p>インスタンス時に</p>
//	 * @param env
//	 * @param itemList
//	 * @return
//	 */
//	private Object createConstractor(EnvData env, List<Map<String, String>> itemList) {
//		// TODO コンストラクタ－の利用については要検討(2020/05/22 ueno)
//		return null;
//	}

	/**
	 * グローバル変数定義<br>
	 * @author ueno hideo
	 * @since 2020/05/22
	 * @param itemList 画面項目リスト
	 * @return 定義文字列
	 */
	private String createVariable(List<Map<String, String>> itemList) {
		StringBuffer source = new StringBuffer();
		//ルートノード
		source.append(editComment("ルートノード", 1));
		source.append(setTab(1)).append("private VBox root = new VBox();").append(OFN_RETURN);
		addImportClass(importClassList, "javafx.scene.layout.VBox");

		//画面項目ノード
		for(Map<String, String> map : itemList) {
			if(map.get("Fx_Item_Type_Name").equals("FxItem_Text")) {
				source.append(setTab(1)).append("private TextField ")
					.append(map.get(DIF_OFN_Fx_ViewItem.COLUMNNAME_FX_VIEWITEM_NAME))
					.append(" = new TextField()").append(";").append(OFN_RETURN);
				addImportClass(importClassList, "javafx.scene.control.TextField");
			}
		}
		
		source.append(OFN_RETURN);
		return source.toString();
	}

	/**
	 * getRootメソッド作成<br>
	 * @author ueno hideo
	 * @since 2929/05/22
	 * @param env 環境情報
	 * @param view 画面情報
	 * @return 定義文字列
	 */
	private String createGetRootMethod(EnvData env, DIO_OFN_Fx_View view) {
		StringBuffer source = new StringBuffer();
		source.append(editComment("rootノードを返す。", 1));
		//メソッド開始
		source.append(setTab(1)).append("public Pane getRoot(EnvData env, Stage stage) {").append(OFN_RETURN);
		/*
		 * もし、画面情報のメニュー情報IDが0以上の時、メニューバーの設定を行う。
		 */
		if(view.getOFN_Fx_Menu_ID() > 0){
			source.append(setTab(2)).append("getMenu(env, stage, root);").append(OFN_RETURN);
		}
		//画面項目編集
		source.append(setTab(2)).append("getItem(root);").append(OFN_RETURN);
		//return
		source.append(setTab(2)).append("return root;").append(OFN_RETURN);
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);
		
		addImportClass(importClassList, "javafx.scene.layout.Pane");
		addImportClass(importClassList, "javafx.stage.Stage");
		addImportClass(importClassList, "com.officina_hide.base.EnvData");
		
		return source.toString();
	}

	/**
	 * getMenuメソッド作成<br>
	 * @author ueno hideo
	 * @since 1.10
	 * @param env 環境情報
	 * @param menuID メニュー情報ID
	 * @return 定義文字列
	 */
	private String createGetMenuMethod(EnvData env, int menuID) {
		StringBuffer source = new StringBuffer();
		source.append(editComment("画面メニューバー表示用Node取得", 1));
		//メソッド開始
		source.append(setTab(1)).append("private void getMenu(EnvData env, Stage stage, Pane root) {").append(OFN_RETURN);

		//メニューバー本体
		source.append(setTab(2)).append("MenuBar menubar = new MenuBar();").append(OFN_RETURN);
		source.append(setTab(2)).append("root.getChildren().add(menubar);").append(OFN_RETURN);
		
		//メニュー鵜目取得
		OFN_WhereData where = new OFN_WhereData(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENU_ID, menuID);
		DIO_OFN_Fx_MenuItem ofm = new DIO_OFN_Fx_MenuItem(env);
		List<Integer> ids = ofm.getIds(env, where);
		String parentMenuName = "";
		for(int id : ids) {
			DIO_OFN_Fx_MenuItem menuItem = new DIO_OFN_Fx_MenuItem(env, id);
			DIO_OFN_Reference dor = new DIO_OFN_Reference(env, menuItem.getMenuItem_Type_ID());
			String menuName = "menu_" + menuItem.getMenuItem_Name();
			if(dor.getReference_Name().equals("FxMenu_Group")) {
				source.append(setTab(2)).append("Menu ").append(menuName).append(" = ")
					.append("new Menu(").append(OFN_DQ).append(menuItem.getOFN_Name()).append(OFN_DQ).append(");").append(OFN_RETURN);
				source.append(setTab(2)).append("menubar.getMenus().add(").append(menuName).append(");").append(OFN_RETURN);
				parentMenuName = menuName;
			}
			if(dor.getReference_Name().equals("FxMenu_Item")) {
				//メニュー項目生成
				source.append(setTab(2)).append("MenuItem ").append(menuName).append(" = ")
					.append("new MenuItem(").append(OFN_DQ).append(menuItem.getOFN_Name()).append(OFN_DQ).append(");").append(OFN_RETURN);
				//親メニューへの紐づけ
				source.append(setTab(2)).append(parentMenuName).append(".getItems().add(").append(menuName).append(");").append(OFN_RETURN);
				//メニュープロセスの取得
				OFN_WhereData pwhere = new OFN_WhereData(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_FX_MENUITEM_ID, id);
				// TODO 複数プロセスには未対応
				DIO_OFN_Fx_MenuProcess process = new DIO_OFN_Fx_MenuProcess(env, pwhere);
				if(process.getOFN_Fx_Process_ID() > 0) {
					//プロセスの実行
					source.append(setTab(2)).append(menuName).append(".setOnAction(event->{").append(OFN_RETURN);
					source.append(setTab(3)).append("new ExecuteProcess(env, stage, ")
						.append(process.getOFN_Fx_Process_ID()).append(", ")
						.append(viewId)
						.append(");").append(OFN_RETURN);
					source.append(setTab(2)).append("});").append(OFN_RETURN);
				}
//				//Action生成
//				if(menuItem.getMenuAction_Type_ID() > 0) {
//					DIO_OFN_Reference actionType = new DIO_OFN_Reference(env, menuItem.getMenuAction_Type_ID());
//					if(actionType.getReference_Name().equals("FxAction_CloseWindow")) {
//						source.append(setTab(2)).append(menuName).append(".setOnAction(event->{").append(OFN_RETURN);
//						source.append(setTab(3)).append("stage.close();").append(OFN_RETURN);
//						source.append(setTab(2)).append("});").append(OFN_RETURN);
//					}
//				}
			}
		}
		
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);

		addImportClass(importClassList, "javafx.scene.layout.Pane");
		addImportClass(importClassList, "javafx.scene.control.MenuBar");
		addImportClass(importClassList, "javafx.scene.control.Menu");
		addImportClass(importClassList, "javafx.scene.control.MenuItem");
		addImportClass(importClassList, "javafx.stage.Stage");
		addImportClass(importClassList, "com.officina_hide.fx.process.ExecuteProcess");
		addImportClass(importClassList, "com.officina_hide.base.EnvData");
		
		return source.toString();
	}

	/**
	 * getItemメソッド作成<br>
	 * @author ueno hideo
	 * @since 2020/05/25
	 * @param env 環境情報
	 * @param itemList  画面項目リスト
	 * @return 定義文字列
	 */
	private String createGetItemMethod(EnvData env, List<Map<String, String>> itemList) {
		StringBuffer source = new StringBuffer();
		source.append(editComment("画面項目表示用Node取得", 1));
		//メソッド開始
		source.append(setTab(1)).append("private void getItem(Pane root) {").append(OFN_RETURN);
		
		int rowNo = 1;	//行番号
		DecimalFormat df = new DecimalFormat("row00");
		//画面項目紐付け
		for(Map<String, String> map : itemList) {
			//設定行生成
			source.append(setTab(2)).append("HBox ").append(df.format(rowNo))
				.append(" = new HBox();").append(OFN_RETURN);
			source.append(setTab(2)).append("root.getChildren().add(").append(df.format(rowNo)).append(");").append(OFN_RETURN);
			
			//項目生成
			if(map.get("Fx_Item_Type_Name").equals("FxItem_Text")) {
				source.append(setTab(2)).append(df.format(rowNo)).append(".getChildren().add(")
					.append("new Label(").append(OFN_DQ).append(map.get(DIF_OFN_Fx_ViewItem.COLUMNNAME_FX_VIEWITEM_NAME))
					.append(OFN_DQ).append("));").append(OFN_RETURN);
				source.append(setTab(2)).append(df.format(rowNo)).append(".getChildren().add(")
				.append(map.get(DIF_OFN_Fx_ViewItem.COLUMNNAME_FX_VIEWITEM_NAME)).append(");").append(OFN_RETURN);

				addImportClass(importClassList, "javafx.scene.control.Label");
			}
			
			rowNo++;
		}
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN);
		
		addImportClass(importClassList, "javafx.scene.layout.Pane");
		addImportClass(importClassList, "javafx.scene.layout.HBox");
		return source.toString();
	}

}
