package com.officina_hide.base.util;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.base.model.DIF_OFN_Fx_MenuItem;
import com.officina_hide.base.model.DIF_OFN_Fx_View;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewProcess;
import com.officina_hide.base.model.DIF_OFN_Table;
import com.officina_hide.base.model.DIO_OFN_Fx_View;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewParameter;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewProcess;
import com.officina_hide.base.model.DIO_OFN_Numbering;
import com.officina_hide.base.model.DIO_OFN_Table;
import com.officina_hide.base.model.OFI_DB;
import com.officina_hide.base.model.OFN_DB;

/**
 * 画面関連基本情報作成<br>
 * <p></p>
 * @author ueno hideo
 * @version 1.11
 * @since 1.11 2020/06/25
 */
public class CreateFxBase extends OFN_DB implements OFI_DB {

	/**
	 * 環境情報
	 */
	private EnvData env;
	
	public CreateFxBase(EnvData env) {
		this.env = env;
		execute();
	}

	/**
	 * 処理実行<br>
	 * @author ueno hideo
	 * @since 1.11 2020/06/27
	 */
	private void execute() {
		//リファレンス登録
		addReference();
		//画面情報テーブル生成
		createViewTable();
		//画面項目情報テーブル生成
		createViewItemTable();
		//画面プロセス情報テーブル生成
		createViewProcessTable();
		//画面プロセスパラメータテーブル生成
		createViewParameterTable("OFN_Fx_ViewParameter", "FX画面パラメータ情報");
		
		//ログイン画面情報登録
		int viewId = addViewData("OFN_FxLogin", "ログイン画面", "ユーザーIDとパスワードを入力して認証する画面", 0, 0, 300, 100);
		//総合メニュー画面情報登録
		int menuViewId = addViewData("OFN_MainMenu", "総合メニュー画面", "システムの各機能へ分岐するためのポータル画面", 0, 0, 400, 400);
		//ログイン画面項目登録
		addViewItemData(viewId, "User_ID", "ユーザーID", "認証の対象となるユーザーのID", "FxItem_Text", 1);
		addViewItemData(viewId, "User_Password", "パスワード", "認証の対象となるユーザーのパスワード", "FxItem_Password", 2);
		int FxLoginID = addViewItemData(viewId, "Login_Button", "ログイン", "認証を開始する。", "FxItem_Button", 3);
		int FxLoginCloseID = addViewItemData(viewId, "Cancel_Button", "キャンセル", "認証を中止して画面を閉じる。", "FxItem_Button", 3);
		//ログイン画面プロセス登録
		addViewProcessData(FxLoginID, "LoginProcess", "com.officina_hide.fx.process.FxLogin", 10);
		int gotoProcessId = addViewProcessData(FxLoginID, "GoToView", "com.officina_hide.fx.process.FxGoToView", 20);
		addViewProcessData(FxLoginCloseID, "WindowsClose", "com.officina_hide.fx.process.FxWindowClose", 10);
		//プロセスパラメータ登録
		addViewParameterData(gotoProcessId, "FxParameter_ViewID", "ViewID", menuViewId);
		
		
		
//		//ログイン情報画面設定
//		createFxLogin();
		//総合メニュー画面設定
		//ユーザー情報画面設定
		
		
	}

	/**
	 * リファレンス情報登録
	 */
	private void addReference() {
		addReferenceData(env, "FxItem_Text");
		addReferenceData(env, "FxItem_Password");
		addReferenceData(env, "FxItem_Button");
		addReferenceData(env, "FxParameter_ViewID");
	}

//	/**
//	 * ログイン画面設定<br>
//	 * @author ueno hideo
//	 * @since 1.11 2020/06/27
//	 */
//	private void createFxLogin() {
//		//ログイン画面情報登録
//		int viewId = addViewData("OFN_FxLogin", "ログイン画面", "ユーザーIDとパスワードを入力して認証する画面", 0, 0, 300, 200);
//		//ログイン画面項目登録
//		addViewItemData(viewId, "User_ID", "ユーザーID", "認証の対象となるユーザーのID", "FxItem_Text", 1);
//		addViewItemData(viewId, "User_Password", "パスワード", "認証の対象となるユーザーのパスワード", "FxItem_Password", 2);
//		addViewItemData(viewId, "Login_Button", "ログイン", "認証を開始する。", "FxItem_Button", 3);
//		addViewItemData(viewId, "Cancel_Button", "キャンセル", "認証を中止して画面を閉じる。", "FxItem_Button", 3);
//		//ログイン画面情報Viewモデル生成
//		
//	}

	/**
	 * Fx画面情報構築<br>
	 * @author ueno hideo
	 * @since 1.11 2020/06/27
	 */
	private void createViewTable() {
		//FX画面情報テーブル登録
		int tableId = addTableData(env, "OFN_Fx_View","FX画面情報","FX画面に関する情報を管理する。");
		//FX画面情報のテーブル項目情報追加
		addTableColumnData(env, tableId, "OFN_Fx_View_ID", "情報ID", 0, "FX画面情報ID", "FX画面情報を識別するためのID", 10, true);
		addTableColumnData(env, tableId, "FX_View_Name", "テキスト", 100, "Fx画面クラス名", "Fx画面のクラス名", 20, false);
		addTableColumnData(env, tableId, "OFN_Name", "テキスト", 100, "Fx画面名", "Fx画面の名称", 30, false);
		addTableColumnData(env, tableId, "OFN_Comment", "複数行テキスト", 0, "説明", "Fx画面の説明", 40, false);
		addTableColumnData(env, tableId, DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENU_ID
				, "情報ID", 0, "メニューID", "画面で使用するメニューバーの情報ID", 50, false);
		addTableColumnData(env, tableId, DIF_OFN_Table.COLUMNNAME_OFN_TABLE_ID
				, "情報ID", 0, "テーブル情報ID", "画面が紐づくテーブルの情報ID", 60, false);
		addTableColumnData(env, tableId, "Pre_Width", "自然数", 0, "画面幅初期値", "画面の表示幅の初期設定", 70, false);
		addTableColumnData(env, tableId, "Pre_Height", "自然数", 0, "画面高さ初期値", "画面の表示高の初期設定", 80, false);
		addTableColumnData(env, tableId, "OFN_Create", "日時", 0, "登録日", "FX画面情報の登録日", 900, false);
		addTableColumnData(env, tableId, "OFN_Created", "情報ID", 0, "登録者ID", "FX画面情報の登録者ID", 910, false);
		addTableColumnData(env, tableId, "OFN_Update", "日時", 0, "更新日", "FX画面情報の更新日", 920, false);
		addTableColumnData(env, tableId, "OFN_Updated", "情報ID", 0, "更新者ID", "FX画面情報の更新者ID", 930, false);
		//Fx画面情報モデル構築
		new CreateModel(env, "OFN_Fx_View");
		//Fx画面情報テーブル生成
		new CreateTable(env, DIF_OFN_Fx_View.Table_Name, "FX画面情報");
		//Fx画面情報採番情報登録
		addNumberingData(env, tableId, 0,100001);
	}

	/**
	 * Fx画面項目情報テーブル生成
	 * @author ueno hideo
	 * @since 1.10 2020/05/04
	 */
	private void createViewItemTable() {
		//FX画面項目情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_ViewItem");
		dot.setOFN_Name("FX画面項目情報");
		dot.setOFN_Comment("FX画面で表示する項目情報を管理する。");
		dot.save();
		//FX画面項目情報テーブル項目登録
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_ViewItem_ID", "情報ID", 0, "FX画面項目情報ID"
				, "FX画面に表示する項目情報を識別するためのID", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_View_ID", "情報ID", 0, "FX画面情報ID", "Fx画面項目が紐づく画面情報のID", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Fx_ViewItem_Name", "テキスト", 100, "FX画面項目名", "Fx画面項目の名称", 30, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Name", "テキスト", 100, "FX画面項目表示名", "Fx画面項目に対してタイトルとして使用される表示名", 40, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Item_Type_ID", "情報ID", 0, "FX画面項目属性ID", "Fx画面項目の属性を表すID(リファレンス情報ID)", 50, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Comment", "複数行テキスト", 0, "説明", "Fx画面項目に関する説明", 60, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Row_No", "自然数", 0, "行番号", "項目を表示する行番号", 70, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "FX画面情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "FX画面情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "FX画面情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "FX画面情報の更新者ID", 930, false);
		//Fx画面情報モデル構築
		new CreateModel(env, "OFN_Fx_ViewItem");
		//Fx画面項目情報テーブル構築
		new CreateTable(env, DIF_OFN_Fx_ViewItem.Table_Name, dot.getOFN_Name());
		//Fx画面情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();
	}

	/**
	 * Fx画面プロセス情報生成<br>
	 * @author ueno hideo
	 * @since 1.11 2020/07/06
	 */
	private void createViewProcessTable() {
		//FX画面項目情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_ViewProcess");
		dot.setOFN_Name("FX画面プロセス情報");
		dot.setOFN_Comment("FX画面の項目で使用するプロセスを管理する。");
		dot.save();
		//FX画面項目情報テーブル項目登録
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_ViewProcess_ID", "情報ID", 0, "FX画面プロセス情報ID"
				, "FX画面の項目に紐づくプロセスを識別するためのID", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_ViewItem_ID", "情報ID", 0, "Fx画面項目情報ID", "プロセスが紐づく項目の情報ID", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Process_Name", "テキスト", 100, "Fx画面プロセス名", "プロセスを識別するための名称", 30, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Process_Class_Name", "テキスト", 200, "処理クラス名", "プロセスを処理するクラスの識別名", 40, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Process_Sort_Order", "自然数", 0, "プロセス処理順", "プロセスを処理する順番を指定する。", 50, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "FX画面情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "FX画面情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "FX画面情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "FX画面情報の更新者ID", 930, false);
		//Fx画面情報モデル構築
		new CreateModel(env, "OFN_Fx_ViewProcess");
		//Fx画面項目情報テーブル構築
		new CreateTable(env, DIF_OFN_Fx_ViewProcess.Table_Name, dot.getOFN_Name());
		//Fx画面情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();
	}

	/**
	 * Fx画面パラメータ情報テーブル生成<br>
	 * @author ueno hideo
	 * @since 1.11 2020/07/13
	 * @param string テーブル名
	 * @param name テーブル表示名
	 */
	private void createViewParameterTable(String tableName, String name) {
		//Fx画面プロセスパラメータ登録
		int tableId = addTableData(env, tableName, name, "FX画面項目プロセスで使用するパラメータを管理する。");
		//Fx画面プロセスパラメータ項目登録
		addTableColumnData(env, tableId, tableName+"_ID", "情報ID", 0, "FX画面パラメータ情報ID"
				, "FX画面の項目プロセスに紐づくパラメータを識別するためのID", 10, true);
		addTableColumnData(env, tableId, "OFN_Fx_ViewProcess_ID", "情報ID", 0, "Fx画面プロセス情報ID", "パラメータが紐づく親のプロセスの情報ID", 20, false);
		addTableColumnData(env, tableId, "Parameter_Name", "テキスト", 100, "パラメータ識別名", "パラメータを識別するための名称", 30, false);
		addTableColumnData(env, tableId, "Parameter_Type_ID", "情報ID", 0, "パラメータ種別", "パラメータの内容を表す種別ID(リファレンス情報ID)", 40, false);
		addTableColumnData(env, tableId, "Parameter_Data_ID", "情報ID", 0, "パラメータ情報(情報ID)", "パラメータとして使用する情報（情報ID）", 50, false);
		addTableColumnData(env, tableId, "OFN_Create", "日時", 0, "登録日", "FX画面情報の登録日", 900, false);
		addTableColumnData(env, tableId, "OFN_Created", "情報ID", 0, "登録者ID", "FX画面情報の登録者ID", 910, false);
		addTableColumnData(env, tableId, "OFN_Update", "日時", 0, "更新日", "FX画面情報の更新日", 920, false);
		addTableColumnData(env, tableId, "OFN_Updated", "情報ID", 0, "更新者ID", "FX画面情報の更新者ID", 930, false);
		//Fx画面プロセスパラメータ情報モデル構築
		new CreateModel(env, tableName);
		//Fx画面プロセスパラメータ情報テーブル構築
		new CreateTable(env, DIO_OFN_Fx_ViewParameter.Table_Name, name);
		//Fx画面パラメータ情報採番登録
		addNumberingData(env, tableId, 0, 1000001);
	}

	/**
	 * Fx画面情報登録<br>
	 * @author ueno hideo
	 * @since 1.10 2020/05/07
	 * @param viewName 画面名
	 * @param name　画面表示名
	 * @param comment 画面説明
	 * @param width 表示幅
	 * @param height 表示高さ
	 * @param menuId メニュー情報ID
	 * @param tableID テーブル情報ID
	 * @param preWidth 画面幅初期値
	 * @param preHeight 画面高初期値
	 */
	private int addViewData(String viewName, String name, String comment, int menuId, int tableID, int preWidth, int preHeight) {
		DIO_OFN_Fx_View ofv = new DIO_OFN_Fx_View(env);
		ofv.setFX_View_Name(viewName);
		ofv.setOFN_Name(name);
		ofv.setOFN_Comment(comment);
		ofv.setOFN_Fx_Menu_ID(menuId);
		ofv.setOFN_Fx_View_ID(tableID);
		ofv.setPre_Width(preWidth);
		ofv.setPre_Height(preHeight);
		ofv.save();
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Information registration of ["+viewName+"] screen completed.");
		return ofv.getOFN_Fx_View_ID();
	}
	
	/**
	 * Fx画面項目情報登録<br>
	 * @author ueno hideo
	 * @since 2020/05/04
	 * @param id 画面情報ID
	 * @param viewItemName 画面項目名
	 * @param name　画面項目表示名
	 * @param comment 画面項目説明
	 * @param typeName 項目属性名
	 * @param rowNo 行番号
	 * @return 保存した画面項目の情報ID
	 */
	private int addViewItemData(int id, String viewItemName, String name, String comment, String typeName, int rowNo) {
		DIO_OFN_Fx_ViewItem fvi = new DIO_OFN_Fx_ViewItem(env);
		fvi.setOFN_Fx_View_ID(id);
		fvi.setFx_ViewItem_Name(viewItemName);
		fvi.setOFN_Name(name);
		fvi.setOFN_Comment(comment);
		fvi.setItem_Type_ID(getReferenceID(env, typeName));
		fvi.setRow_No(rowNo);
		fvi.save();
		return fvi.getOFN_Fx_ViewItem_ID();
	}

	/**
	 * Fx画面項目プロセス情報登録<br>
	 * @author ueno hideo
	 * @since 1.11 2020/07/06
	 * @param viewItemID 画面項目情報ID
	 * @param name プロセス名
	 * @param className 実行クラス名
	 * @param sort 処理順
	 * @return Fx画面項目プロセス情報ID
	 */
	private int addViewProcessData(int viewItemID, String name, String className, int sort) {
		DIO_OFN_Fx_ViewProcess fvp = new DIO_OFN_Fx_ViewProcess(env);
		fvp.setOFN_Fx_ViewItem_ID(viewItemID);
		fvp.setProcess_Name(name);
		fvp.setProcess_Class_Name(className);
		fvp.setProcess_Sort_Order(sort);
		fvp.save();
		return fvp.getOFN_Fx_ViewProcess_ID();
	}

	/**
	 * Fx画面パラメータ情報登録<br>
	 * @author ueno hideo
	 * @since 2020/07/13
	 * @param processId 画面プロセス情報Id
	 * @param name パラメータ名
	 * @param string 
	 * @param menuViewId 画面情報ID
	 */
	private void addViewParameterData(int processId, String type, String name, int id) {
		DIO_OFN_Fx_ViewParameter fvp = new DIO_OFN_Fx_ViewParameter(env);
		fvp.setOFN_Fx_ViewProcess_ID(processId);
		fvp.setParameter_Name(name);
		fvp.setParameter_Data_ID(id);
		fvp.setParameter_Type_ID(getReferenceID(env, type));
		fvp.save();
	}
}
