package com.officina_hide.base.util;

import java.util.Date;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.model.OFI_DB;
import com.officina_hide.base.model.OFN_DB;

/**
 * 基本情報テーブル構築<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020-04-07
 */
public class CreateBaseTable extends OFN_DB implements OFI_DB {
	
	/**
	 * コンストラクター<br>
	 * <p>インスタンス時に必要な情報テーブルの構築を行う。</p>
	 * @author ueno hideo
	 * @param env 
	 * @since 1.10 2020-04-07
	 */
	public CreateBaseTable(EnvData env) {
		System.out.println(new Date()+" : Start Create Base Table");

		//テーブル情報構築
		//テーブル情報Drop
		StringBuffer sql = new StringBuffer();
		sql.append("DROP TABLE IF EXISTS OFN_Table");
		executeDB(env, sql.toString());
		//テーブル情報構築
		sql = new StringBuffer();
		sql.append("CREATE TABLE IF NOT EXISTS OFN_Table  (");
		sql.append("OFN_Table_ID INT UNSIGNED NOT NULL PRIMARY KEY COMMENT 'テーブル情報ID'").append(",");
		sql.append("Table_Name Varchar(100)  COMMENT 'テーブル名'").append(",");
		sql.append("OFN_Name Varchar(100)  COMMENT 'テーブル論理名'").append(",");
		sql.append("OFN_COMMENT Text  COMMENT '説明'").append(",");
		sql.append("OFN_Create DATETIME  COMMENT '登録日'").append(",");
		sql.append("OFN_Created INT UNSIGNED  COMMENT '登録者ID'").append(",");
		sql.append("OFN_Update DATETIME  COMMENT '更新日'").append(",");
		sql.append("OFN_Updated INT UNSIGNED  COMMENT '更新者ID'");
		sql.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='テーブル情報'");
		executeDB(env, sql.toString());
		//テーブル項目情報Drop
		sql = new StringBuffer();
		sql.append("DROP TABLE IF EXISTS OFN_TableColumn");
		executeDB(env, sql.toString());
		//テーブル項目情報構築
		sql = new StringBuffer();
		sql.append("CREATE TABLE IF NOT EXISTS OFN_TableColumn  (");
		sql.append("OFN_TableColumn_ID INT UNSIGNED NOT NULL PRIMARY KEY COMMENT 'テーブル項目情報ID'").append(",");
		sql.append("OFN_Table_ID INT UNSIGNED NOT NULL COMMENT 'テーブル情報ID'").append(",");
		sql.append("Column_Name Varchar(100) NULL COMMENT 'テーブル項目名'").append(",");
		sql.append("Column_Type_ID INT UNSIGNED NOT NULL COMMENT 'テーブル項目種別ID（リファレンスID）'").append(",");
		sql.append("Column_Size INT UNSIGNED COMMENT 'テーブル項目桁数'").append(",");
		sql.append("OFN_Name Varchar(100)  COMMENT 'テーブル項目論理名'").append(",");
		sql.append("OFN_COMMENT Text  COMMENT '説明'").append(",");
		sql.append("Primary_Key_Check TINYINT(1) COMMENT 'プライマリーキー判定'").append(",");
		sql.append("Column_Sort_Order INT UNSIGNED COMMENT '項目並び順'").append(",");
		sql.append("OFN_Create DATETIME  COMMENT '登録日'").append(",");
		sql.append("OFN_Created INT UNSIGNED  COMMENT '登録者ID'").append(",");
		sql.append("OFN_Update DATETIME  COMMENT '更新日'").append(",");
		sql.append("OFN_Updated INT UNSIGNED  COMMENT '更新者ID'");
		sql.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='テーブル項目情報'");			
		executeDB(env, sql.toString());
		//採番情報Drop
		sql = new StringBuffer();
		sql.append("DROP TABLE IF EXISTS OFN_Numbering");
		executeDB(env, sql.toString());
		//採番情報構築
		sql = new StringBuffer();
		sql.append("CREATE TABLE IF NOT EXISTS OFN_Numbering  (");
		sql.append("OFN_Numbering_ID INT UNSIGNED NOT NULL COMMENT '採番情報ID'").append(",");
		sql.append("OFN_Table_ID INT UNSIGNED NOT NULL COMMENT 'テーブル情報ID'").append(",");
		sql.append("Current_Number INT UNSIGNED COMMENT '現在値'").append(",");
		sql.append("Start_Number INT UNSIGNED COMMENT '開始値'").append(",");
		sql.append("OFN_Create DATETIME  COMMENT '登録日'").append(",");
		sql.append("OFN_Created INT UNSIGNED  COMMENT '登録者ID'").append(",");
		sql.append("OFN_Update DATETIME  COMMENT '更新日'").append(",");
		sql.append("OFN_Updated INT UNSIGNED  COMMENT '更新者ID'");
		sql.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='採番情報'");
		executeDB(env, sql.toString());
		//リファレンス情報Drop
		sql = new StringBuffer();
		sql.append("DROP TABLE IF EXISTS OFN_Reference");
		executeDB(env, sql.toString());
		//リファレンス情報構築
		sql = new StringBuffer();
		sql.append("CREATE TABLE IF NOT EXISTS OFN_Reference  (");
		sql.append("OFN_Reference_ID INT UNSIGNED NOT NULL COMMENT 'リファレンス情報ID'").append(",");
		sql.append("Reference_Name Varchar(100) COMMENT 'リファレンス名'").append(",");
		sql.append("OFN_Create DATETIME  COMMENT '登録日'").append(",");
		sql.append("OFN_Created INT UNSIGNED  COMMENT '登録者ID'").append(",");
		sql.append("OFN_Update DATETIME  COMMENT '更新日'").append(",");
		sql.append("OFN_Updated INT UNSIGNED  COMMENT '更新者ID'");
		sql.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='リファレンス情報'");			
		executeDB(env, sql.toString());
		//リファレンスクラス情報Drop
		sql = new StringBuffer();
		sql.append("DROP TABLE IF EXISTS OFN_RefClass");
		executeDB(env, sql.toString());
		//リファレンスクラス情報構築
		sql = new StringBuffer();
		sql.append("CREATE TABLE IF NOT EXISTS OFN_RefClass  (");
		sql.append("OFN_RefClass_ID INT UNSIGNED NOT NULL COMMENT 'リファレンスクラス情報ID'").append(",");
		sql.append("OFN_Reference_ID INT UNSIGNED NOT NULL COMMENT 'リファレンス情報ID'").append(",");
		sql.append("Variable_Class Varchar(100) COMMENT 'リファレンス処理クラス名'").append(",");
		sql.append("OFN_Create DATETIME  COMMENT '登録日'").append(",");
		sql.append("OFN_Created INT UNSIGNED  COMMENT '登録者ID'").append(",");
		sql.append("OFN_Update DATETIME  COMMENT '更新日'").append(",");
		sql.append("OFN_Updated INT UNSIGNED  COMMENT '更新者ID'");
		sql.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='リファレンスクラス情報'");			
		executeDB(env, sql.toString());
		
		//採番情報登録
		addNumberData(env, 100001,1001,0,1001);		//テーブル情報
		addNumberData(env, 100002,1002,0,100001);	//テーブル項目情報
		addNumberData(env, 100004,1003,100006,100001);	//採番情報
		addNumberData(env, 100005,1004,0,100001);	//リファレンス情報
		addNumberData(env, 100006,1005,0,100001);	//リファレンスクラス情報
		//テーブル情報登録
		addTableData(env, getNewID(env, 1001), "OFN_Table", "テーブル情報","テーブルに関する情報を管理する。");
		addTableData(env, getNewID(env, 1001), "OFN_TableColumn", "テーブル項目情報","テーブルで使用する項目に課する情報を管理する。");
		addTableData(env, getNewID(env, 1001), "OFN_Numbering", "採番情報","テーブル毎に情報に対して付与する情報IDの採番を管理する。");
		addTableData(env, getNewID(env, 1001), "OFN_Reference", "リファレンス情報","システムで管理する項目の辞書としての管理を行う。");
		addTableData(env, getNewID(env, 1001), "OFN_RefClass", "リファレンスクラス情報","リファレンス情報に紐づく、クラス構築に関する情報を管理する。");
		//リファレンス情報登録
		addReferenceData(env, getNewID(env, getTableID(env, "OFN_Reference")), "情報ID");
		addReferenceData(env, getNewID(env, getTableID(env, "OFN_Reference")), "テキスト");
		addReferenceData(env, getNewID(env, getTableID(env, "OFN_Reference")), "自然数");
		addReferenceData(env, getNewID(env, getTableID(env, "OFN_Reference")), "複数行テキスト");
		addReferenceData(env, getNewID(env, getTableID(env, "OFN_Reference")), "日時");
		addReferenceData(env, getNewID(env, getTableID(env, "OFN_Reference")), "YESNO");
		//リファレンスクラス情報登録
		addRefClassData(env, "情報ID","com.officina_hide.base.model.OFN_Ref_int");
		addRefClassData(env, "テキスト","com.officina_hide.base.model.OFN_Ref_String");
		addRefClassData(env, "自然数","com.officina_hide.base.model.OFN_Ref_int");
		addRefClassData(env, "複数行テキスト","com.officina_hide.base.model.OFN_Ref_String");
		addRefClassData(env, "日時","com.officina_hide.base.model.OFN_Ref_Date");
		addRefClassData(env, "YESNO","com.officina_hide.base.model.OFN_Ref_Boolean");
		//テーブル項目登録
		addTableColumnData(env, "OFN_Table", "OFN_Table_ID", "情報ID", 0, "テーブル情報ID","テーブル情報を識別するためのID", 10, true);
		addTableColumnData(env, "OFN_Table", "Table_Name", "テキスト", 100, "テーブル名","テーブル情報の物理名", 20, false);
		addTableColumnData(env, "OFN_Table", "OFN_Name", "テキスト", 100,  "テーブル論理名","テーブル情報の論理名", 30, false);
		addTableColumnData(env, "OFN_Table", "OFN_Comment", "複数行テキスト", 0,  "説明","テーブル情報の説明",40, false);
		addTableColumnData(env, "OFN_Table", "OFN_Create", "日時", 0,  "登録日","テーブル情報の登録日", 900, false);
		addTableColumnData(env, "OFN_Table", "OFN_Created", "情報ID", 0,  "登録者ID","テーブル情報の登録者ID", 910, false);
		addTableColumnData(env, "OFN_Table", "OFN_Update", "日時", 0,  "更新日","テーブル情報の更新日", 920, false);
		addTableColumnData(env, "OFN_Table", "OFN_Updated", "情報ID", 0,  "更新者ID","テーブル情報の更新者ID", 930, false);

		addTableColumnData(env, "OFN_TableColumn", "OFN_TableColumn_ID", "情報ID", 0, "テーブル項目情報ID","テーブル項目情報を識別するためのID", 10, true);
		addTableColumnData(env, "OFN_TableColumn", "OFN_Table_ID", "情報ID", 0, "テーブル情報ID","テーブル項目情報が紐づくテーブル情報のID", 20, false);
		addTableColumnData(env, "OFN_TableColumn", "Column_Name", "テキスト", 100, "テーブル項目名","テーブル項目の物理名", 30, false);
		addTableColumnData(env, "OFN_TableColumn", "Column_Type_ID", "情報ID", 0, "テーブル項目種別ID（リファレンスID）","テーブル項目の属性を表すリファレンス情報ID", 40, false);
		addTableColumnData(env, "OFN_TableColumn", "Column_Size", "自然数", 0, "テーブル項目桁数","テーブル項目の桁数", 50, false);
		addTableColumnData(env, "OFN_TableColumn", "OFN_Name", "テキスト", 100, "テーブル項目論理名","テーブル項目の論理名" ,60, false);
		addTableColumnData(env, "OFN_TableColumn", "OFN_Comment", "複数行テキスト", 0,  "説明","テーブル項目情報の説明", 70, false);
		addTableColumnData(env, "OFN_TableColumn", "Primary_Key_Check", "YESNO", 0,  "プライマリーキー判定","当該の項目がプライマリーキーかどうかを判定する。", 80, false);
		addTableColumnData(env, "OFN_TableColumn", "Column_Sort_Order", "自然数", 0,  "項目並び順","一覧表示の時の項目の並び順", 90, false);
		addTableColumnData(env, "OFN_TableColumn", "OFN_Create", "日時", 0,  "登録日","テーブル項目情報の登録日", 900, false);
		addTableColumnData(env, "OFN_TableColumn", "OFN_Created", "情報ID", 0,  "登録者ID","テーブル項目情報の登録者ID", 910, false);
		addTableColumnData(env, "OFN_TableColumn", "OFN_Update", "日時", 0,  "更新日","テーブル項目情報の更新日", 920, false);
		addTableColumnData(env, "OFN_TableColumn", "OFN_Updated", "情報ID", 0,  "更新者ID","テーブル項目情報の更新者ID", 930, false);

		addTableColumnData(env, "OFN_Reference", "OFN_Reference_ID", "情報ID", 0, "リファレンス情報ID","リファレンス情報を識別するためのID", 10, true);
		addTableColumnData(env, "OFN_Reference", "Reference_Name", "テキスト", 100, "リファレンス情報名","リファレンス情報の名称", 20, false);
		addTableColumnData(env, "OFN_Reference", "OFN_Create", "日時", 0,  "登録日","リファレンス情報の登録日", 900, false);
		addTableColumnData(env, "OFN_Reference", "OFN_Created", "情報ID", 0,  "登録者ID","リファレンス情報の登録者ID", 910, false);
		addTableColumnData(env, "OFN_Reference", "OFN_Update", "日時", 0,  "更新日","リファレンス情報の更新日", 920, false);
		addTableColumnData(env, "OFN_Reference", "OFN_Updated", "情報ID", 0,  "更新者ID","リファレンス情報の更新者ID", 930, false);
		
		addTableColumnData(env, "OFN_RefClass", "OFN_RefClass_ID", "情報ID", 0, "リファレンスクラス情報ID","リファレンス情報に紐づくクラス情報を識別するためのID", 10, true);
		addTableColumnData(env, "OFN_RefClass", "OFN_Reference_ID", "情報ID", 0, "リファレンス情報ID","リファレンス情報を識別するためのID", 20, false);
		addTableColumnData(env, "OFN_RefClass", "Variable_Class", "テキスト", 100, "リファレンス処理クラス名","リファレンス情報を処理するためのクラス名", 30, false);
		addTableColumnData(env, "OFN_RefClass", "OFN_Create", "日時", 0,  "登録日","リファレンスクラス情報の登録日", 900, false);
		addTableColumnData(env, "OFN_RefClass", "OFN_Created", "情報ID", 0,  "登録者ID","リファレンスクラス情報の登録者ID", 910, false);
		addTableColumnData(env, "OFN_RefClass", "OFN_Update", "日時", 0,  "更新日","リファレンスクラス情報の更新日", 920, false);
		addTableColumnData(env, "OFN_RefClass", "OFN_Updated", "情報ID", 0,  "更新者ID","リファレンスクラス情報の更新者ID", 930, false);
		
		addTableColumnData(env, "OFN_Numbering", "OFN_Numbering_ID", "情報ID", 0, "採番情報ID","採番情報を識別するためのID", 10, true);
		addTableColumnData(env, "OFN_Numbering", "OFN_Table_ID", "情報ID", 0, "テーブル情報ID","採番情報の対象となるテーブル情報ID", 20, false);
		addTableColumnData(env, "OFN_Numbering", "Current_Number", "自然数", 0, "現在値","現在取られている採番番号", 30, false);
		addTableColumnData(env, "OFN_Numbering", "Start_Number", "自然数", 0, "開始値","最初に取られる採番番号", 40, false);
		addTableColumnData(env, "OFN_Numbering", "OFN_Create", "日時", 0,  "登録日","採番情報の登録日", 900, false);
		addTableColumnData(env, "OFN_Numbering", "OFN_Created", "情報ID", 0,  "登録者ID","採番情報の登録者ID", 910, false);
		addTableColumnData(env, "OFN_Numbering", "OFN_Update", "日時", 0,  "更新日","採番情報の更新日", 920, false);
		addTableColumnData(env, "OFN_Numbering", "OFN_Updated", "情報ID", 0,  "更新者ID","採番情報の更新者ID", 930, false);
}

	/**
	 * 採番情報登録<br>
	 * @param env　環境情報
	 * @param id 採番情報ID
	 * @param tableId テーブル情報ID
	 * @param currentNumber 現在値
	 * @param startNumber 開始値
	 */
	private void addNumberData(EnvData env, int id, int tableId, int currentNumber, int startNumber) {
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO OFN_Numbering SET ");
		sql.append("OFN_Numbering_ID = ").append(id).append(",");
		sql.append("OFN_Table_ID = ").append(tableId).append(",");
		sql.append("Current_Number = ").append(currentNumber).append(",");
		sql.append("Start_Number = ").append(startNumber).append(",");
		sql.append("OFN_Create = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Created = ").append(env.getSystemUserID()).append(",");
		sql.append("OFN_Update = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Updated = ").append(env.getSystemUserID());
		executeDB(env, sql.toString());
	}

	/**
	 * テーブル情報登録<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-09
	 * @param env 環境情報
	 * @param id テーブル情報ID
	 * @param tableName テーブル名
	 * @param name テーブル論理名
	 * @param comment 説明
	 */
	private void addTableData(EnvData env, int id, String tableName, String name, String comment) {
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO OFN_Table SET ");
		sql.append("OFN_Table_ID = ").append(id).append(",");
		sql.append("Table_Name = '").append(tableName).append("'").append(",");
		sql.append("OFN_Name = '").append(name).append("'").append(",");
		sql.append("OFN_Comment = '").append(comment).append("'").append(",");
		sql.append("OFN_Create = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Created = ").append(env.getSystemUserID()).append(",");
		sql.append("OFN_Update = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Updated = ").append(env.getSystemUserID());
		executeDB(env, sql.toString());
	}

	/**
	 * リファレンス情報登録<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-10
	 * @param env 環境情報
	 * @param id リファレンス情報ID
	 * @param referenceName リファレンス名
	 */
	private void addReferenceData(EnvData env, int id, String referenceName) {
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO OFN_Reference SET ");
		sql.append("OFN_Reference_ID = ").append(id).append(",");
		sql.append("Reference_Name = '").append(referenceName).append("'").append(",");
		sql.append("OFN_Create = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Created = ").append(env.getSystemUserID()).append(",");
		sql.append("OFN_Update = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Updated = ").append(env.getSystemUserID());
		executeDB(env, sql.toString());
	}

	/**
	 * リファレンスクラス情報登録<br>
	 * @param env 環境情報
	 * @param referenceName リファレンス情報名
	 * @param variableStrings　変数文字列
	 */
	private void addRefClassData(EnvData env, String referenceName, String variableStrings) {
		int id = getNewID(env, getTableID(env, "OFN_RefClass"));
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO OFN_RefClass SET ");
		sql.append("OFN_RefClass_ID = ").append(id).append(",");
		sql.append("OFN_Reference_ID = ").append(getReferenceID(env, referenceName)).append(",");
		sql.append("Variable_Class = ").append(OFN_SQ).append(variableStrings).append(OFN_SQ).append(",");
		sql.append("OFN_Create = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Created = ").append(env.getSystemUserID()).append(",");
		sql.append("OFN_Update = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Updated = ").append(env.getSystemUserID());
		executeDB(env, sql.toString());
	}

	/**
	 * テーブル項目情報登録<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-10
	 * @param env 環境情報
	 * @param tableName テーブル名
	 * @param columnName 項目名
	 * @param columnTypeID 項目種別ID
	 * @param name テーブル項目論理名
	 * @param comment 説明
	 * @param primaryKey プライマリーキー
	 */
	private void addTableColumnData(EnvData env, String tableName, String columnName, String columnType, int size
			,  String name, String comment, int sortOrder, boolean primaryKey) {
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO OFN_TableColumn SET ");
		sql.append("OFN_TableColumn_ID = ").append(getNewID(env, getTableID(env, "OFN_TableColumn"))).append(",");
		sql.append("OFN_Table_ID = ").append(getTableID(env, tableName)).append(",");
		sql.append("Column_Name = '").append(columnName).append("'").append(",");
		sql.append("Column_Type_ID = ").append(getReferenceID(env, columnType)).append(",");
		sql.append("Column_Size = ").append(size).append(",");
		sql.append("OFN_Name = '").append(name).append("'").append(",");
		sql.append("OFN_Comment = '").append(comment).append("'").append(",");
		sql.append("Column_Sort_Order = ").append(sortOrder).append(",");
		if(primaryKey == true) {
			sql.append("Primary_Key_Check = 1").append(",");
		} else {
			sql.append("Primary_Key_Check = 0").append(",");
		}
		sql.append("OFN_Create = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Created = ").append(env.getSystemUserID()).append(",");
		sql.append("OFN_Update = '").append(dateFormat.format(new Date())).append("'").append(",");
		sql.append("OFN_Updated = ").append(env.getSystemUserID());
		executeDB(env, sql.toString());
	}
}
