package com.officina_hide.base.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.base.model.DIF_OFN_RefClass;
import com.officina_hide.base.model.DIF_OFN_Reference;
import com.officina_hide.base.model.DIF_OFN_TableColumn;
import com.officina_hide.base.model.OFI_DB;
import com.officina_hide.base.model.OFN_DB;

/**
 * テーブル生成<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020-04-28
 */
public class CreateTable extends OFN_DB implements OFI_DB {

	/**
	 * コンストラクタ－<br>
	 * @author ueno hideo
	 * @since 2020-04-28
	 * @param env 環境情報
	 * @param tableName テーブル名
	 * @param name テーブル論理名(COMMENT)
	 */
	public CreateTable(EnvData env, String tableName, String name) {
		StringBuffer sql = new StringBuffer();
		//テーブル削除
		sql.append("DROP TABLE IF EXISTS ").append(tableName);
		executeDB(env, sql.toString());
		//テーブル作成
		List<Map<String,String>> columns = getColumnData(env, tableName);
		sql = new StringBuffer();
		sql.append("CREATE TABLE IF NOT EXISTS ").append(tableName);
		sql.append("(");
		StringBuffer items = new StringBuffer();	//項目用SQL文
		for(Map<String, String> map : columns) {
			if(items.length() > 0) {
				items.append(", ");
			}
			try {
				Class<?> cl = Class.forName(map.get(DIF_OFN_RefClass.COLUMNNAME_VARIABLE_CLASS).toString());
				Constructor<?> con = cl.getConstructor(new Class[] {List.class});
				Object obj = con.newInstance(new Object[] {importClassList});
				Method method = cl.getMethod("toTableCreateSQL", Map.class);
				items.append(method.invoke(obj, map).toString());
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException 
					| IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				e.printStackTrace();
			}
		}
		
		sql.append(items.toString()).append(")");
		if(name.length() > 0) {
			sql.append(" COMMENT ").append(OFN_SQ).append(name).append(OFN_SQ).append(" ");
		}
		executeDB(env, sql.toString());
		
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Table created : "+tableName);
	}

	/**
	 * テーブル項目情報一覧取得<br>
	 * @param env 環境情報
	 * @param tableName テーブル名
	 * @return テーブル項目情報一覧
	 */
	private List<Map<String, String>> getColumnData(EnvData env, String tableName) {
		List<Map<String, String>> list = new ArrayList<Map<String,String>>();
		StringBuffer sql = new StringBuffer();
		int tableID = getTableID(env, tableName);
		try {
			sql.append("SELECT * FROM OFN_TableColumn ");
			sql.append("LEFT JOIN OFN_Reference ON OFN_Reference.OFN_Reference_ID = OFN_TableColumn.Column_Type_ID ");
			sql.append("LEFT JOIN OFN_RefClass ON OFN_RefClass.OFN_Reference_ID = OFN_Reference.OFN_Reference_ID ");
			sql.append("WHERE ").append(DIF_OFN_TableColumn.COLUMNNAME_OFN_TABLE_ID).append(" = ").append(tableID).append(" ");
			sql.append("ORDER BY Column_Sort_Order");
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				Map<String, String> map = new HashMap<String, String>();
				map.put(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_NAME, rs.getString(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_NAME));
				map.put(DIF_OFN_RefClass.COLUMNNAME_VARIABLE_CLASS, rs.getString(DIF_OFN_RefClass.COLUMNNAME_VARIABLE_CLASS));
				map.put(DIF_OFN_Reference.COLUMNNAME_REFERENCE_NAME, rs.getString(DIF_OFN_Reference.COLUMNNAME_REFERENCE_NAME));
				map.put(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_SIZE, rs.getString(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_SIZE));
				map.put(DIF_OFN_TableColumn.COLUMNNAME_OFN_NAME, rs.getString(DIF_OFN_TableColumn.COLUMNNAME_OFN_NAME));
				if(rs.getInt(DIF_OFN_TableColumn.COLUMNNAME_PRIMARY_KEY_CHECK) == 1) {
					map.put(DIF_OFN_TableColumn.COLUMNNAME_PRIMARY_KEY_CHECK, "YES");
				} else {
					map.put(DIF_OFN_TableColumn.COLUMNNAME_PRIMARY_KEY_CHECK, "NO");
				}
				list.add(map);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

}
