package com.officina_hide.base.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.base.model.DIF_OFN_RefClass;
import com.officina_hide.base.model.DIF_OFN_TableColumn;
import com.officina_hide.base.model.OFI_DB;
import com.officina_hide.base.model.OFN_DB;
import com.officina_hide.base.model.OFN_JavaDocParam;

/**
 * テーブルモデル構築<br>
 * <p>履歴<br>
 * 1.10 新規作成<br>
 * 1.11 getIds()にorderを追加(2020/07/02 ueno)</p>
 * @author ueno hideo
 * @version 1.11
 * @since 1.10 2020-04-10
 */
public class CreateModel extends OFN_DB implements OFI_DB {

	/**
	 * 環境情報
	 */
	private EnvData env;
	/**
	 * テーブル名
	 */
	private String tableName;
	/**
	 * インポートリスト
	 */
	private List<String> importClassList;
	
	/**
	 * コンストラクター<br>
	 * <p>テーブル操作に必要なクラスを生成する。</p>
	 * <p>【English】<br>
	 * Generate the classes required for table operations.</p>
	 * @param env
	 * @param tableName
	 */
	public CreateModel(EnvData env, String tableName) {
		this.env = env;
		this.tableName = tableName;
		importClassList = new ArrayList<String>();
		//インターフェースクラス生成
		createInterface();
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Create Interface Class : "+tableName);
		//データモデルクラス生成
		createModelClass();
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Create I/O Class : "+tableName);
	}

	/**
	 * インターフェースクラス生成<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-10
	 */
	private void createInterface() {
		StringBuffer source = new StringBuffer();
		File file = new File(env.getModelPath()+"\\"+"DIF_"+tableName+".java");
		try {
			FileWriter fw  = new FileWriter(file);
			//Package宣言
			source.append("package ").append(env.getModelParent()).append(";").append(OFN_RETURN).append(OFN_RETURN);
			//インターフェースクラス開始
			source.append("public interface DIF_").append(tableName).append(" {").append(OFN_RETURN).append(OFN_RETURN);			
			//テーブル名定数
			source.append(editComment("テーブル名", 1));
			source.append(setTab(1)).append("public final String Table_Name = ")
				.append(OFN_DQ).append(tableName).append(OFN_DQ).append(";").append(OFN_RETURN).append(OFN_RETURN);
			//テーブル項目定数
			List<Map<String, String>> columns = getColumnData();
			for(Map<String, String> map : columns) {
				source.append(editComment(map.get("OFN_Name").toString(), 1));
				source.append(setTab(1)).append("public final String COLUMNNAME_").append(map.get("Column_Name").toString().toUpperCase())
					.append(" = ").append(OFN_DQ).append(map.get("Column_Name").toString()).append(OFN_DQ).append(";").append(OFN_RETURN);
				source.append(OFN_RETURN);
			}
			
			//インターフェースクラス終了
			source.append("}").append(OFN_RETURN);
			
			fw.write(source.toString());
			fw.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * データモデルクラス生成<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-15
	 */
	private void createModelClass() {
		StringBuffer packageSource = new StringBuffer();
		StringBuffer importSource = new StringBuffer();
		StringBuffer source = new StringBuffer();

		File file = new File(env.getModelPath()+"\\"+"DIO_"+tableName+".java");
		try {
			FileWriter fw  = new FileWriter(file);
			//Package宣言
			packageSource.append("package ").append(env.getModelParent()).append(";").append(OFN_RETURN).append(OFN_RETURN);
			//クラス開始
			source.append("public class DIO_").append(tableName).append(" extends OFN_DB implements OFI_DB").append(",")
				.append("DIF_").append(tableName).append(" ").append("{").append(OFN_RETURN);
			//共通変数定義
			source.append(setTab(1)).append("private EnvData env;").append(OFN_RETURN);
			source.append(OFN_RETURN);
			//コンストラクター(取得用)定義
			source.append(createConstractor());
			//テーブル項目定義0
			List<Map<String, String>> columns = getColumnData();
			for(Map<String, String> map : columns) {
				try {
					//変数定義
					Class<?> cl = Class.forName(map.get("Variable_Class").toString());
					Constructor<?> con = cl.getConstructor(new Class[] {List.class});
					Object obj = con.newInstance(new Object[] {importClassList});
					Method method = cl.getMethod("toVariableDefinitions", String.class, String.class);
					source.append(method.invoke(obj, map.get("Column_Name").toString(), map.get("OFN_Name").toString()).toString());
					//getter定義
					method = cl.getMethod("toGetterDefinition", String.class, String.class);
					source.append(method.invoke(obj, map.get("Column_Name").toString(), map.get("OFN_Name").toString()).toString());
					//setter定義
					method = cl.getMethod("toSetterDefinition", String.class, String.class);
					source.append(method.invoke(obj, map.get("Column_Name").toString(), map.get("OFN_Name").toString()).toString());
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException |
						IllegalAccessException | IllegalArgumentException | InvocationTargetException | InstantiationException e) {
					e.printStackTrace();
				}
			}
			//saveメソッド定義
			source.append(createSaveMethod());
			//id取得メソッド定義
			source.append(createIdsMethod());
			//loadメソッド定義
			source.append(createLoadMethod());
			
			//クラス終了
			source.append("}").append(OFN_RETURN);
			
			//インポート編集
			importSource = editImportClass(importClassList);
			
			fw.write(packageSource.toString() + importSource.toString() + source.toString());
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * データモデルクラスコンストラクター定義<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-22
	 * @return 定義文字列
	 */
	private String createConstractor() {
		StringBuffer source = new StringBuffer();
		//インスタンス化のみのコンストラクター
		source.append(setTab(1)).append("public DIO_").append(tableName).append("(EnvData env) {").append(OFN_RETURN);
		source.append(setTab(2)).append("this.env = env;").append(OFN_RETURN);
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);
		addImportClass(importClassList, "com.officina_hide.base.EnvData");
		
		//インスタンス化時に条件分で指定した情報を読取るコンストラクター生成
		source.append(setTab(1)).append("public DIO_").append(tableName)
			.append("(EnvData env, OFN_WhereData where) {").append(OFN_RETURN);
		source.append(setTab(2)).append("this.env = env;").append(OFN_RETURN);
		source.append(setTab(2)).append("List<Integer> ids = getIds(env, where);").append(OFN_RETURN);
		//idsの0件対応
		// TODO idsが0件の時（条件らマッチした情報が抽出できなかった時）の対応について要検討(2020/06/15 ueno)
		source.append(setTab(2)).append("if(ids.size() > 0) {").append(OFN_RETURN);
		source.append(setTab(3)).append("load(env, ids.get(0));").append(OFN_RETURN);
		source.append(setTab(2)).append("}").append(OFN_RETURN);
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);
		
		//インスタンス化時に情報IDで情報を取得するコンストラクター生成
		source.append(setTab(1)).append("public DIO_").append(tableName).append("(EnvData env, int id) {").append(OFN_RETURN);
		source.append(setTab(2)).append("this.env = env;").append(OFN_RETURN);
		source.append(setTab(2)).append("load(env, id);").append(OFN_RETURN);
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);
		
		addImportClass(importClassList, "java.util.List");
		return source.toString();
	}

	/**
	 * 保存メソッド定義<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-22
	 * @return 定義文字列
	 */
	private String createSaveMethod() {
		StringBuffer source = new StringBuffer();
		source.append(editComment(tableName + "を保存する。", 1));
		//メソッド開始
		source.append(setTab(1)).append("public void save() {").append(OFN_RETURN);
		//SQL文字列変数定義
		source.append(setTab(2)).append("StringBuffer sql = new StringBuffer();").append(OFN_RETURN);
		//新規登録判定
		source.append(setTab(2)).append("boolean isNewData = false;").append(OFN_RETURN);
		//新規情報ID取得
		source.append(setTab(2)).append("if(get").append(tableName.substring(0, 1))
			.append(tableName.substring(1)).append("_ID() == 0 ) {").append(OFN_RETURN);
		source.append(setTab(3)).append("set").append(tableName.substring(0, 1).toUpperCase())
			.append(tableName.substring(1)).append("_ID(")
			.append("getNewID(env, getTableID(env, ").append(OFN_DQ).append(tableName).append(OFN_DQ)
			.append(")));").append(OFN_RETURN);
		source.append(setTab(3)).append("isNewData = true;").append(OFN_RETURN);
		source.append(setTab(2)).append("}").append(OFN_RETURN);
		//追加・更新SQL分ヘッダー
		source.append(setTab(2)).append("if(isNewData) {").append(OFN_RETURN);
		source.append(setTab(3)).append("sql.append(").append(OFN_DQ).append("INSERT INTO ").append(OFN_DQ)
			.append(").append(DIF_").append(tableName).append(".Table_Name);").append(OFN_RETURN);
		source.append(setTab(3)).append("getOFN_Create().setTime(new Date());").append(OFN_RETURN);
		source.append(setTab(3)).append("getOFN_Update().setTime(new Date());").append(OFN_RETURN);
		source.append(setTab(3)).append("setOFN_Created(").append("env.getLoginUserID()").append(");").append(OFN_RETURN);
		source.append(setTab(3)).append("setOFN_Updated(").append("env.getLoginUserID()").append(");").append(OFN_RETURN);
		source.append(setTab(2)).append("} else {").append(OFN_RETURN);
		source.append(setTab(3)).append("sql.append(").append(OFN_DQ).append("UPDATE ").append(OFN_DQ)
			.append(").append(DIF_").append(tableName).append(".Table_Name);").append(OFN_RETURN);
		source.append(setTab(3)).append("getOFN_Update().setTime(new Date());").append(OFN_RETURN);
		source.append(setTab(3)).append("setOFN_Updated(").append("env.getLoginUserID()").append(");").append(OFN_RETURN);
		source.append(setTab(2)).append("}").append(OFN_RETURN);
		addImportClass(importClassList, "java.util.Date");
		//項目セット
		source.append(setTab(2)).append("sql.append(").append(OFN_DQ).append(" SET ").append(OFN_DQ).append(");").append(OFN_RETURN);
		List<Map<String, String>> columns = getColumnData();
		StringBuffer setItems = new StringBuffer();
		for(Map<String, String> map : columns) {
			if(setItems.length() > 0) {
				setItems.append(".append(").append(OFN_DQ).append(",").append(OFN_DQ).append(");").append(OFN_RETURN);
			}
			//項目の該当する属性クラスから保存用のSQL文字列を取得する。
			try {
				Class<?> cl = Class.forName(map.get("Variable_Class").toString());
				Constructor<?> con = cl.getConstructor(new Class[] {List.class});
				Object obj = con.newInstance(new Object[] {importClassList});
				Method method = cl.getMethod("toSaveSQL", String.class, String.class);
				setItems.append(method.invoke(obj, tableName, map.get("Column_Name").toString()));
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException
					| IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				e.printStackTrace();
			}
		}
		source.append(setItems.toString()).append(";").append(OFN_RETURN);

		//更新時の条件セット
		source.append(setTab(2)).append("if(isNewData == false) {").append(OFN_RETURN);
		source.append(setTab(3)).append("sql.append(").append(OFN_DQ).append(" WHERE ").append(OFN_DQ).append(")")
			.append(".append(DIF_").append(tableName).append(".").append("COLUMNNAME_").append(tableName.toUpperCase())
			.append("_ID)").append(".append(").append(OFN_DQ).append(" = ").append(OFN_DQ).append(")")
			.append(".append(").append("get").append(tableName.substring(0, 1).toUpperCase())
			.append(tableName.substring(1)).append("_ID").append("());").append(OFN_RETURN);
		source.append(setTab(2)).append("}").append(OFN_RETURN);
		
		//SQL実行
		source.append(setTab(2)).append("executeDB(env, sql.toString());").append(OFN_RETURN);
		
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);
		return source.toString();
	}

	/**
	 * ID取得メソッド定義<br>
	 * @author ueno hideo
	 * @since 1.10 2020/05/02
	 * @return 定義文字列
	 */
	private String createIdsMethod() {
		StringBuffer source = new StringBuffer();
		/*
		 * 1.11追加事項
		 * getIds(EnvData, OFN_WhereData)の従来版に
		 * getIds(EnvData, OFN_WhereData, OFN_OrderData)の並び順付きメソッドを追加する。
		 * 注) ディフォルトは並び順付きとし、従来版はOFN_OrderDataをnullにして新規版を呼び出す。
		 */
		//メソッド開始(条件、並び順)
		OFN_JavaDocParam param = new OFN_JavaDocParam();
		param.add("env", "環境情報");
		param.add("where", "抽出条件");
		param.add("order", "並び順");
		source.append(editComment("条件文に該当する情報のIDリストを取得する。<br>", 1, param));
		source.append(setTab(1)).append("public List<Integer> "
				+ "getIds(EnvData env, OFN_WhereData where, OFN_OrderData order) {").append(OFN_RETURN);
		//ID配列定義
		source.append(setTab(2)).append("List<Integer> ids = new ArrayList<Integer>();").append(OFN_RETURN);
		//SQL文編集
		source.append(setTab(2)).append("StringBuffer sql = new StringBuffer();").append(OFN_RETURN);
		source.append(setTab(2)).append("sql.append(").append(OFN_DQ).append("SELECT ").append(OFN_DQ).append(")")
			.append(".append(DIF_").append(tableName).append(".").append("COLUMNNAME_").append(tableName.toUpperCase()).append("_ID)")
			.append(".append(").append(OFN_DQ).append(" FROM ").append(OFN_DQ).append(")")
			.append(".append(DIF_").append(tableName).append(".Table_Name);").append(OFN_RETURN);
		source.append(setTab(2)).append("sql.append(").append(OFN_DQ).append(" WHERE ").append(OFN_DQ).append(")")
			.append(".append(where.toString())").append(";").append(OFN_RETURN);
		//Order文追条件
		source.append(setTab(2)).append("if(order != null) {").append(OFN_RETURN);
		source.append(setTab(3)).append("sql.append(").append(OFN_DQ).append(" ORDER BY ").append(OFN_DQ).append(")")
			.append(".append(order.toString())").append(";").append(OFN_RETURN);
		source.append(setTab(2)).append("}").append(OFN_RETURN);
		//SQL実行
		source.append(setTab(2)).append("try {").append(OFN_RETURN);
		source.append(setTab(3)).append("ResultSet rs = queryDB(env, sql.toString());").append(OFN_RETURN);
		source.append(setTab(3)).append("while(rs.next()) {").append(OFN_RETURN);
		source.append(setTab(4)).append("ids.add(rs.getInt(DIF_").append(tableName).append(".")
			.append("COLUMNNAME_").append(tableName.toUpperCase()).append("_ID));").append(OFN_RETURN);
		source.append(setTab(3)).append("}").append(OFN_RETURN);
		source.append(setTab(2)).append("} catch (SQLException e) {").append(OFN_RETURN);
		source.append(setTab(3)).append("e.printStackTrace();").append(OFN_RETURN);
		source.append(setTab(2)).append("}").append(OFN_RETURN);
		//return
		source.append(setTab(2)).append("return ids;").append(OFN_RETURN);
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);
		
		//メソッド開始(条件)
		param = new OFN_JavaDocParam();
		param.add("env", "環境情報");
		param.add("where", "抽出条件");
		source.append(editComment("条件文に該当する情報のIDリストを取得する。<br>", 1, param));
		source.append(setTab(1)).append("public List<Integer> "
				+ "getIds(EnvData env, OFN_WhereData where) {").append(OFN_RETURN);
		//return
		source.append(setTab(2)).append("return getIds(env, where, null);").append(OFN_RETURN);
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN).append(OFN_RETURN);
		
		addImportClass(importClassList, "java.util.List");
		addImportClass(importClassList, "java.util.ArrayList");
		addImportClass(importClassList, "java.sql.ResultSet");
		addImportClass(importClassList, "java.sql.SQLException");
		return source.toString();
	}

	/**
	 * データ取得(Load)メソッド定義<br>
	 * @author ueno hideo
	 * @since 2020/05/02
	 * @return 定義文字列
	 */
	private String createLoadMethod() {
		StringBuilder source = new StringBuilder();
		source.append(editComment("指定された情報IDを持つ情報を抽出する。<br>", 1));
		//メソッド開始
		source.append(setTab(1)).append("public boolean load(EnvData env, int id) {").append(OFN_RETURN);
		//取得判定用
		source.append(setTab(2)).append("boolean chk = false;").append(OFN_RETURN);
		//SQL編集
		source.append(setTab(2)).append("StringBuffer sql = new StringBuffer();").append(OFN_RETURN);
		source.append(setTab(2)).append("sql.append(").append(OFN_DQ).append("SELECT * FROM ").append(OFN_DQ).append(")")
			.append(".append(Table_Name);").append(OFN_RETURN);
		source.append(setTab(2)).append("sql.append(").append(OFN_DQ).append(" WHERE ").append(OFN_DQ).append(")")
			.append(".append(COLUMNNAME_").append(tableName.toUpperCase()).append("_ID)")
			.append(".append(").append(OFN_DQ).append(" = ").append(OFN_DQ).append(")")
			.append(".append(id);").append(OFN_RETURN);
		//SQL実行
		source.append(setTab(2)).append("try {").append(OFN_RETURN);
		source.append(setTab(3)).append("ResultSet rs = queryDB(env, sql.toString());").append(OFN_RETURN);
		source.append(setTab(3)).append("if(rs.next()) {").append(OFN_RETURN);

		//項目セット
		List<Map<String, String>> columns = getColumnData();
		StringBuilder setItems = new StringBuilder();
		for(Map<String, String> map : columns) {
			try {
				Class<?> cl = Class.forName(map.get("Variable_Class").toString());
				Constructor<?> con = cl.getConstructor(new Class[] {List.class});
				Object obj = con.newInstance(new Object[] {importClassList});
				Method method = cl.getMethod("toLoadSQL",  Map.class, int.class);
				setItems.append(method.invoke(obj, map, 4));
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException
					| IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				e.printStackTrace();
			}
		}
		source.append(setItems.toString());
		
		source.append(setTab(3)).append("}").append(OFN_RETURN);
		source.append(setTab(2)).append("} catch (SQLException e) {").append(OFN_RETURN);
		//エラー処理
		source.append(setTab(3)).append("env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, ")
			.append(OFN_DQ).append("SQL Execution Error !!").append(OFN_DQ).append(");").append(OFN_RETURN);
		source.append(setTab(2)).append("}").append(OFN_RETURN);
		//return
		source.append(setTab(2)).append("return chk;").append(OFN_RETURN);
		//メソッド終了
		source.append(setTab(1)).append("}").append(OFN_RETURN);

		addImportClass(importClassList, "java.sql.ResultSet");
		addImportClass(importClassList, "java.sql.SQLException");
		addImportClass(importClassList, "com.officina_hide.base.OFN_Logging");
		return source.toString();
	}

	/**
	 * テーブル項目情報取得<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-13
	 * @return テーブル項目情報リスト
	 */
	private List<Map<String, String>> getColumnData() {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		int tableID = getTableID(env, tableName);
		StringBuffer sql = new StringBuffer();
		try {
			sql.append("SELECT * FROM OFN_TableColumn ");
			sql.append("LEFT JOIN OFN_Reference ON OFN_Reference.OFN_Reference_ID = OFN_TableColumn.Column_Type_ID ");
			sql.append("LEFT JOIN OFN_RefClass ON OFN_RefClass.OFN_Reference_ID = OFN_Reference.OFN_Reference_ID ");
			sql.append("WHERE OFN_Table_ID = ").append(tableID).append(" ");
			sql.append("ORDER BY Column_Sort_Order");
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				Map<String, String> map = new HashMap<String, String>();
				map.put(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_NAME, rs.getString(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_NAME));
				map.put(DIF_OFN_TableColumn.COLUMNNAME_OFN_NAME, rs.getString(DIF_OFN_TableColumn.COLUMNNAME_OFN_NAME));
				map.put(DIF_OFN_RefClass.COLUMNNAME_VARIABLE_CLASS, rs.getString(DIF_OFN_RefClass.COLUMNNAME_VARIABLE_CLASS));
				list.add(map);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

}
