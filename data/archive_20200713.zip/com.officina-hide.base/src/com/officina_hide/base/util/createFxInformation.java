package com.officina_hide.base.util;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import com.officina_hide.base.model.DIF_OFN_Fx_Menu;
import com.officina_hide.base.model.DIF_OFN_Fx_MenuItem;
import com.officina_hide.base.model.DIF_OFN_Fx_MenuProcess;
import com.officina_hide.base.model.DIF_OFN_Fx_Process;
import com.officina_hide.base.model.DIF_OFN_Fx_View;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewAction;
import com.officina_hide.base.model.DIF_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIF_OFN_Table;
import com.officina_hide.base.model.DIO_OFN_Fx_Menu;
import com.officina_hide.base.model.DIO_OFN_Fx_MenuItem;
import com.officina_hide.base.model.DIO_OFN_Fx_MenuProcess;
import com.officina_hide.base.model.DIO_OFN_Fx_Process;
import com.officina_hide.base.model.DIO_OFN_Fx_View;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewAction;
import com.officina_hide.base.model.DIO_OFN_Fx_ViewItem;
import com.officina_hide.base.model.DIO_OFN_Numbering;
import com.officina_hide.base.model.DIO_OFN_Table;
import com.officina_hide.base.model.OFI_DB;
import com.officina_hide.base.model.OFN_DB;
import com.officina_hide.base.setting.CreateUserTable;
import com.officina_hide.base.setting.CreateViewItem;

/**
 * Fx画面用初期設定<br>
 * 1.11 新版を作成開始(2020/06/25)<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020-04-27
 * @deprecated
 */
public class createFxInformation extends OFN_DB implements OFI_DB {

	/**
	 * 環境情報
	 */
	private EnvData env;
	
	/**
	 * コンストラクタ－
	 * @param env 環境情報
	 */
	public createFxInformation(EnvData env) {
		this.env = env;
		execute();
	}

	/**
	 * 初期登録実施<br>
	 * @author ueno hideo
	 * @since 2020-05-27
	 */
	private void execute() {
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "FX画面初期設定　開始");
		//FX画面情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_View");
		dot.setOFN_Name("FX画面情報");
		dot.setOFN_Comment("FX画面に関する情報を管理する。");
		dot.save();
		//FX画面情報のテーブル項目情報追加
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_View_ID", "情報ID", 0, "FX画面情報ID", "FX画面情報を識別するためのID", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "FX_View_Name", "テキスト", 100, "Fx画面クラス名", "Fx画面のクラス名", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Name", "テキスト", 100, "Fx画面名", "Fx画面の名称", 30, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "FX_View_Width", "自然数", 0, "Fx画面幅初期値", "Fx画面の幅の初期設定値", 40, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "FX_View_Height", "自然数", 0, "Fx画面高さ初期値", "Fx画面の高さの初期設定値", 50, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Comment", "複数行テキスト", 0, "説明", "Fx画面の説明", 60, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENU_ID
				, "情報ID", 0, "メニューID", "画面で使用するメニューバーの情報ID", 70, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), DIF_OFN_Table.COLUMNNAME_OFN_TABLE_ID
				, "情報ID", 0, "テーブル情報ID", "画面が紐づくテーブルの情報ID", 80, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Pre_Width", "自然数", 0, "画面幅初期値", "画面の表示幅の初期設定", 90, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Pre_Height", "自然数", 0, "画面高さ初期値", "画面の表示高の初期設定", 100, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "FX画面情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "FX画面情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "FX画面情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "FX画面情報の更新者ID", 930, false);
		//Fx画面情報モデル構築
		new CreateModel(env, "OFN_Fx_View");
		//Fx画面情報テーブル生成
		new CreateTable(env, DIF_OFN_Fx_View.Table_Name, dot.getOFN_Name());
		//Fx画面情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();

		//Fx画面項目情報テーブル生成
		createFxItemTable();
		//Fx画面アクション情報テーブル生成
		createFxActionTable();
		//Fx画面メニュー情報テーブル生成
		createFxMenuTable();
		//Fx画面メニユー項目情報テーブル生成
		createFxMenuItemTable();
		//Fxプロセス情報テーブル生成
		createFxProcessTable();
		//Fxメニュー項目プロセス関連情報
		createFxMenuProcessTable();
		
//		//画面用リファレンス情報の登録
//		addReferenceData("FxItem_Text");
//		addReferenceData("FxItem_Password");
//		addReferenceData("FxItem_Button");
//		addReferenceData("FxAction_Process");
//		addReferenceData("FxMenu_Group");
//		addReferenceData("FxMenu_Item");
//		addReferenceData("FxAction_NextView");
//		addReferenceData("FxAction_CloseWindow");
//		addReferenceData("FxAction_SaveData");

		//ログイン画面情報登録
		int login = addViewData("Fx_Login","ログイン画面","ユーザー名とパスワードを入力し、認証時に次の画面を表示する。", 300, 200, 0, 0, 200, 100);
		//総合メニュー画面情報登録
		int menuId = addViewData("Fx_MainMenu","総合メニュー画面","プロジェクトで最初に表示されるポータル画面", 600, 500, 0, 0, 400, 300);
		
		//ログイン画面項目情報登録
		addViewItemData(login, "OFN_User_ID", "ユーザーID", "認証の対象となるユーザーのID", "FxItem_Text");
		addViewItemData(login, "OFN_Password", "パスワード", "認証の対象となるユーザーのパスワード", "FxItem_Password");
		int id = addViewItemData(login, "Login_Button", "ログイン", "ログイン認証を行うためのボタン", "FxItem_Button");
		//ログインボタン画面項目制御追加
		addViewItemActionData(id, 10, "FxAction_NextView", menuId);
		//ログイン画面表示クラス生成
		new CreateViewClass(env, "Fx_Login");
		
//		//総合メニュー画面表示クラス生成
//		new CreateViewClass(env, "Fx_MainMenu");
//		//ユーザー情報画面表示クラス生成
//		new CreateViewClass(env, "Fx_User");
		
		//総合メニューバー情報登録
		int mainMenuID = addMenuData("MainMenu", "共通の汎用的に使用するメニューバー");
		//総合メニュー画面にメニューバー情報を追加
		DIO_OFN_Fx_View fxMainMenu = new DIO_OFN_Fx_View(env, menuId);
		fxMainMenu.setOFN_Fx_Menu_ID(mainMenuID);
		fxMainMenu.save();
		
		//メインメニューバー項目登録
		addMenuItemData(mainMenuID, "System", "システム", "FxMenu_Group", "", 0);
		
		/*
		 * ユーザー情報画面の登録
		 * 1.ユーザー情報テーブル生成
		 * 2.ユーザー画面情報登録（対象テーブルとしてユーザー情報テーブルを指定）
		 * 3.テーブル項目の画面項目展開
		 * 4.ユーザー情報画面クラス生成
		 */
		//ユーザー情報テーブル生成
		CreateUserTable cut = new CreateUserTable(env);
		//ユーザー情報メニュー登録
		int userMenuID = addMenuData("UserMenu", "ユーザー情報画面のメニューバー");
		//画面閉じるプロセス登録
		int closeProcessID = addProcessData("Fx_WindowClose", "画面を閉じる。",  "本プロセスは、指定されたStageをCloseする。"
				, "com.officina_hide.fx.process.FxWindowClose", 0);
		//保存プロセス登録
		int dataSaveProcessID = addProcessData("Fx_DataSave", "画面情報保存", "画面情報を保存する。"
				, "com.officina_hide.fx.process.FxDataSave", 0);
		
		
		
		//ユーザーメニュー項目登録
		addMenuItemData(userMenuID, "File", "ファイル", "FxMenu_Group", "", 0);
		int saveMenuID = addMenuItemData(userMenuID, "Save", "保存", "FxMenu_Item", "FxAction_SaveData", 0);
		int exitMenuID = addMenuItemData(userMenuID, "Exit", "終了", "FxMenu_Item", "", 0);
		addMenuProcess(exitMenuID, closeProcessID, 10);
		addMenuProcess(saveMenuID, dataSaveProcessID, 10);
		//ユーザー情報画面登録
		int userId = addViewData("Fx_User","ユーザー情報画面","プロジェクトを利用するユーザーを登録する為の画面", 500, 400, userMenuID, cut.getTableID(), 300, 200);
		//ユーザー画面を表示するプロセス情報
		int userViewProcessID = addProcessData("Fx_NextView", "画面遷移", "本プロセスは指定された画面情報IDへ遷移するための処理を行う。"
				, "com.officina_hide.fx.process.FxNextView", userId);
		int userDataMenuID = addMenuItemData(mainMenuID, "UserData", "ユーザー情報", "FxMenu_Item", "FxAction_NextView", userId);
		addMenuItemData(mainMenuID, "Exit", "終了", "FxMenu_Item", "FxAction_CloseWindow", 0);
		//ユーザー画面表示プロセスの紐づけ
		addMenuProcess(userDataMenuID, userViewProcessID, 10);
		//ユーザー情報画面項目生成
		new CreateViewItem(env, cut.getTableID(), userId);

		//総合メニュー画面Viewモデル生成
		new CreateViewModel(env, menuId);
		//ユーザー情報画面Viewモデル生成
		new CreateViewModel(env, userId);
		
	}
 
	/**
	 * Fx画面情報登録<br>
	 * @author ueno hideo
	 * @since 2020/05/07
	 * @param viewName 画面名
	 * @param name　画面表示名
	 * @param comment 画面説明
	 * @param width 表示幅
	 * @param height 表示高さ
	 * @param menuId メニュー情報ID
	 * @param tableID テーブル情報ID
	 * @param preWidth 画面幅初期値
	 * @param preHeight 画面高初期値
	 */
	private int addViewData(String viewName, String name, String comment, int width, int height, int menuId, int tableID
			, int preWidth, int preHeight) {
		DIO_OFN_Fx_View ofv = new DIO_OFN_Fx_View(env);
		ofv.setFX_View_Name(viewName);
		ofv.setOFN_Name(name);
//		ofv.setFX_View_Width(width);
//		ofv.setFX_View_Height(height);
		ofv.setOFN_Comment(comment);
		ofv.setOFN_Fx_Menu_ID(menuId);
		ofv.setOFN_Fx_View_ID(tableID);
		ofv.setPre_Width(preWidth);
		ofv.setPre_Height(preHeight);
		ofv.save();
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Information registration of ["+viewName+"] screen completed.");
		return ofv.getOFN_Fx_View_ID();
	}
//
//	/**
//	 * リファレンス情報追加<br>
//	 * @author ueno hideo
//	 * @since 2020/05/05
//	 * @param referenceName リファレンス名
//	 */
//	private void addReferenceData(String referenceName) {
//		DIO_OFN_Reference dor = new DIO_OFN_Reference(env);
//		dor.setReference_Name(referenceName);
//		dor.save();
//	}

	/**
	 * Fx画面項目情報登録<br>
	 * @author ueno hideo
	 * @since 2020/05/04
	 * @param id 画面情報ID
	 * @param viewItemName 画面項目名
	 * @param name　画面項目表示名
	 * @param comment 画面項目説明
	 * @param typeName 
	 * @return 保存した画面項目の情報ID
	 */
	private int addViewItemData(int id, String viewItemName, String name, String comment, String typeName) {
		DIO_OFN_Fx_ViewItem fvi = new DIO_OFN_Fx_ViewItem(env);
		fvi.setOFN_Fx_View_ID(id);
		fvi.setFx_ViewItem_Name(viewItemName);
		fvi.setOFN_Name(name);
		fvi.setOFN_Comment(comment);
		fvi.setItem_Type_ID(getReferenceID(env, typeName));
		fvi.save();
		return fvi.getOFN_Fx_ViewItem_ID();
	}

	/**
	 * Fx画面項目制御情報登録
	 * @author ueno hideo
	 * @since 2020/05/07
	 * @param fxViewItemID
	 * @param seq 処理順序
	 * @param actionType 制御属性
	 * @param actionViewID 制御画面情報ID
	 */
	private void addViewItemActionData(int fxViewItemID, int seq, String actionType, int actionViewID) {
		DIO_OFN_Fx_ViewAction fva = new DIO_OFN_Fx_ViewAction(env);
		fva.setOFN_Fx_ViewItem_ID(fxViewItemID);
		fva.setOFN_Seq(seq);
		fva.setViewAction_Type_ID(getReferenceID(env, actionType));
		fva.setViewAction_View_ID(actionViewID);
		fva.save();
	}

	/**
	 * メニュー情報登録
	 * @param menuName メニュー名
	 * @param comment 説明
	 * @return メニュー情報ID
	 */
	private int addMenuData(String menuName, String comment) {
		DIO_OFN_Fx_Menu ofm = new DIO_OFN_Fx_Menu(env);
		ofm.setMenu_Name(menuName);
		ofm.setOFN_Comment(comment);
		ofm.save();
		return ofm.getOFN_Fx_Menu_ID();
	}

	/**
	 * Fxメニュー項目情報登録<br>
	 * @author ueno hideo
	 * @since 2020/05/10
	 * @param menuID メニュー情報ID
	 * @param menuItemName メニュー項目名
	 * @param menuItemDispName メニュー項目表示名
	 * @param actionType 項目制御種別
	 * @param viewID 遷移画面ID
	 * @param MenuItemType　メニュー項目属性
	 * @return 保管したFxメニュー項目情報の情報ID
	 */
	private int addMenuItemData(int menuID, String menuItemName, String menuItemDispName, String MenuItemType, String actionType, int viewID) {
		DIO_OFN_Fx_MenuItem fmn = new DIO_OFN_Fx_MenuItem(env);
		fmn.setOFN_Fx_Menu_ID(menuID);
		fmn.setMenuItem_Name(menuItemName);
		fmn.setOFN_Name(menuItemDispName);
		fmn.setMenuItem_Type_ID(getReferenceID(env, MenuItemType));
		fmn.setMenuAction_Type_ID(getReferenceID(env, actionType));
		fmn.setMenuAction_View_ID(viewID);
		fmn.save();
		return fmn.getOFN_Fx_MenuItem_ID();
	}

	/**
	 * メニュー項目プロセス関連情報追加
	 * @param menuItemID メニュー項目情報ID
	 * @param processID プロセス情報ID
	 * @param seq 処理順序
	 */
	private void addMenuProcess(int menuItemID, int processID, int seq) {
		DIO_OFN_Fx_MenuProcess ofm = new DIO_OFN_Fx_MenuProcess(env);
		ofm.setOFN_Fx_MenuItem_ID(menuItemID);
		ofm.setOFN_Fx_Process_ID(processID);
		ofm.setProcess_Seq(seq);
		ofm.save();
	}

	/**
	 * プロセス情報追加
	 * @param processName プロセス名
	 * @param name プロセス表示名
	 * @param procassClass プロセス処理クラス
	 * @param procassClass 
	 * @param viewId 画面ID
	 * @return プロセス情報ID
	 */
	private int addProcessData(String processName, String name, String comment, String procassClass, int viewId) {
		DIO_OFN_Fx_Process ofp = new DIO_OFN_Fx_Process(env);
		ofp.setProcess_Name(processName);
		ofp.setProcess_Class(procassClass);
		ofp.setOFN_Name(name);
		ofp.setOFN_Comment(comment);
		ofp.setView_ID(viewId);
		ofp.save();
		return ofp.getOFN_Fx_Process_ID();
	}

	/**
	 * Fx画面項目情報テーブル生成<br>
	 * @author ueno hideo
	 * @since 2020/05/04
	 */
	private void createFxItemTable() {
		//FX画面項目情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_ViewItem");
		dot.setOFN_Name("FX画面項目情報");
		dot.setOFN_Comment("FX画面で表示する項目情報を管理する。");
		dot.save();
		//FX画面項目情報テーブル項目登録
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_ViewItem_ID", "情報ID", 0, "FX画面項目情報ID"
				, "FX画面に表示する項目情報を識別するためのID", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_View_ID", "情報ID", 0, "FX画面情報ID", "Fx画面項目が紐づく画面情報のID", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Fx_ViewItem_Name", "テキスト", 100, "FX画面項目名", "Fx画面項目の名称", 30, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Name", "テキスト", 100, "FX画面項目表示名", "Fx画面項目に対してタイトルとして使用される表示名", 40, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Item_Type_ID", "情報ID", 0, "FX画面項目属性ID", "Fx画面項目の属性を表すID(リファレンス情報ID)", 50, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Comment", "複数行テキスト", 0, "説明", "Fx画面項目に関する説明", 60, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "FX画面情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "FX画面情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "FX画面情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "FX画面情報の更新者ID", 930, false);
		//Fx画面情報モデル構築
		new CreateModel(env, "OFN_Fx_ViewItem");
		//Fx画面項目情報テーブル構築
		new CreateTable(env, DIF_OFN_Fx_ViewItem.Table_Name, dot.getOFN_Name());
		//Fx画面情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();
	}

	/**
	 * Fx画面項目制御情報テーブル生成<br>
	 * @author ueno hideo
	 * @since 2020/05/05
	 */
	private void createFxActionTable() {
		//FX画面項目制御情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_ViewAction");
		dot.setOFN_Name("FX画面項目制御情報");
		dot.setOFN_Comment("FX画面で表示する項目の制御情報を管理する。");
		dot.save();
		//Fx画面項目制御情報テーブル項目の登録
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_ViewAction_ID", "情報ID", 0, "Fx画面項目制御情報ID"
				, "Fx画面で表示する項目を制御する情報の識別ID", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_ViewItem_ID", "情報ID", 0, "Fx画面項目情報ID", "項目制御情報が紐づく画面項目情報ID", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Seq", "自然数", 0, "画面項目情報処理順序", "項目制御の処理順序", 30, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "ViewAction_Type_ID", "情報ID", 0, "画面制御属性ID", "項目制御の属性(リファレンス情報ID)", 40, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "ViewAction_View_ID", "情報ID", 0, "制御対象画面情報ID", "項目制御で対象となる画面情報ID(Fx画面情報ID)", 50, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "Fx画面項目制御情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "Fx画面項目制御情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "Fx画面項目制御情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "Fx画面項目制御情報の更新者ID", 930, false);
		//Fx画面項目制御情報モデル構築
		new CreateModel(env, "OFN_Fx_ViewAction");
		//Fx画面項目制御情報テーブル構築
		new CreateTable(env, DIF_OFN_Fx_ViewAction.Table_Name, dot.getOFN_Name());
		//Fx画面情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();
	}

	/**
	 * メニュー情報テーブル生成<br>
	 * @author ueno hideo
	 * @since 2020/05/10
	 */
	private void createFxMenuTable() {
		//FX画面メニュー情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_Menu");
		dot.setOFN_Name("FX画面メニュー情報");
		dot.setOFN_Comment("FX画面で表示するメニューバーのヘッダー情報を管理する。");
		dot.save();
		//FX画面メニュー情報テーブル項目登録
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_Menu_ID", "情報ID", 0, "Fx画面メニュー情報ID"
				, "Fx画面で表示するメニュー情報を識別する為のID", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Menu_Name", "テキスト", 100, "メニュー名", "Fx画面で使用されるメニューの識別名", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Comment", "複数行テキスト", 0, "説明", "Fx画面メニュー情報に関する説明", 60, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "Fx画面メニュー情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "Fx画面メニュー情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "Fx画面メニュー情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "Fx画面メニュー情報の更新者ID", 930, false);
		//FX画面メニュー情報モデル構築
		new CreateModel(env, "OFN_Fx_Menu");
		//FX画面メニュー情報テーブル構築
		new CreateTable(env, DIF_OFN_Fx_Menu.Table_Name, dot.getOFN_Name());
		//FX画面メニュー情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();
		
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Create Table & Model : ["+DIF_OFN_Fx_Menu.Table_Name+"]");
	}

	/**
	 * メニュー項目情報テーブル生成<br>
	 * 
	 */
	private void createFxMenuItemTable() {
		//FX画面メニュー項目情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_MenuItem");
		dot.setOFN_Name("FX画面メニュー項目情報");
		dot.setOFN_Comment("FX画面で表示するメニューバーの項目情報を管理する。");
		dot.save();		
		//FX画面メニュー項目情報テーブル項目登録
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_MenuItem_ID", "情報ID", 0, "Fx画面メニュー項目情報ID"
				, "Fx画面で表示するメニューの項目情報を識別する為のID", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_Menu_ID", "情報ID", 0, "Fx画面メニュー情報ID"
				, "メニュー項目が紐づくメニュー情報のID", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "MenuItem_Name", "テキスト", 100, "メニュー項目名", "Fx画面メニューの項目名", 30, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "MenuItem_Type_ID", "情報ID", 0, "メニュー項目属性ID", "Fx画面メニューの項目属性(リファレンスID)", 40, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "MenuAction_Type_ID", "情報ID", 0, "メニュー項目制御ID"
				, "Fx画面メニューの項目iに関する制御情報ID(リファレンスID)", 50, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "MenuAction_View_ID", "情報ID", 0, "メニュー項目制御画面ID"
				, "Fx画面メニューの制御で関連するFx画面情報ID", 60, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Name", "テキスト", 100, "メニュー表示名", "メニュー表示名", 70, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "Fx画面メニュー項目情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "Fx画面メニュー項目情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "Fx画面メニュー項目情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "Fx画面メニュー項目情報の更新者ID", 930, false);
		//FX画面メニュー項目情報モデル構築
		new CreateModel(env, "OFN_Fx_MenuItem");
		//FX画面メニュー項目情報テーブル構築
		new CreateTable(env, DIF_OFN_Fx_MenuItem.Table_Name, dot.getOFN_Name());
		//FX画面メニュー項目情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();
	}

	/**
	 * Fxプロセス情報テーブル生成<br>
	 * @author ueno hideo
	 * @since 2020/05/13
	 */
	private void createFxProcessTable() {
		//Fxプロセス情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_Process");
		dot.setOFN_Name("FXプロセス情報");
		dot.setOFN_Comment("Fxで使用するプロセス情報を管理する。");
		dot.save();		
		//Fxプロセス情報テーブル項目登録
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_Process_ID", "情報ID", 0, "Fxプロセス情報ID"
				, "Fxで使用するプロセス情報を識別する為のID", 10, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Process_Name", "テキスト", 100, "プロセス名", "Fxプロセス情報の名称", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Process_Class", "テキスト", 200, "プロセスクラス", "Fxプロセスを実行するクラスURI", 30, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Name", "テキスト", 100, "Fxプロセス表示名"	, "Fxプロセスの表示名", 40, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Comment", "複数行テキスト", 0, "説明", "Fxプロセスの説明", 50, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "View_ID", "情報ID", 0, "画面情報ID", "遷移画面情報ID", 60, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "Fx画面メニュー項目情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "Fx画面メニュー項目情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "Fx画面メニュー項目情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "Fx画面メニュー項目情報の更新者ID", 930, false);
		//Fxプロセス情報モデル構築
		new CreateModel(env, "OFN_Fx_Process");
		//Fxプロセス情報テーブル構築
		new CreateTable(env,  DIF_OFN_Fx_Process.Table_Name, dot.getOFN_Name());
		//Fxプロセス情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();
	}

	/**
	 * Fxメニュー項目プロセス関連情報<br>
	 * @author ueno hideo
	 * @since 2020/06/08
	 */
	private void createFxMenuProcessTable() {
		//FxFxメニュー項目プロセス関連情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name("OFN_Fx_MenuProcess");
		dot.setOFN_Name("FXメニュー項目プロセス関連情報");
		dot.setOFN_Comment("メニュー項目で処理されるプロセス情報との関連を管理する。");
		dot.save();
		//Fxメニュー項目プロセス関連項目情報登録
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_MenuProcess_ID", "情報ID", 0, "Fxメニュー項目プロセス関連情報ID"
				, "メニュー項目プロセス関連情報を識別するためのID", 0, true);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_MenuItem_ID", "情報ID", 0, "Fxメニュー項目情報ID",  "プロセスに紐づくメニュー項目のID", 20, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Fx_Process_ID", "情報ID", 0, "Fxプロセス情報ID",  "メニュー項目に紐づくプロセス情報のID", 30, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "Process_Seq", "自然数", 0, "プロセス処理順",  "メニュー項目が選択された時に処理されるプロセスの実行順序", 40, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Create", "日時", 0, "登録日", "Fxメニュー項目プロセス関連項目情報の登録日", 900, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Created", "情報ID", 0, "登録者ID", "Fxメニュー項目プロセス関連項目情報の登録者ID", 910, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Update", "日時", 0, "更新日", "Fxメニュー項目プロセス関連項目情報の更新日", 920, false);
		addTableColumnData(env, dot.getOFN_Table_ID(), "OFN_Updated", "情報ID", 0, "更新者ID", "Fxメニュー項目プロセス関連項目情報の更新者ID", 930, false);
		//Fxプロセス情報モデル構築
		new CreateModel(env, "OFN_Fx_MenuProcess");
		//Fxプロセス情報テーブル構築
		new CreateTable(env,  DIF_OFN_Fx_MenuProcess.Table_Name, dot.getOFN_Name());
		//Fxプロセス情報採番情報登録
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(dot.getOFN_Table_ID());
		don.setCurrent_Number(0);
		don.setStart_Number(100001);
		don.save();
	}

}
