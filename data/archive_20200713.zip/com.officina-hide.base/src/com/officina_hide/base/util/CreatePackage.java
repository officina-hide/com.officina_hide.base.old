package com.officina_hide.base.util;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;

/**
 * パッケージの初期化処理を実施する。<br>
 * <p>履歴<br>
 * 1.10 新規作成<br>
 * 1.11 Fx画面の生成ロジックのリファクタリング</p>
 * @author ueno hideo
 * @version 1.11
 * @since 1.10 2020-04-07
 */
public class CreatePackage {

	/**
	 * main処理<br>
	 * <p>以下の処理を行う。</p>
	 * @param args
	 */
	public static void main(String[] args) {
		Date StartDate = new Date();
		
		//起動時に環境情報を取得する。
		// TODO 環境設定については、最終的に設定用のツールを作成する。(2020-04-07 ueno)
		EnvData env = new EnvData();
		env.setDB_Host("www.officina-hide.com");
		env.setDB_Name("datatest");
		env.setDB_User("root");
		env.setDB_Password("kan2*Sin");
		env.setSystemUserID(1000001);
		env.setLoginUserID(1000001);
		env.setModelParent("com.officina_hide.base.model");
		try {
			String currentPath = new File(".").getCanonicalPath();
			env.setModelPath(currentPath + "\\src\\com\\officina_hide\\base\\model");
			env.setDataPath(currentPath + "\\data");
			env.setFxViewPath(currentPath + "\\src\\com\\officina_hide\\fx\\view");
			env.setFxViewParent("com.officina_hide.fx.view");
		} catch (IOException e) {
			e.printStackTrace();
		}

		/**
		 * システムログ
		 */
		env.getLog().open(env, OFN_Logging.MODE_DEBUG, OFN_Logging.LOG_INITIALIZE);
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "Start Project Initialize");
	
		/*
		 * 基本となるテーブル情報を作成する。
		 * Create basic table information.
		 */
		new CreateBaseTable(env);
		//テーブル情報モデル構築
		new CreateModel(env, "OFN_Table");
		//テーブル項目情報モデル構築
		new CreateModel(env, "OFN_TableColumn");
		//リファレンス情報モデル構築
		new CreateModel(env, "OFN_Reference");
		//リファレンスクラス情報モデル構築
		new CreateModel(env, "OFN_RefClass");
		//採番情報モデル構築
		new CreateModel(env, "OFN_Numbering");
		
		//Fx画面情報追加(今までの整理版:1.11)
		new CreateFxBase(env);
		
//		//Fx画面情報追加
//		new createFxInformation(env);
		
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "E n d Create package");
		double startTime = StartDate.getTime();
		double endTime = new Date().getTime();
		double elapseTime = (endTime - startTime) / 1000;
		DecimalFormat df = new DecimalFormat("0.000");
		env.getLog().add(OFN_Logging.MESSAGE, OFN_Logging.NORMAL, "elapsed time " + df.format(elapseTime) + " Seconds");
	}
		
}
