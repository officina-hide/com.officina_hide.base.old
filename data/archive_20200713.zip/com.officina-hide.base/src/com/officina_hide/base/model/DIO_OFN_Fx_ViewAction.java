package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_Fx_ViewAction extends OFN_DB implements OFI_DB,DIF_OFN_Fx_ViewAction {
	private EnvData env;

	public DIO_OFN_Fx_ViewAction(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_Fx_ViewAction(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_Fx_ViewAction(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * Fx画面項目制御情報ID.<br>
	 */
	private int oFN_Fx_ViewAction_ID;
	/**
	 * Fx画面項目制御情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_ViewAction_ID() {
		return oFN_Fx_ViewAction_ID;
	}
	/**
	 * Fx画面項目制御情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_ViewAction_ID( int oFN_Fx_ViewAction_ID) {
		this.oFN_Fx_ViewAction_ID = oFN_Fx_ViewAction_ID;
	}
	/**
	 * Fx画面項目情報ID.<br>
	 */
	private int oFN_Fx_ViewItem_ID;
	/**
	 * Fx画面項目情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_ViewItem_ID() {
		return oFN_Fx_ViewItem_ID;
	}
	/**
	 * Fx画面項目情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_ViewItem_ID( int oFN_Fx_ViewItem_ID) {
		this.oFN_Fx_ViewItem_ID = oFN_Fx_ViewItem_ID;
	}
	/**
	 * 画面項目情報処理順序.<br>
	 */
	private int oFN_Seq;
	/**
	 * 画面項目情報処理順序を取得する。.<br>
	 */
	public int getOFN_Seq() {
		return oFN_Seq;
	}
	/**
	 * 画面項目情報処理順序をセットする。.<br>
	 */
	public void setOFN_Seq( int oFN_Seq) {
		this.oFN_Seq = oFN_Seq;
	}
	/**
	 * 画面制御属性ID.<br>
	 */
	private int viewAction_Type_ID;
	/**
	 * 画面制御属性IDを取得する。.<br>
	 */
	public int getViewAction_Type_ID() {
		return viewAction_Type_ID;
	}
	/**
	 * 画面制御属性IDをセットする。.<br>
	 */
	public void setViewAction_Type_ID( int viewAction_Type_ID) {
		this.viewAction_Type_ID = viewAction_Type_ID;
	}
	/**
	 * 制御対象画面情報ID.<br>
	 */
	private int viewAction_View_ID;
	/**
	 * 制御対象画面情報IDを取得する。.<br>
	 */
	public int getViewAction_View_ID() {
		return viewAction_View_ID;
	}
	/**
	 * 制御対象画面情報IDをセットする。.<br>
	 */
	public void setViewAction_View_ID( int viewAction_View_ID) {
		this.viewAction_View_ID = viewAction_View_ID;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_Fx_ViewActionを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_Fx_ViewAction_ID() == 0 ) {
			setOFN_Fx_ViewAction_ID(getNewID(env, getTableID(env, "OFN_Fx_ViewAction")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_Fx_ViewAction.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_Fx_ViewAction.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_FX_VIEWACTION_ID).append(" = ").append(getOFN_Fx_ViewAction_ID()).append(",");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_FX_VIEWITEM_ID).append(" = ").append(getOFN_Fx_ViewItem_ID()).append(",");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_SEQ).append(" = ").append(getOFN_Seq()).append(",");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_VIEWACTION_TYPE_ID).append(" = ").append(getViewAction_Type_ID()).append(",");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_VIEWACTION_VIEW_ID).append(" = ").append(getViewAction_View_ID()).append(",");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_FX_VIEWACTION_ID).append(" = ").append(getOFN_Fx_ViewAction_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_FX_VIEWACTION_ID).append(" FROM ").append(DIF_OFN_Fx_ViewAction.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_Fx_ViewAction.COLUMNNAME_OFN_FX_VIEWACTION_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_FX_VIEWACTION_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_Fx_ViewAction_ID(rs.getInt(COLUMNNAME_OFN_FX_VIEWACTION_ID));
				setOFN_Fx_ViewItem_ID(rs.getInt(COLUMNNAME_OFN_FX_VIEWITEM_ID));
				setOFN_Seq(rs.getInt(COLUMNNAME_OFN_SEQ));
				setViewAction_Type_ID(rs.getInt(COLUMNNAME_VIEWACTION_TYPE_ID));
				setViewAction_View_ID(rs.getInt(COLUMNNAME_VIEWACTION_VIEW_ID));
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
