package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_Fx_MenuProcess extends OFN_DB implements OFI_DB,DIF_OFN_Fx_MenuProcess {
	private EnvData env;

	public DIO_OFN_Fx_MenuProcess(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_Fx_MenuProcess(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_Fx_MenuProcess(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * Fxメニュー項目プロセス関連情報ID.<br>
	 */
	private int oFN_Fx_MenuProcess_ID;
	/**
	 * Fxメニュー項目プロセス関連情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_MenuProcess_ID() {
		return oFN_Fx_MenuProcess_ID;
	}
	/**
	 * Fxメニュー項目プロセス関連情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_MenuProcess_ID( int oFN_Fx_MenuProcess_ID) {
		this.oFN_Fx_MenuProcess_ID = oFN_Fx_MenuProcess_ID;
	}
	/**
	 * Fxメニュー項目情報ID.<br>
	 */
	private int oFN_Fx_MenuItem_ID;
	/**
	 * Fxメニュー項目情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_MenuItem_ID() {
		return oFN_Fx_MenuItem_ID;
	}
	/**
	 * Fxメニュー項目情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_MenuItem_ID( int oFN_Fx_MenuItem_ID) {
		this.oFN_Fx_MenuItem_ID = oFN_Fx_MenuItem_ID;
	}
	/**
	 * Fxプロセス情報ID.<br>
	 */
	private int oFN_Fx_Process_ID;
	/**
	 * Fxプロセス情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_Process_ID() {
		return oFN_Fx_Process_ID;
	}
	/**
	 * Fxプロセス情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_Process_ID( int oFN_Fx_Process_ID) {
		this.oFN_Fx_Process_ID = oFN_Fx_Process_ID;
	}
	/**
	 * プロセス処理順.<br>
	 */
	private int process_Seq;
	/**
	 * プロセス処理順を取得する。.<br>
	 */
	public int getProcess_Seq() {
		return process_Seq;
	}
	/**
	 * プロセス処理順をセットする。.<br>
	 */
	public void setProcess_Seq( int process_Seq) {
		this.process_Seq = process_Seq;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_Fx_MenuProcessを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_Fx_MenuProcess_ID() == 0 ) {
			setOFN_Fx_MenuProcess_ID(getNewID(env, getTableID(env, "OFN_Fx_MenuProcess")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_Fx_MenuProcess.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_Fx_MenuProcess.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_FX_MENUPROCESS_ID).append(" = ").append(getOFN_Fx_MenuProcess_ID()).append(",");
		sql.append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_FX_MENUITEM_ID).append(" = ").append(getOFN_Fx_MenuItem_ID()).append(",");
		sql.append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_FX_PROCESS_ID).append(" = ").append(getOFN_Fx_Process_ID()).append(",");
		sql.append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_PROCESS_SEQ).append(" = ").append(getProcess_Seq()).append(",");
		sql.append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_FX_MENUPROCESS_ID).append(" = ").append(getOFN_Fx_MenuProcess_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_FX_MENUPROCESS_ID).append(" FROM ").append(DIF_OFN_Fx_MenuProcess.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_Fx_MenuProcess.COLUMNNAME_OFN_FX_MENUPROCESS_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_FX_MENUPROCESS_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_Fx_MenuProcess_ID(rs.getInt(COLUMNNAME_OFN_FX_MENUPROCESS_ID));
				setOFN_Fx_MenuItem_ID(rs.getInt(COLUMNNAME_OFN_FX_MENUITEM_ID));
				setOFN_Fx_Process_ID(rs.getInt(COLUMNNAME_OFN_FX_PROCESS_ID));
				setProcess_Seq(rs.getInt(COLUMNNAME_PROCESS_SEQ));
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
