package com.officina_hide.base.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;

/**
 * データベース基本クラス<br>
 * <p>本クラスでは、データベースに関する共通する操作・項目を管理する。</p>
 * <p>【English】<br>
 * This class manages common operations and items related to the database.</p>
 * <p>履歴<br>
 * 1.10 新規作成<br>
 * 1.11 テーブル情報登録メソッド追加 addTableData()<br>
 * コメント編集にパラメータ追加  editComment()</p>
 * @author ueno hideo
 * @version 1.11 
 * @since 2020-04-09
 */
public class OFN_DB  implements OFI_DB {
	/**
	 * インポート対象クラスリスト
	 */
	public List<String> importClassList;
	/**
	 * データベース接続情報
	 */
	protected static Connection conn = null;
	/**
	 * 日付書式変数
	 */
	protected SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

	/**
	 * データベース接続
	 * @param env
	 */
	public void DBConnect(EnvData env) {
		if(conn == null) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				StringBuffer url  = new StringBuffer().append("jdbc:mysql://")
						.append(env.getDB_Host())
						.append(":3306/")
						.append(env.getDB_Name());
				conn = DriverManager.getConnection(url.toString(), env.getDB_User(), env.getDB_Password());
				env.getLog().add(OFN_Logging.DB, OFN_Logging.NORMAL, "Database Connected.");
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * SQL実行<br>
	 * @param env 環境情報
 	 * @param sql SQL文
	 */
	public void executeDB(EnvData env, String sql) {
		Statement stmt = null;
		try {
			DBConnect(env);
			stmt = conn.createStatement();
			stmt.execute(sql);
			env.getLog().add(OFN_Logging.DB, OFN_Logging.NORMAL, sql.toString());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * SQL実行(選択)<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-10
	 * @param env 環境情報
	 * @param sql SQL文
	 * @return 検索結果
	 * @throws SQLException SQL実行エラーをThrowする。
	 */
	public ResultSet queryDB(EnvData env, String sql) throws SQLException {
		ResultSet rs = null;
		Statement stmt = null;
		DBConnect(env);
		stmt = conn.createStatement();
		rs = stmt.executeQuery(sql);
		env.getLog().add(OFN_Logging.DB, OFN_Logging.NORMAL, sql.toString());
		return rs;
	}

	/**
	 * タブセット<br>
	 * <p>指定されたカウント数のタブをセットする。</p>
	 * @param tabCount セットタブ数
	 * @return タブ文字列
	 */
	public String setTab(int tabCount) {
		StringBuffer source = new StringBuffer();
		for(int ix = 0 ; ix < tabCount; ix++) {
			source.append(OFN_TAB);
		}
		return source.toString();
	}


	/**
	 * テーブル名よりテーブル情報ID取得する。<br>
	 * TODO 本メソッドは汎用化の対象(2020-04-10 ueno)
	 * @author ueno hideo
	 * @since 1.10 2020-04-10
	 * @param env 環境情報
	 * @param tableName テーブル名
	 * @return テーブル情報ID
	 */
	public int getTableID(EnvData env, String tableName) {
		int tableID = 0;
		StringBuffer sql = new StringBuffer();
		try {
			sql.append("SELECT OFN_Table_ID FROM OFN_Table ");
			sql.append("WHERE Table_Name = ").append(OFN_SQ).append(tableName).append(OFN_SQ);
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				tableID = rs.getInt("OFN_Table_ID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tableID;
	}

	/**
	 * コメント編集<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-12
	 * @param title タイトル
	 * @param tabCount タブ位置
	 * @return コメント文字列
	 */
	public String editComment(String title, int tabCount) {
//		StringBuffer source = new StringBuffer();
//		source.append(setTab(tabCount)).append("/**").append(OFN_RETURN);
//		source.append(setTab(tabCount)).append(" * ").append(title).append(".<br>").append(OFN_RETURN);
//		source.append(setTab(tabCount)).append(" */").append(OFN_RETURN);
		return editComment(title, tabCount, null);
	}

	/**
	 * コメント編集<br>
	 * @author ueno hideo
	 * @since 1.11 2020/07/02
	 * @param title タイトル
	 * @param tabCount タブ位置
	 * @param param パラメータ
	 * @return コメント文字列
	 */
	public String editComment(String title, int tabCount, OFN_JavaDocParam param) {
		StringBuffer source = new StringBuffer();
		source.append(setTab(tabCount)).append("/**").append(OFN_RETURN);
		source.append(setTab(tabCount)).append(" * ").append(title).append(".<br>").append(OFN_RETURN);
		//パラメータ追加
		if(param != null && param.length() > 0) {
			source.append(param.getJavadocOfParam(tabCount));
		}
		source.append(setTab(tabCount)).append(" */").append(OFN_RETURN);
		return source.toString();
	}

	/**
	 * 新規情報ID取得<br>
	 * <p>テーブル情報IDを持った採番情報より最新の採番値を取得する。</p>
	 * @author ueno hideo
	 * @since 1.10 2020-04-10
	 * @param env 環境情報
	 * @param tableID
	 * @return
	 * TODO 本メソッドは汎用化の対象(2020-04-10 ueno)
	 */
	public int getNewID(EnvData env, int tableID) {
		StringBuffer sql = new StringBuffer();
		int newID = 0;
		try {
			sql.append("SELECT Current_Number, Start_Number FROM OFN_Numbering ");
			sql.append("WHERE OFN_Table_ID = ").append(tableID);
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				//採番値算出
				if(rs.getInt("Current_Number") == 0) {
					newID = rs.getInt("Start_Number");
				} else {
					newID = rs.getInt("Current_Number") + 1;
				}
				//採番値更新
				sql = new StringBuffer();
				sql.append("UPDATE OFN_Numbering SET ");
				sql.append("Current_Number = ").append(newID).append(",");
				sql.append("OFN_Update = '").append(dateFormat.format(new Date())).append("'").append(",");
				sql.append("OFN_Updated = ").append(env.getSystemUserID()).append(" ");
				sql.append("WHERE OFN_Table_ID = ").append(tableID);
				executeDB(env, sql.toString());
			}
			
		} catch (SQLException e) {  
			e.printStackTrace();
		}
		return newID;
	}
	
	/**
	 * インポート用クラス追加<br>
	 * TODO OFN_DBへ移行予定(2020/04/20 ueno)
	 * @author ueno hideo
	 * @since 2020-04-20
	 * @param importClassList インポートクラス一覧
	 * @param className クラス名
	 */
	public void addImportClass(List<String> importClassList, String className) {
		boolean isSee = false;		//追加スイッチ
		for(String clazz : importClassList) {
			if(clazz.equals(className)) {
				isSee = true;
				break;
			}
		}
		if(isSee == false) {
			importClassList.add(className);
		}
	}

	/**
	 * リファレンス情報ID取得<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-10
	 * @param env 環境情報
	 * @param referenceName リファレンス名
	 * @return リファレンス情報ID
	 */
	public int getReferenceID(EnvData env, String referenceName) {
		int referenceID = 0;
		StringBuffer sql = new StringBuffer();
		try {
			sql.append("SELECT OFN_Reference_ID FROM OFN_Reference ");
			sql.append("WHERE Reference_Name = ").append(OFN_SQ).append(referenceName).append(OFN_SQ).append(" ");
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				referenceID = rs.getInt("OFN_Reference_ID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return referenceID;
	}

	/**
	 * インポートクラス編集<br>
	 * <p>リストの対象クラスは昇順に並び替えて出力される。</p>
	 * @author ueno hideo
	 * @since 2020-04-21
	 * @param importClassList　インサート対象クラスリスト
	 * @return インサート文字列
	 */
	public StringBuffer editImportClass(List<String> importClassList) {
		StringBuffer source = new StringBuffer();
		Collections.sort(importClassList);
		for(String clazz : importClassList) {
			source.append("import ").append(clazz).append(";").append(OFN_RETURN);
		}
		if(source.length() > 0) {
			source.append(OFN_RETURN);
		}
		return source;
	}


	/**
	 * テーブル情報追加<br>
	 * @author ueno hideo
	 * @since 1.10 2020/06/27
	 * @param env 環境情報
	 * @param tableName テーブル名
	 * @param name　テーブル表示名
	 * @param comment コメント
	 * @return テーフル情報ID
	 */
	public int addTableData(EnvData env, String tableName, String name, String comment) {
		//FX画面情報テーブル登録
		DIO_OFN_Table dot = new DIO_OFN_Table(env);
		dot.setTable_Name(tableName);
		dot.setOFN_Name(name);
		dot.setOFN_Comment(comment);
		dot.save();
		return dot.getOFN_Table_ID();
	}

	/**
	 * テーブル項目情報追加<br>
	 * @author ueno hideo				
	 * @since 2020-04-27
	 * @param env 環境情報
	 * @param tableID テーブル情報ID
	 * @param columnName テーブル項目名
	 * @param referenceType 項目属性 
	 * @param size 桁数
	 * @param name テーブル項目論理名
	 * @param comment テーブル項目説明
	 * @param sortOrder 一覧並び順
	 * @param primaryKey プライマリーキー
	 */
	public void addTableColumnData(EnvData env, int tableID, String columnName, String referenceType, int size, String name
			, String comment, int sortOrder, boolean primaryKey) {
		DIO_OFN_TableColumn dtm = new DIO_OFN_TableColumn(env);
		dtm.setOFN_Table_ID(tableID);
		dtm.setColumn_Name(columnName);
		dtm.setColumn_Type_ID(getReferenceID(env, referenceType));
		dtm.setColumn_Size(size);
		dtm.setOFN_Name(name);
		dtm.setOFN_Comment(comment);
		dtm.setColumn_Sort_Order(sortOrder);
		dtm.setPrimary_Key_Check(primaryKey);
		dtm.save();
	}

	/**
	 * 採番情報登録<br>
	 * @author ueno hideo
	 * @since 1.11 2020/06/27
	 * @param env 環境情報
	 * @param tableId テーフル情報ID
	 * @param currentNo 現在値
	 * @param startNo　採番開始値
	 */
	public void addNumberingData(EnvData env, int tableId, int currentNo, int startNo) {
		DIO_OFN_Numbering don = new DIO_OFN_Numbering(env);
		don.setOFN_Table_ID(tableId);
		don.setCurrent_Number(currentNo);
		don.setStart_Number(startNo);
		don.save();
	}

	/**
	 * リファレンス情報追加<br>
	 * @author ueno hideo
	 * @param env 環境情報
	 * @since 2020/05/05
	 * @param referenceName リファレンス名
	 */
	public void addReferenceData(EnvData env, String referenceName) {
		DIO_OFN_Reference dor = new DIO_OFN_Reference(env);
		dor.setReference_Name(referenceName);
		dor.save();
	}
}
