package com.officina_hide.base.model;

public interface DIF_OFN_Fx_ViewAction {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_Fx_ViewAction";

	/**
	 * Fx画面項目制御情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_VIEWACTION_ID = "OFN_Fx_ViewAction_ID";

	/**
	 * Fx画面項目情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_VIEWITEM_ID = "OFN_Fx_ViewItem_ID";

	/**
	 * 画面項目情報処理順序.<br>
	 */
	public final String COLUMNNAME_OFN_SEQ = "OFN_Seq";

	/**
	 * 画面制御属性ID.<br>
	 */
	public final String COLUMNNAME_VIEWACTION_TYPE_ID = "ViewAction_Type_ID";

	/**
	 * 制御対象画面情報ID.<br>
	 */
	public final String COLUMNNAME_VIEWACTION_VIEW_ID = "ViewAction_View_ID";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
