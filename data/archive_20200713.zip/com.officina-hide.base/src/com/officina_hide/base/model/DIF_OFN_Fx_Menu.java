package com.officina_hide.base.model;

public interface DIF_OFN_Fx_Menu {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_Fx_Menu";

	/**
	 * Fx画面メニュー情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_MENU_ID = "OFN_Fx_Menu_ID";

	/**
	 * メニュー名.<br>
	 */
	public final String COLUMNNAME_MENU_NAME = "Menu_Name";

	/**
	 * 説明.<br>
	 */
	public final String COLUMNNAME_OFN_COMMENT = "OFN_Comment";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
