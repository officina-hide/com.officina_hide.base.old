package com.officina_hide.base.model;

public interface DIF_OFN_Fx_ViewItem {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_Fx_ViewItem";

	/**
	 * FX画面項目情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_VIEWITEM_ID = "OFN_Fx_ViewItem_ID";

	/**
	 * FX画面情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_VIEW_ID = "OFN_Fx_View_ID";

	/**
	 * FX画面項目名.<br>
	 */
	public final String COLUMNNAME_FX_VIEWITEM_NAME = "Fx_ViewItem_Name";

	/**
	 * FX画面項目表示名.<br>
	 */
	public final String COLUMNNAME_OFN_NAME = "OFN_Name";

	/**
	 * FX画面項目属性ID.<br>
	 */
	public final String COLUMNNAME_ITEM_TYPE_ID = "Item_Type_ID";

	/**
	 * 説明.<br>
	 */
	public final String COLUMNNAME_OFN_COMMENT = "OFN_Comment";

	/**
	 * 行番号.<br>
	 */
	public final String COLUMNNAME_ROW_NO = "Row_No";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
