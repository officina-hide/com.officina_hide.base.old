package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_Table extends OFN_DB implements OFI_DB,DIF_OFN_Table {
	private EnvData env;

	public DIO_OFN_Table(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_Table(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_Table(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * テーブル情報ID.<br>
	 */
	private int oFN_Table_ID;
	/**
	 * テーブル情報IDを取得する。.<br>
	 */
	public int getOFN_Table_ID() {
		return oFN_Table_ID;
	}
	/**
	 * テーブル情報IDをセットする。.<br>
	 */
	public void setOFN_Table_ID( int oFN_Table_ID) {
		this.oFN_Table_ID = oFN_Table_ID;
	}
	/**
	 * テーブル名.<br>
	 */
	private String table_Name;
	/**
	 * テーブル名を取得する。.<br>
	 */
	public String getTable_Name() {
		return table_Name;
	}
	/**
	 * テーブル名をセットする。.<br>
	 */
	public void setTable_Name (String table_Name) {
		this.table_Name = table_Name;
	}
	/**
	 * テーブル論理名.<br>
	 */
	private String oFN_Name;
	/**
	 * テーブル論理名を取得する。.<br>
	 */
	public String getOFN_Name() {
		return oFN_Name;
	}
	/**
	 * テーブル論理名をセットする。.<br>
	 */
	public void setOFN_Name (String oFN_Name) {
		this.oFN_Name = oFN_Name;
	}
	/**
	 * 説明.<br>
	 */
	private String oFN_Comment;
	/**
	 * 説明を取得する。.<br>
	 */
	public String getOFN_Comment() {
		return oFN_Comment;
	}
	/**
	 * 説明をセットする。.<br>
	 */
	public void setOFN_Comment (String oFN_Comment) {
		this.oFN_Comment = oFN_Comment;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_Tableを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_Table_ID() == 0 ) {
			setOFN_Table_ID(getNewID(env, getTableID(env, "OFN_Table")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_Table.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_Table.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_Table.COLUMNNAME_OFN_TABLE_ID).append(" = ").append(getOFN_Table_ID()).append(",");
		sql.append(DIF_OFN_Table.COLUMNNAME_TABLE_NAME).append(" = '").append(getTable_Name()).append("'").append(",");
		sql.append(DIF_OFN_Table.COLUMNNAME_OFN_NAME).append(" = '").append(getOFN_Name()).append("'").append(",");
		sql.append(DIF_OFN_Table.COLUMNNAME_OFN_COMMENT).append(" = '").append(getOFN_Comment()).append("'").append(",");
		sql.append(DIF_OFN_Table.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Table.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_Table.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Table.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_Table.COLUMNNAME_OFN_TABLE_ID).append(" = ").append(getOFN_Table_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 * @paramenv 環境情報
	 * @paramwhere 抽出条件
	 * @paramorder 並び順
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where, OFN_OrderData order) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_Table.COLUMNNAME_OFN_TABLE_ID).append(" FROM ").append(DIF_OFN_Table.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		if(order != null) {
			sql.append(" ORDER BY ").append(order.toString());
		}
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_Table.COLUMNNAME_OFN_TABLE_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 * @paramenv 環境情報
	 * @paramwhere 抽出条件
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		return getIds(env, where, null);
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_TABLE_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_Table_ID(rs.getInt(COLUMNNAME_OFN_TABLE_ID));
				if(rs.getString(COLUMNNAME_TABLE_NAME) != null) {
					setTable_Name(rs.getString(COLUMNNAME_TABLE_NAME));
				} else {
					setTable_Name("");
				}
				if(rs.getString(COLUMNNAME_OFN_NAME) != null) {
					setOFN_Name(rs.getString(COLUMNNAME_OFN_NAME));
				} else {
					setOFN_Name("");
				}
				if(rs.getString(COLUMNNAME_OFN_COMMENT) != null) {
					setOFN_Comment(rs.getString(COLUMNNAME_OFN_COMMENT));
				} else {
					setOFN_Comment("");
				}
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
