package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_Fx_MenuItem extends OFN_DB implements OFI_DB,DIF_OFN_Fx_MenuItem {
	private EnvData env;

	public DIO_OFN_Fx_MenuItem(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_Fx_MenuItem(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_Fx_MenuItem(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * Fx画面メニュー項目情報ID.<br>
	 */
	private int oFN_Fx_MenuItem_ID;
	/**
	 * Fx画面メニュー項目情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_MenuItem_ID() {
		return oFN_Fx_MenuItem_ID;
	}
	/**
	 * Fx画面メニュー項目情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_MenuItem_ID( int oFN_Fx_MenuItem_ID) {
		this.oFN_Fx_MenuItem_ID = oFN_Fx_MenuItem_ID;
	}
	/**
	 * Fx画面メニュー情報ID.<br>
	 */
	private int oFN_Fx_Menu_ID;
	/**
	 * Fx画面メニュー情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_Menu_ID() {
		return oFN_Fx_Menu_ID;
	}
	/**
	 * Fx画面メニュー情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_Menu_ID( int oFN_Fx_Menu_ID) {
		this.oFN_Fx_Menu_ID = oFN_Fx_Menu_ID;
	}
	/**
	 * メニュー項目名.<br>
	 */
	private String menuItem_Name;
	/**
	 * メニュー項目名を取得する。.<br>
	 */
	public String getMenuItem_Name() {
		return menuItem_Name;
	}
	/**
	 * メニュー項目名をセットする。.<br>
	 */
	public void setMenuItem_Name (String menuItem_Name) {
		this.menuItem_Name = menuItem_Name;
	}
	/**
	 * メニュー項目属性ID.<br>
	 */
	private int menuItem_Type_ID;
	/**
	 * メニュー項目属性IDを取得する。.<br>
	 */
	public int getMenuItem_Type_ID() {
		return menuItem_Type_ID;
	}
	/**
	 * メニュー項目属性IDをセットする。.<br>
	 */
	public void setMenuItem_Type_ID( int menuItem_Type_ID) {
		this.menuItem_Type_ID = menuItem_Type_ID;
	}
	/**
	 * メニュー項目制御ID.<br>
	 */
	private int menuAction_Type_ID;
	/**
	 * メニュー項目制御IDを取得する。.<br>
	 */
	public int getMenuAction_Type_ID() {
		return menuAction_Type_ID;
	}
	/**
	 * メニュー項目制御IDをセットする。.<br>
	 */
	public void setMenuAction_Type_ID( int menuAction_Type_ID) {
		this.menuAction_Type_ID = menuAction_Type_ID;
	}
	/**
	 * メニュー項目制御画面ID.<br>
	 */
	private int menuAction_View_ID;
	/**
	 * メニュー項目制御画面IDを取得する。.<br>
	 */
	public int getMenuAction_View_ID() {
		return menuAction_View_ID;
	}
	/**
	 * メニュー項目制御画面IDをセットする。.<br>
	 */
	public void setMenuAction_View_ID( int menuAction_View_ID) {
		this.menuAction_View_ID = menuAction_View_ID;
	}
	/**
	 * メニュー表示名.<br>
	 */
	private String oFN_Name;
	/**
	 * メニュー表示名を取得する。.<br>
	 */
	public String getOFN_Name() {
		return oFN_Name;
	}
	/**
	 * メニュー表示名をセットする。.<br>
	 */
	public void setOFN_Name (String oFN_Name) {
		this.oFN_Name = oFN_Name;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_Fx_MenuItemを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_Fx_MenuItem_ID() == 0 ) {
			setOFN_Fx_MenuItem_ID(getNewID(env, getTableID(env, "OFN_Fx_MenuItem")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_Fx_MenuItem.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_Fx_MenuItem.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENUITEM_ID).append(" = ").append(getOFN_Fx_MenuItem_ID()).append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENU_ID).append(" = ").append(getOFN_Fx_Menu_ID()).append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_MENUITEM_NAME).append(" = '").append(getMenuItem_Name()).append("'").append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_MENUITEM_TYPE_ID).append(" = ").append(getMenuItem_Type_ID()).append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_MENUACTION_TYPE_ID).append(" = ").append(getMenuAction_Type_ID()).append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_MENUACTION_VIEW_ID).append(" = ").append(getMenuAction_View_ID()).append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_NAME).append(" = '").append(getOFN_Name()).append("'").append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENUITEM_ID).append(" = ").append(getOFN_Fx_MenuItem_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENUITEM_ID).append(" FROM ").append(DIF_OFN_Fx_MenuItem.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_Fx_MenuItem.COLUMNNAME_OFN_FX_MENUITEM_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_FX_MENUITEM_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_Fx_MenuItem_ID(rs.getInt(COLUMNNAME_OFN_FX_MENUITEM_ID));
				setOFN_Fx_Menu_ID(rs.getInt(COLUMNNAME_OFN_FX_MENU_ID));
				if(rs.getString(COLUMNNAME_MENUITEM_NAME) != null) {
					setMenuItem_Name(rs.getString(COLUMNNAME_MENUITEM_NAME));
				} else {
					setMenuItem_Name("");
				}
				setMenuItem_Type_ID(rs.getInt(COLUMNNAME_MENUITEM_TYPE_ID));
				setMenuAction_Type_ID(rs.getInt(COLUMNNAME_MENUACTION_TYPE_ID));
				setMenuAction_View_ID(rs.getInt(COLUMNNAME_MENUACTION_VIEW_ID));
				if(rs.getString(COLUMNNAME_OFN_NAME) != null) {
					setOFN_Name(rs.getString(COLUMNNAME_OFN_NAME));
				} else {
					setOFN_Name("");
				}
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
