package com.officina_hide.base.model;

public interface DIF_OFN_Fx_ViewParameter {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_Fx_ViewParameter";

	/**
	 * FX画面パラメータ情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_VIEWPARAMETER_ID = "OFN_Fx_ViewParameter_ID";

	/**
	 * Fx画面プロセス情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_VIEWPROCESS_ID = "OFN_Fx_ViewProcess_ID";

	/**
	 * パラメータ識別名.<br>
	 */
	public final String COLUMNNAME_PARAMETER_NAME = "Parameter_Name";

	/**
	 * パラメータ種別.<br>
	 */
	public final String COLUMNNAME_PARAMETER_TYPE_ID = "Parameter_Type_ID";

	/**
	 * パラメータ情報(情報ID).<br>
	 */
	public final String COLUMNNAME_PARAMETER_DATA_ID = "Parameter_Data_ID";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
