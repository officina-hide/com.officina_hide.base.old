package com.officina_hide.base.model;

public interface DIF_OFN_Numbering {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_Numbering";

	/**
	 * 採番情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_NUMBERING_ID = "OFN_Numbering_ID";

	/**
	 * テーブル情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_TABLE_ID = "OFN_Table_ID";

	/**
	 * 現在値.<br>
	 */
	public final String COLUMNNAME_CURRENT_NUMBER = "Current_Number";

	/**
	 * 開始値.<br>
	 */
	public final String COLUMNNAME_START_NUMBER = "Start_Number";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
