package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_RefClass extends OFN_DB implements OFI_DB,DIF_OFN_RefClass {
	private EnvData env;

	public DIO_OFN_RefClass(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_RefClass(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_RefClass(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * リファレンスクラス情報ID.<br>
	 */
	private int oFN_RefClass_ID;
	/**
	 * リファレンスクラス情報IDを取得する。.<br>
	 */
	public int getOFN_RefClass_ID() {
		return oFN_RefClass_ID;
	}
	/**
	 * リファレンスクラス情報IDをセットする。.<br>
	 */
	public void setOFN_RefClass_ID( int oFN_RefClass_ID) {
		this.oFN_RefClass_ID = oFN_RefClass_ID;
	}
	/**
	 * リファレンス情報ID.<br>
	 */
	private int oFN_Reference_ID;
	/**
	 * リファレンス情報IDを取得する。.<br>
	 */
	public int getOFN_Reference_ID() {
		return oFN_Reference_ID;
	}
	/**
	 * リファレンス情報IDをセットする。.<br>
	 */
	public void setOFN_Reference_ID( int oFN_Reference_ID) {
		this.oFN_Reference_ID = oFN_Reference_ID;
	}
	/**
	 * リファレンス処理クラス名.<br>
	 */
	private String variable_Class;
	/**
	 * リファレンス処理クラス名を取得する。.<br>
	 */
	public String getVariable_Class() {
		return variable_Class;
	}
	/**
	 * リファレンス処理クラス名をセットする。.<br>
	 */
	public void setVariable_Class (String variable_Class) {
		this.variable_Class = variable_Class;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_RefClassを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_RefClass_ID() == 0 ) {
			setOFN_RefClass_ID(getNewID(env, getTableID(env, "OFN_RefClass")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_RefClass.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_RefClass.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_RefClass.COLUMNNAME_OFN_REFCLASS_ID).append(" = ").append(getOFN_RefClass_ID()).append(",");
		sql.append(DIF_OFN_RefClass.COLUMNNAME_OFN_REFERENCE_ID).append(" = ").append(getOFN_Reference_ID()).append(",");
		sql.append(DIF_OFN_RefClass.COLUMNNAME_VARIABLE_CLASS).append(" = '").append(getVariable_Class()).append("'").append(",");
		sql.append(DIF_OFN_RefClass.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_RefClass.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_RefClass.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_RefClass.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_RefClass.COLUMNNAME_OFN_REFCLASS_ID).append(" = ").append(getOFN_RefClass_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 * @paramenv 環境情報
	 * @paramwhere 抽出条件
	 * @paramorder 並び順
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where, OFN_OrderData order) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_RefClass.COLUMNNAME_OFN_REFCLASS_ID).append(" FROM ").append(DIF_OFN_RefClass.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		if(order != null) {
			sql.append(" ORDER BY ").append(order.toString());
		}
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_RefClass.COLUMNNAME_OFN_REFCLASS_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 * @paramenv 環境情報
	 * @paramwhere 抽出条件
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		return getIds(env, where, null);
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_REFCLASS_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_RefClass_ID(rs.getInt(COLUMNNAME_OFN_REFCLASS_ID));
				setOFN_Reference_ID(rs.getInt(COLUMNNAME_OFN_REFERENCE_ID));
				if(rs.getString(COLUMNNAME_VARIABLE_CLASS) != null) {
					setVariable_Class(rs.getString(COLUMNNAME_VARIABLE_CLASS));
				} else {
					setVariable_Class("");
				}
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
