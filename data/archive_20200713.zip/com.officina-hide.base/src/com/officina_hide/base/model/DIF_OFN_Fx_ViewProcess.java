package com.officina_hide.base.model;

public interface DIF_OFN_Fx_ViewProcess {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_Fx_ViewProcess";

	/**
	 * FX画面プロセス情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_VIEWPROCESS_ID = "OFN_Fx_ViewProcess_ID";

	/**
	 * Fx画面項目情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_VIEWITEM_ID = "OFN_Fx_ViewItem_ID";

	/**
	 * Fx画面プロセス名.<br>
	 */
	public final String COLUMNNAME_PROCESS_NAME = "Process_Name";

	/**
	 * 処理クラス名.<br>
	 */
	public final String COLUMNNAME_PROCESS_CLASS_NAME = "Process_Class_Name";

	/**
	 * プロセス処理順.<br>
	 */
	public final String COLUMNNAME_PROCESS_SORT_ORDER = "Process_Sort_Order";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
