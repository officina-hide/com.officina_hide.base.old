package com.officina_hide.base.model;

/**
 * SQL条件クラス<br>
 * <p>履歴<br>
 * 1.10 新規作成<br>
 * 1.11 length()新規追加 2020/07/01</p>
 * @author ueno hidoe
 * @version 1.11
 * @since 2020/04/30
 */
public class OFN_WhereData {
	/**
	 * 条件文
	 */
	private StringBuffer where;

	public OFN_WhereData() {
	}

	/**
	 * コンストラクタ－<br>
	 * <p>単一の条件（項目名 = 数値変数)の条件を生成する。</p>
	 * @param itemName 項目名
	 * @param valueName 数値変数
	 */
	public OFN_WhereData(String itemName, int valueName) {
		getWhere().append(itemName).append(" = ").append(valueName);
	}

	/**
	 * コンストラクタ－<br>
	 * <p>単一の条件（項目名 = 文字変数)の条件を生成する。</p>
	 * @param itemName 項目名
	 * @param valueName 文字変数
	 */
	public OFN_WhereData(String itemName, String valueName) {
		getWhere().append(itemName).append(" = '").append(valueName).append("'");
	}

	public StringBuffer getWhere() {
		if(where == null) {
			where = new StringBuffer();
		}
		return where;
	}
	
	/**
	 * 条件文のクリア<br>
	 * @author ueno  hideo
	 * @since 2020/05/02
	 */
	public void clear() {
		where = new StringBuffer();
	}

	@Override
	public String toString() {
		return getWhere().toString();
	}

	/**
	 * 条件分の桁数を返す。<br>
	 * @author ueno hideo
	 * @since 1.11 2020/07/01
	 * @return 桁数
	 */
	public int length() {
		return getWhere().toString().length();
	}

}
