package com.officina_hide.base.model;

public interface DIF_OFN_Reference {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_Reference";

	/**
	 * リファレンス情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_REFERENCE_ID = "OFN_Reference_ID";

	/**
	 * リファレンス情報名.<br>
	 */
	public final String COLUMNNAME_REFERENCE_NAME = "Reference_Name";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
