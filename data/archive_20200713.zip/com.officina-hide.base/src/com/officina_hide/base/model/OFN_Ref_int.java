package com.officina_hide.base.model;

import java.util.List;
import java.util.Map;

/**
 * 数値変数クラス<br>
 * @author ueno hideo
 * @version 1.10
 * @since 2020-04-18
 */
public class OFN_Ref_int extends OFN_DB implements OFI_DB {
	
	/**
	 * コンストラクター
	 * @param importClassList 対象クラスリスト
	 */
	public OFN_Ref_int(List<String> importClassList) {
		this.importClassList = importClassList;
	}
	
	public OFN_Ref_int() {
	}

	/**
	 * クラスの変数定義用文字列を返す。<br>
	 * @author ueno hideo
	 * @since 1.10 2020-04-18
	 * @param variableName 変数名
	 * @param name　変数説明
	 * @return 定義用文字列
	 */
	public String toVariableDefinitions(String variableName, String name) {
		StringBuffer source = new StringBuffer();
		source.append(editComment(name, 1));
		source.append(setTab(1)).append("private int ").append(variableName.substring(0, 1).toLowerCase())
			.append(variableName.substring(1)).append(";").append(OFN_RETURN);
		return source.toString();
	}
	
	/**
	 * クラスのgetter定義用文字列を返す。
	 * @author ueno hideo
	 * @since 2020-04-18
	 * @param variableName 変数名
	 * @param name 変数説明
	 * @return 定義用文字列
	 */
	public String toGetterDefinition(String variableName, String name) {
		StringBuffer source = new StringBuffer();
		source.append(editComment(name+"を取得する。", 1));
		source.append(setTab(1)).append("public int get").append(variableName.substring(0, 1).toUpperCase())
			.append(variableName.substring(1)).append("() {").append(OFN_RETURN);
		source.append(setTab(2)).append("return ").append(variableName.substring(0, 1).toLowerCase())
			.append(variableName.substring(1)).append(";").append(OFN_RETURN);
		source.append(setTab(1)).append("}").append(OFN_RETURN);
		return source.toString();
	}
	
	/**
	 * クラスのsetter定義用文字列を返す。<br.
	 * @author ueno hideo
	 * @since 2020-04-20
	 * @param variableName 変数名
	 * @param name 変数説明
	 * @return 定義用文字列
	 */
	public String toSetterDefinition(String variableName, String name) {
		StringBuffer source = new StringBuffer();
		String variable = variableName.substring(0, 1).toLowerCase()+variableName.substring(1);
		source.append(editComment(name+"をセットする。", 1));
		source.append(setTab(1)).append("public void set").append(variableName.substring(0, 1).toUpperCase())
			.append(variableName.substring(1)).append("( int ").append(variable).append(") {").append(OFN_RETURN);
		source.append(setTab(2)).append("this.").append(variable).append(" = ").append(variable).append(";").append(OFN_RETURN);
		source.append(setTab(1)).append("}").append(OFN_RETURN);
		return source.toString();
	}
	
	/**
	 * 保存メソッドSQL用項目セット文字列を使うと返す。<br>
	 * @author ueno hideo
	 * @since 2020-04-25 
	 * @param tableName テーブル名
	 * @param columnName テーブル項目名
	 * @return 定義用文字列
	 */
	public String toSaveSQL (String tableName, String columnName) {
		StringBuffer source = new StringBuffer();
		source.append(setTab(2)).append("sql.append(DIF_").append(tableName).append(".")
			.append("COLUMNNAME_").append(columnName.toUpperCase()).append(")")
			.append(".append(").append(OFN_DQ).append(" = ").append(OFN_DQ).append(")")
			.append(".append(").append("get").append(columnName.substring(0, 1).toUpperCase())
			.append(columnName.substring(1)).append("()")
			.append(")");
		return source.toString();
	}
	
	/**
	 * テーブル生成用SQL文を返す。<br>
	 * @author ueno hideo
	 * @since 2020/04/30
	 * @param map テーブル項目情報
	 * @return SQL文字列
	 */
	public String toTableCreateSQL(Map<String, String>  map) {
		StringBuffer source = new StringBuffer();
		source.append(map.get(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_NAME).toString());
		source.append(" INT");
		if(map.get(DIF_OFN_Reference.COLUMNNAME_REFERENCE_NAME).equals("情報ID")
				||map.get(DIF_OFN_Reference.COLUMNNAME_REFERENCE_NAME).equals("自然数")) {
			source.append(" UNSIGNED");
		}
		if(map.get(DIF_OFN_TableColumn.COLUMNNAME_PRIMARY_KEY_CHECK).equals("YES")) {
			source.append(" PRIMARY KEY");
		}
		if(map.get(DIF_OFN_TableColumn.COLUMNNAME_OFN_NAME).length() > 0) {
			source.append(" COMMENT ").append(OFN_SQ).append(map.get(DIF_OFN_TableColumn.COLUMNNAME_OFN_NAME)).append(OFN_SQ).append(" ");
		}
		// TODO NOT NULL の設定を追加予定(2020-04-30)
		return source.toString();
	}
	
	/**
	 * テーブルからの情報取得用SQL文を返す<br>
	 * @author ueno hideo
	 * @since 2020/05/04
	 * @param map テーブル項目情報
	 * @param tabCnt タブ数
	 * @return Load用定義文
	 */
	public String toLoadSQL(Map<String, String>  map, int tabCnt) {
		StringBuilder source = new StringBuilder();
		String columnName = map.get(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_NAME).toString();
		source.append(setTab(tabCnt)).append("set").append(columnName.substring(0, 1).toUpperCase())
			.append(map.get(DIF_OFN_TableColumn.COLUMNNAME_COLUMN_NAME).substring(1)).append("(")
			.append("rs.getInt(").append("COLUMNNAME_"+columnName.toUpperCase()).append("));").append(OFN_RETURN);
		return source.toString();
	}
}
