package com.officina_hide.base.model;

public interface DIF_OFN_TableColumn {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_TableColumn";

	/**
	 * テーブル項目情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_TABLECOLUMN_ID = "OFN_TableColumn_ID";

	/**
	 * テーブル情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_TABLE_ID = "OFN_Table_ID";

	/**
	 * テーブル項目名.<br>
	 */
	public final String COLUMNNAME_COLUMN_NAME = "Column_Name";

	/**
	 * テーブル項目種別ID（リファレンスID）.<br>
	 */
	public final String COLUMNNAME_COLUMN_TYPE_ID = "Column_Type_ID";

	/**
	 * テーブル項目桁数.<br>
	 */
	public final String COLUMNNAME_COLUMN_SIZE = "Column_Size";

	/**
	 * テーブル項目論理名.<br>
	 */
	public final String COLUMNNAME_OFN_NAME = "OFN_Name";

	/**
	 * 説明.<br>
	 */
	public final String COLUMNNAME_OFN_COMMENT = "OFN_Comment";

	/**
	 * プライマリーキー判定.<br>
	 */
	public final String COLUMNNAME_PRIMARY_KEY_CHECK = "Primary_Key_Check";

	/**
	 * 項目並び順.<br>
	 */
	public final String COLUMNNAME_COLUMN_SORT_ORDER = "Column_Sort_Order";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
