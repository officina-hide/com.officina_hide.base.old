/**
 * 基本情報に対するデータモデルを定義する。<br>
 * ここで管理されているクラスはパッケージに影響を与えるのでユーザー側での変更を禁止する。<br>
 * <p>【English】<br>
 * Define a data model for basic information.<br>
 * Classes managed here affect the package, so change on the user side is prohibited.</p>
 */
package com.officina_hide.base.model;