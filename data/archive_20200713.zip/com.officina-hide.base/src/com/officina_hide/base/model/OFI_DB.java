package com.officina_hide.base.model;

/**
 * データベース基本インターフェース<br>
 * <p>本インターフェースはデータベースを扱うための基本的な定数等を管理する。</p>
 * <p>【English】<br>
 * This interface manages basic constants for handling the database.</p>
 * @author ueno
 *
 */
public interface OFI_DB {
	/**
	 * SQL用文字列 : シングルクォーター
	 */
	public static final Object OFN_SQ = "'";
	/**
	 * SQL用文字列 : 改行
	 */
	public static final String OFN_RETURN = "\n";
	/**
	 * SQL用文字列 : タブ
	 */
	public static final Object OFN_TAB = "\t";
	/**
	 * SQL用文字列 : ダブルクォーター
	 */
	public static final Object OFN_DQ = "\"";

}
