package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_User extends OFN_DB implements OFI_DB,DIF_OFN_User {
	private EnvData env;

	public DIO_OFN_User(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_User(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_User(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * ユーザー情報ID.<br>
	 */
	private int oFN_User_ID;
	/**
	 * ユーザー情報IDを取得する。.<br>
	 */
	public int getOFN_User_ID() {
		return oFN_User_ID;
	}
	/**
	 * ユーザー情報IDをセットする。.<br>
	 */
	public void setOFN_User_ID( int oFN_User_ID) {
		this.oFN_User_ID = oFN_User_ID;
	}
	/**
	 * ユーザー名.<br>
	 */
	private String user_Name;
	/**
	 * ユーザー名を取得する。.<br>
	 */
	public String getUser_Name() {
		return user_Name;
	}
	/**
	 * ユーザー名をセットする。.<br>
	 */
	public void setUser_Name (String user_Name) {
		this.user_Name = user_Name;
	}
	/**
	 * パスワード.<br>
	 */
	private String oFN_Password;
	/**
	 * パスワードを取得する。.<br>
	 */
	public String getOFN_Password() {
		return oFN_Password;
	}
	/**
	 * パスワードをセットする。.<br>
	 */
	public void setOFN_Password (String oFN_Password) {
		this.oFN_Password = oFN_Password;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_Userを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_User_ID() == 0 ) {
			setOFN_User_ID(getNewID(env, getTableID(env, "OFN_User")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_User.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_User.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_User.COLUMNNAME_OFN_USER_ID).append(" = ").append(getOFN_User_ID()).append(",");
		sql.append(DIF_OFN_User.COLUMNNAME_USER_NAME).append(" = '").append(getUser_Name()).append("'").append(",");
		sql.append(DIF_OFN_User.COLUMNNAME_OFN_PASSWORD).append(" = '").append(getOFN_Password()).append("'").append(",");
		sql.append(DIF_OFN_User.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_User.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_User.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_User.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_User.COLUMNNAME_OFN_USER_ID).append(" = ").append(getOFN_User_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_User.COLUMNNAME_OFN_USER_ID).append(" FROM ").append(DIF_OFN_User.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_User.COLUMNNAME_OFN_USER_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_USER_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_User_ID(rs.getInt(COLUMNNAME_OFN_USER_ID));
				if(rs.getString(COLUMNNAME_USER_NAME) != null) {
					setUser_Name(rs.getString(COLUMNNAME_USER_NAME));
				} else {
					setUser_Name("");
				}
				if(rs.getString(COLUMNNAME_OFN_PASSWORD) != null) {
					setOFN_Password(rs.getString(COLUMNNAME_OFN_PASSWORD));
				} else {
					setOFN_Password("");
				}
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
