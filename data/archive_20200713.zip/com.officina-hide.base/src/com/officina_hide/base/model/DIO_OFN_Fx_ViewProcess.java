package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_Fx_ViewProcess extends OFN_DB implements OFI_DB,DIF_OFN_Fx_ViewProcess {
	private EnvData env;

	public DIO_OFN_Fx_ViewProcess(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_Fx_ViewProcess(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_Fx_ViewProcess(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * FX画面プロセス情報ID.<br>
	 */
	private int oFN_Fx_ViewProcess_ID;
	/**
	 * FX画面プロセス情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_ViewProcess_ID() {
		return oFN_Fx_ViewProcess_ID;
	}
	/**
	 * FX画面プロセス情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_ViewProcess_ID( int oFN_Fx_ViewProcess_ID) {
		this.oFN_Fx_ViewProcess_ID = oFN_Fx_ViewProcess_ID;
	}
	/**
	 * Fx画面項目情報ID.<br>
	 */
	private int oFN_Fx_ViewItem_ID;
	/**
	 * Fx画面項目情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_ViewItem_ID() {
		return oFN_Fx_ViewItem_ID;
	}
	/**
	 * Fx画面項目情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_ViewItem_ID( int oFN_Fx_ViewItem_ID) {
		this.oFN_Fx_ViewItem_ID = oFN_Fx_ViewItem_ID;
	}
	/**
	 * Fx画面プロセス名.<br>
	 */
	private String process_Name;
	/**
	 * Fx画面プロセス名を取得する。.<br>
	 */
	public String getProcess_Name() {
		return process_Name;
	}
	/**
	 * Fx画面プロセス名をセットする。.<br>
	 */
	public void setProcess_Name (String process_Name) {
		this.process_Name = process_Name;
	}
	/**
	 * 処理クラス名.<br>
	 */
	private String process_Class_Name;
	/**
	 * 処理クラス名を取得する。.<br>
	 */
	public String getProcess_Class_Name() {
		return process_Class_Name;
	}
	/**
	 * 処理クラス名をセットする。.<br>
	 */
	public void setProcess_Class_Name (String process_Class_Name) {
		this.process_Class_Name = process_Class_Name;
	}
	/**
	 * プロセス処理順.<br>
	 */
	private int process_Sort_Order;
	/**
	 * プロセス処理順を取得する。.<br>
	 */
	public int getProcess_Sort_Order() {
		return process_Sort_Order;
	}
	/**
	 * プロセス処理順をセットする。.<br>
	 */
	public void setProcess_Sort_Order( int process_Sort_Order) {
		this.process_Sort_Order = process_Sort_Order;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_Fx_ViewProcessを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_Fx_ViewProcess_ID() == 0 ) {
			setOFN_Fx_ViewProcess_ID(getNewID(env, getTableID(env, "OFN_Fx_ViewProcess")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_Fx_ViewProcess.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_Fx_ViewProcess.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_FX_VIEWPROCESS_ID).append(" = ").append(getOFN_Fx_ViewProcess_ID()).append(",");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_FX_VIEWITEM_ID).append(" = ").append(getOFN_Fx_ViewItem_ID()).append(",");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_PROCESS_NAME).append(" = '").append(getProcess_Name()).append("'").append(",");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_PROCESS_CLASS_NAME).append(" = '").append(getProcess_Class_Name()).append("'").append(",");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_PROCESS_SORT_ORDER).append(" = ").append(getProcess_Sort_Order()).append(",");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_FX_VIEWPROCESS_ID).append(" = ").append(getOFN_Fx_ViewProcess_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 * @paramenv 環境情報
	 * @paramwhere 抽出条件
	 * @paramorder 並び順
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where, OFN_OrderData order) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_FX_VIEWPROCESS_ID).append(" FROM ").append(DIF_OFN_Fx_ViewProcess.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		if(order != null) {
			sql.append(" ORDER BY ").append(order.toString());
		}
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_Fx_ViewProcess.COLUMNNAME_OFN_FX_VIEWPROCESS_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 * @paramenv 環境情報
	 * @paramwhere 抽出条件
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		return getIds(env, where, null);
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_FX_VIEWPROCESS_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_Fx_ViewProcess_ID(rs.getInt(COLUMNNAME_OFN_FX_VIEWPROCESS_ID));
				setOFN_Fx_ViewItem_ID(rs.getInt(COLUMNNAME_OFN_FX_VIEWITEM_ID));
				if(rs.getString(COLUMNNAME_PROCESS_NAME) != null) {
					setProcess_Name(rs.getString(COLUMNNAME_PROCESS_NAME));
				} else {
					setProcess_Name("");
				}
				if(rs.getString(COLUMNNAME_PROCESS_CLASS_NAME) != null) {
					setProcess_Class_Name(rs.getString(COLUMNNAME_PROCESS_CLASS_NAME));
				} else {
					setProcess_Class_Name("");
				}
				setProcess_Sort_Order(rs.getInt(COLUMNNAME_PROCESS_SORT_ORDER));
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
