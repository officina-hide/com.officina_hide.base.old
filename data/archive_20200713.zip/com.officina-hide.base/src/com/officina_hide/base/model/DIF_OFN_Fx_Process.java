package com.officina_hide.base.model;

public interface DIF_OFN_Fx_Process {

	/**
	 * テーブル名.<br>
	 */
	public final String Table_Name = "OFN_Fx_Process";

	/**
	 * Fxプロセス情報ID.<br>
	 */
	public final String COLUMNNAME_OFN_FX_PROCESS_ID = "OFN_Fx_Process_ID";

	/**
	 * プロセス名.<br>
	 */
	public final String COLUMNNAME_PROCESS_NAME = "Process_Name";

	/**
	 * プロセスクラス.<br>
	 */
	public final String COLUMNNAME_PROCESS_CLASS = "Process_Class";

	/**
	 * Fxプロセス表示名.<br>
	 */
	public final String COLUMNNAME_OFN_NAME = "OFN_Name";

	/**
	 * 説明.<br>
	 */
	public final String COLUMNNAME_OFN_COMMENT = "OFN_Comment";

	/**
	 * 画面情報ID.<br>
	 */
	public final String COLUMNNAME_VIEW_ID = "View_ID";

	/**
	 * 登録日.<br>
	 */
	public final String COLUMNNAME_OFN_CREATE = "OFN_Create";

	/**
	 * 登録者ID.<br>
	 */
	public final String COLUMNNAME_OFN_CREATED = "OFN_Created";

	/**
	 * 更新日.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATE = "OFN_Update";

	/**
	 * 更新者ID.<br>
	 */
	public final String COLUMNNAME_OFN_UPDATED = "OFN_Updated";

}
