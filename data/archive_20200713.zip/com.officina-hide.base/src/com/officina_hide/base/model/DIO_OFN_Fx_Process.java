package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_Fx_Process extends OFN_DB implements OFI_DB,DIF_OFN_Fx_Process {
	private EnvData env;

	public DIO_OFN_Fx_Process(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_Fx_Process(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_Fx_Process(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * Fxプロセス情報ID.<br>
	 */
	private int oFN_Fx_Process_ID;
	/**
	 * Fxプロセス情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_Process_ID() {
		return oFN_Fx_Process_ID;
	}
	/**
	 * Fxプロセス情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_Process_ID( int oFN_Fx_Process_ID) {
		this.oFN_Fx_Process_ID = oFN_Fx_Process_ID;
	}
	/**
	 * プロセス名.<br>
	 */
	private String process_Name;
	/**
	 * プロセス名を取得する。.<br>
	 */
	public String getProcess_Name() {
		return process_Name;
	}
	/**
	 * プロセス名をセットする。.<br>
	 */
	public void setProcess_Name (String process_Name) {
		this.process_Name = process_Name;
	}
	/**
	 * プロセスクラス.<br>
	 */
	private String process_Class;
	/**
	 * プロセスクラスを取得する。.<br>
	 */
	public String getProcess_Class() {
		return process_Class;
	}
	/**
	 * プロセスクラスをセットする。.<br>
	 */
	public void setProcess_Class (String process_Class) {
		this.process_Class = process_Class;
	}
	/**
	 * Fxプロセス表示名.<br>
	 */
	private String oFN_Name;
	/**
	 * Fxプロセス表示名を取得する。.<br>
	 */
	public String getOFN_Name() {
		return oFN_Name;
	}
	/**
	 * Fxプロセス表示名をセットする。.<br>
	 */
	public void setOFN_Name (String oFN_Name) {
		this.oFN_Name = oFN_Name;
	}
	/**
	 * 説明.<br>
	 */
	private String oFN_Comment;
	/**
	 * 説明を取得する。.<br>
	 */
	public String getOFN_Comment() {
		return oFN_Comment;
	}
	/**
	 * 説明をセットする。.<br>
	 */
	public void setOFN_Comment (String oFN_Comment) {
		this.oFN_Comment = oFN_Comment;
	}
	/**
	 * 画面情報ID.<br>
	 */
	private int view_ID;
	/**
	 * 画面情報IDを取得する。.<br>
	 */
	public int getView_ID() {
		return view_ID;
	}
	/**
	 * 画面情報IDをセットする。.<br>
	 */
	public void setView_ID( int view_ID) {
		this.view_ID = view_ID;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_Fx_Processを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_Fx_Process_ID() == 0 ) {
			setOFN_Fx_Process_ID(getNewID(env, getTableID(env, "OFN_Fx_Process")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_Fx_Process.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_Fx_Process.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_FX_PROCESS_ID).append(" = ").append(getOFN_Fx_Process_ID()).append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_PROCESS_NAME).append(" = '").append(getProcess_Name()).append("'").append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_PROCESS_CLASS).append(" = '").append(getProcess_Class()).append("'").append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_NAME).append(" = '").append(getOFN_Name()).append("'").append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_COMMENT).append(" = '").append(getOFN_Comment()).append("'").append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_VIEW_ID).append(" = ").append(getView_ID()).append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_FX_PROCESS_ID).append(" = ").append(getOFN_Fx_Process_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_Fx_Process.COLUMNNAME_OFN_FX_PROCESS_ID).append(" FROM ").append(DIF_OFN_Fx_Process.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_Fx_Process.COLUMNNAME_OFN_FX_PROCESS_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_FX_PROCESS_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_Fx_Process_ID(rs.getInt(COLUMNNAME_OFN_FX_PROCESS_ID));
				if(rs.getString(COLUMNNAME_PROCESS_NAME) != null) {
					setProcess_Name(rs.getString(COLUMNNAME_PROCESS_NAME));
				} else {
					setProcess_Name("");
				}
				if(rs.getString(COLUMNNAME_PROCESS_CLASS) != null) {
					setProcess_Class(rs.getString(COLUMNNAME_PROCESS_CLASS));
				} else {
					setProcess_Class("");
				}
				if(rs.getString(COLUMNNAME_OFN_NAME) != null) {
					setOFN_Name(rs.getString(COLUMNNAME_OFN_NAME));
				} else {
					setOFN_Name("");
				}
				if(rs.getString(COLUMNNAME_OFN_COMMENT) != null) {
					setOFN_Comment(rs.getString(COLUMNNAME_OFN_COMMENT));
				} else {
					setOFN_Comment("");
				}
				setView_ID(rs.getInt(COLUMNNAME_VIEW_ID));
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
