package com.officina_hide.base.model;

import com.officina_hide.base.EnvData;
import com.officina_hide.base.OFN_Logging;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class DIO_OFN_Fx_View extends OFN_DB implements OFI_DB,DIF_OFN_Fx_View {
	private EnvData env;

	public DIO_OFN_Fx_View(EnvData env) {
		this.env = env;
	}

	public DIO_OFN_Fx_View(EnvData env, OFN_WhereData where) {
		this.env = env;
		List<Integer> ids = getIds(env, where);
		if(ids.size() > 0) {
			load(env, ids.get(0));
		}
	}

	public DIO_OFN_Fx_View(EnvData env, int id) {
		this.env = env;
		load(env, id);
	}

	/**
	 * FX画面情報ID.<br>
	 */
	private int oFN_Fx_View_ID;
	/**
	 * FX画面情報IDを取得する。.<br>
	 */
	public int getOFN_Fx_View_ID() {
		return oFN_Fx_View_ID;
	}
	/**
	 * FX画面情報IDをセットする。.<br>
	 */
	public void setOFN_Fx_View_ID( int oFN_Fx_View_ID) {
		this.oFN_Fx_View_ID = oFN_Fx_View_ID;
	}
	/**
	 * Fx画面クラス名.<br>
	 */
	private String fX_View_Name;
	/**
	 * Fx画面クラス名を取得する。.<br>
	 */
	public String getFX_View_Name() {
		return fX_View_Name;
	}
	/**
	 * Fx画面クラス名をセットする。.<br>
	 */
	public void setFX_View_Name (String fX_View_Name) {
		this.fX_View_Name = fX_View_Name;
	}
	/**
	 * Fx画面名.<br>
	 */
	private String oFN_Name;
	/**
	 * Fx画面名を取得する。.<br>
	 */
	public String getOFN_Name() {
		return oFN_Name;
	}
	/**
	 * Fx画面名をセットする。.<br>
	 */
	public void setOFN_Name (String oFN_Name) {
		this.oFN_Name = oFN_Name;
	}
	/**
	 * 説明.<br>
	 */
	private String oFN_Comment;
	/**
	 * 説明を取得する。.<br>
	 */
	public String getOFN_Comment() {
		return oFN_Comment;
	}
	/**
	 * 説明をセットする。.<br>
	 */
	public void setOFN_Comment (String oFN_Comment) {
		this.oFN_Comment = oFN_Comment;
	}
	/**
	 * メニューID.<br>
	 */
	private int oFN_Fx_Menu_ID;
	/**
	 * メニューIDを取得する。.<br>
	 */
	public int getOFN_Fx_Menu_ID() {
		return oFN_Fx_Menu_ID;
	}
	/**
	 * メニューIDをセットする。.<br>
	 */
	public void setOFN_Fx_Menu_ID( int oFN_Fx_Menu_ID) {
		this.oFN_Fx_Menu_ID = oFN_Fx_Menu_ID;
	}
	/**
	 * テーブル情報ID.<br>
	 */
	private int oFN_Table_ID;
	/**
	 * テーブル情報IDを取得する。.<br>
	 */
	public int getOFN_Table_ID() {
		return oFN_Table_ID;
	}
	/**
	 * テーブル情報IDをセットする。.<br>
	 */
	public void setOFN_Table_ID( int oFN_Table_ID) {
		this.oFN_Table_ID = oFN_Table_ID;
	}
	/**
	 * 画面幅初期値.<br>
	 */
	private int pre_Width;
	/**
	 * 画面幅初期値を取得する。.<br>
	 */
	public int getPre_Width() {
		return pre_Width;
	}
	/**
	 * 画面幅初期値をセットする。.<br>
	 */
	public void setPre_Width( int pre_Width) {
		this.pre_Width = pre_Width;
	}
	/**
	 * 画面高さ初期値.<br>
	 */
	private int pre_Height;
	/**
	 * 画面高さ初期値を取得する。.<br>
	 */
	public int getPre_Height() {
		return pre_Height;
	}
	/**
	 * 画面高さ初期値をセットする。.<br>
	 */
	public void setPre_Height( int pre_Height) {
		this.pre_Height = pre_Height;
	}
	/**
	 * 登録日.<br>
	 */
	private Calendar oFN_Create;
	/**
	 * 登録日を取得する。.<br>
	 */
	public Calendar getOFN_Create() {
		if(oFN_Create == null) {
			oFN_Create = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Create;
	}
	/**
	 * 登録日をセットする。.<br>
	 */
	public void setOFN_Create(Calendar oFN_Create) {
		this.oFN_Create = oFN_Create;
	}
	/**
	 * 登録者ID.<br>
	 */
	private int oFN_Created;
	/**
	 * 登録者IDを取得する。.<br>
	 */
	public int getOFN_Created() {
		return oFN_Created;
	}
	/**
	 * 登録者IDをセットする。.<br>
	 */
	public void setOFN_Created( int oFN_Created) {
		this.oFN_Created = oFN_Created;
	}
	/**
	 * 更新日.<br>
	 */
	private Calendar oFN_Update;
	/**
	 * 更新日を取得する。.<br>
	 */
	public Calendar getOFN_Update() {
		if(oFN_Update == null) {
			oFN_Update = new GregorianCalendar(new Locale("ja", "JP"));
		}
		return oFN_Update;
	}
	/**
	 * 更新日をセットする。.<br>
	 */
	public void setOFN_Update(Calendar oFN_Update) {
		this.oFN_Update = oFN_Update;
	}
	/**
	 * 更新者ID.<br>
	 */
	private int oFN_Updated;
	/**
	 * 更新者IDを取得する。.<br>
	 */
	public int getOFN_Updated() {
		return oFN_Updated;
	}
	/**
	 * 更新者IDをセットする。.<br>
	 */
	public void setOFN_Updated( int oFN_Updated) {
		this.oFN_Updated = oFN_Updated;
	}
	/**
	 * OFN_Fx_Viewを保存する。.<br>
	 */
	public void save() {
		StringBuffer sql = new StringBuffer();
		boolean isNewData = false;
		if(getOFN_Fx_View_ID() == 0 ) {
			setOFN_Fx_View_ID(getNewID(env, getTableID(env, "OFN_Fx_View")));
			isNewData = true;
		}
		if(isNewData) {
			sql.append("INSERT INTO ").append(DIF_OFN_Fx_View.Table_Name);
			getOFN_Create().setTime(new Date());
			getOFN_Update().setTime(new Date());
			setOFN_Created(env.getLoginUserID());
			setOFN_Updated(env.getLoginUserID());
		} else {
			sql.append("UPDATE ").append(DIF_OFN_Fx_View.Table_Name);
			getOFN_Update().setTime(new Date());
			setOFN_Updated(env.getLoginUserID());
		}
		sql.append(" SET ");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_FX_VIEW_ID).append(" = ").append(getOFN_Fx_View_ID()).append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_FX_VIEW_NAME).append(" = '").append(getFX_View_Name()).append("'").append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_NAME).append(" = '").append(getOFN_Name()).append("'").append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_COMMENT).append(" = '").append(getOFN_Comment()).append("'").append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_FX_MENU_ID).append(" = ").append(getOFN_Fx_Menu_ID()).append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_TABLE_ID).append(" = ").append(getOFN_Table_ID()).append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_PRE_WIDTH).append(" = ").append(getPre_Width()).append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_PRE_HEIGHT).append(" = ").append(getPre_Height()).append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_CREATE).append(" = '").append(dateFormat.format(getOFN_Create().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_CREATED).append(" = ").append(getOFN_Created()).append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_UPDATE).append(" = '").append(dateFormat.format(getOFN_Update().getTime())).append("'").append(",");
		sql.append(DIF_OFN_Fx_View.COLUMNNAME_OFN_UPDATED).append(" = ").append(getOFN_Updated());
		if(isNewData == false) {
			sql.append(" WHERE ").append(DIF_OFN_Fx_View.COLUMNNAME_OFN_FX_VIEW_ID).append(" = ").append(getOFN_Fx_View_ID());
		}
		executeDB(env, sql.toString());
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 * @paramenv 環境情報
	 * @paramwhere 抽出条件
	 * @paramorder 並び順
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where, OFN_OrderData order) {
		List<Integer> ids = new ArrayList<Integer>();
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ").append(DIF_OFN_Fx_View.COLUMNNAME_OFN_FX_VIEW_ID).append(" FROM ").append(DIF_OFN_Fx_View.Table_Name);
		sql.append(" WHERE ").append(where.toString());
		if(order != null) {
			sql.append(" ORDER BY ").append(order.toString());
		}
		try {
			ResultSet rs = queryDB(env, sql.toString());
			while(rs.next()) {
				ids.add(rs.getInt(DIF_OFN_Fx_View.COLUMNNAME_OFN_FX_VIEW_ID));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;
	}

	/**
	 * 条件文に該当する情報のIDリストを取得する。<br>.<br>
	 * @paramenv 環境情報
	 * @paramwhere 抽出条件
	 */
	public List<Integer> getIds(EnvData env, OFN_WhereData where) {
		return getIds(env, where, null);
	}

	/**
	 * 指定された情報IDを持つ情報を抽出する。<br>.<br>
	 */
	public boolean load(EnvData env, int id) {
		boolean chk = false;
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM ").append(Table_Name);
		sql.append(" WHERE ").append(COLUMNNAME_OFN_FX_VIEW_ID).append(" = ").append(id);
		try {
			ResultSet rs = queryDB(env, sql.toString());
			if(rs.next()) {
				setOFN_Fx_View_ID(rs.getInt(COLUMNNAME_OFN_FX_VIEW_ID));
				if(rs.getString(COLUMNNAME_FX_VIEW_NAME) != null) {
					setFX_View_Name(rs.getString(COLUMNNAME_FX_VIEW_NAME));
				} else {
					setFX_View_Name("");
				}
				if(rs.getString(COLUMNNAME_OFN_NAME) != null) {
					setOFN_Name(rs.getString(COLUMNNAME_OFN_NAME));
				} else {
					setOFN_Name("");
				}
				if(rs.getString(COLUMNNAME_OFN_COMMENT) != null) {
					setOFN_Comment(rs.getString(COLUMNNAME_OFN_COMMENT));
				} else {
					setOFN_Comment("");
				}
				setOFN_Fx_Menu_ID(rs.getInt(COLUMNNAME_OFN_FX_MENU_ID));
				setOFN_Table_ID(rs.getInt(COLUMNNAME_OFN_TABLE_ID));
				setPre_Width(rs.getInt(COLUMNNAME_PRE_WIDTH));
				setPre_Height(rs.getInt(COLUMNNAME_PRE_HEIGHT));
				if(rs.getDate(COLUMNNAME_OFN_CREATE) != null) {
					getOFN_Create().setTime(rs.getDate(COLUMNNAME_OFN_CREATE));
				}
				setOFN_Created(rs.getInt(COLUMNNAME_OFN_CREATED));
				if(rs.getDate(COLUMNNAME_OFN_UPDATE) != null) {
					getOFN_Update().setTime(rs.getDate(COLUMNNAME_OFN_UPDATE));
				}
				setOFN_Updated(rs.getInt(COLUMNNAME_OFN_UPDATED));
			}
		} catch (SQLException e) {
			env.getLog().add(OFN_Logging.ERROR, OFN_Logging.NORMAL, "SQL Execution Error !!");
		}
		return chk;
	}
}
