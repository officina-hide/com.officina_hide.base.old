package com.officina_hide.base;

/**
 * 環境情報<br>
 * <p>プロジェクトを起動するための情報を管理する。<Br>
 * Manage information for launching a project.</p>
 * @author ueno hideo
 * @version 1.10
 * @since 2020-04-08
 */
public class EnvData {
	/**
	 * データベース管理システム名<br>
	 * <p>本パッケージでは登録はMySQLを使用するので、現時点ではこの変数は使用しない。<br>
	 * In this package, registration uses MySQL, so this variable is not used at this time.</p>
	 */
	@SuppressWarnings("unused")
	private String DB_System_Name;
	/**
	 * データベース名
	 */
	private String DB_Name;
	/**
	 * データベースホスト名
	 */
	private String DB_Host;
	/**
	 * データベースユーザーID
	 */
	private String DB_User;
	/**
	 * データベースパスワード
	 */
	private String DB_Password;
	/**
	 * システムユーザーID
	 */
	private int systemUserID;
	/**
	 * 基本モデルクラスFilePath(物理パスで指定する。)
	 */
	private String modelPath;
	/**
	 * 基本モデルクラスの親URI
	 */
	private String modelParent;
	/**
	 * データ関連ファイルPath(物理パスで指定する。)
	 */
	private String dataPath;
	/**
	 * Fx画面クラスFilePath(物理パスで指定する。）
	 */
	private String FxViewPath;
	/**
	 * Fx画面PackageURI
	 */
	private String FxViewParent;
	/**
	 * ログインユーザーID
	 */
	private int loginUserID;
	/**
	 * 開始Fx仮面クラス
	 */
	private String startFxClass;
	/**
	 * ログ情報
	 */
	private OFN_Logging log = new OFN_Logging();
	
	public String getDB_Name() {
		return DB_Name;
	}
	public void setDB_Name(String dB_Name) {
		DB_Name = dB_Name;
	}
	public String getDB_Host() {
		return DB_Host;
	}
	public void setDB_Host(String dB_Host) {
		DB_Host = dB_Host;
	}
	public String getDB_User() {
		return DB_User;
	}
	public void setDB_User(String dB_User) {
		DB_User = dB_User;
	}
	public String getDB_Password() {
		return DB_Password;
	}
	public void setDB_Password(String dB_Password) {
		DB_Password = dB_Password;
	}
	public int getSystemUserID() {
		return systemUserID;
	}
	public void setSystemUserID(int systemUserID) {
		this.systemUserID = systemUserID;
	}
	public String getModelPath() {
		return modelPath;
	}
	public void setModelPath(String modelPath) {
		this.modelPath = modelPath;
	}
	public String getModelParent() {
		return modelParent;
	}
	public void setModelParent(String modelParent) {
		this.modelParent = modelParent;
	}
	public String getDataPath() {
		return dataPath;
	}
	public void setDataPath(String dataPath) {
		this.dataPath = dataPath;
	}
	public OFN_Logging getLog() {
		return log;
	}
	/**
	 * @return loginUserID
	 */
	public int getLoginUserID() {
		return loginUserID;
	}
	/**
	 * @param loginUserID セットする loginUserID
	 */
	public void setLoginUserID(int loginUserID) {
		this.loginUserID = loginUserID;
	}
	public String getStartFxClass() {
		return startFxClass;
	}
	public void setStartFxClass(String startFxClass) {
		this.startFxClass = startFxClass;
	}
	/**
	 * @return fxViewPath
	 */
	public String getFxViewPath() {
		return FxViewPath;
	}
	/**
	 * @param fxViewPath セットする fxViewPath
	 */
	public void setFxViewPath(String fxViewPath) {
		FxViewPath = fxViewPath;
	}
	/**
	 * @return fxViewParent
	 */
	public String getFxViewParent() {
		return FxViewParent;
	}
	/**
	 * @param fxViewParent セットする fxViewParent
	 */
	public void setFxViewParent(String fxViewParent) {
		FxViewParent = fxViewParent;
	}
}
