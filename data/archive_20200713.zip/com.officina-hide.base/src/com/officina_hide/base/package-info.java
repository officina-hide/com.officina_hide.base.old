/**
 * プロジェクトのBaseとなる機能を提供する。<br>
 * <p>【English】<br>
 * Provide a function that becomes the base of the project.</p>
 * @author ueno hideo
 * @since 2019-12-07
 * @version 1.00
 */
package com.officina_hide.base;